package lu.pgd.dri.saga.audit.config;

import java.util.List;
import java.util.Set;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Propriétés audit.* (immuables : un record ne peut pas être modifié au runtime).
 * La taille max des bodies vient de ValidationConstraints, comme avant : une seule source de vérité.
 *
 * @param includedPaths         chemins audités, patterns Ant hors context-path (remplace restServiceUri)
 * @param excludedPaths         chemins jamais audités, prioritaires sur includedPaths
 * @param writerThreads         threads qui écrivent l'audit en base = connexions max prises au pool ;
 *                              règle : au plus 1/4 de spring.datasource.hikari.maximum-pool-size
 * @param queueCapacity         événements en attente max ; file pleine = événement ignoré, jamais bloquant
 * @param maskedHeaders         headers remplacés par ***
 * @param maskedFields          champs JSON remplacés par *** (remplace ignoredJsonFields)
 * @param originAppHeader       header qui identifie l'application appelante
 * @param undefinedSender       valeur de ce header à considérer comme absente
 * @param unknownUser           utilisateur stocké quand personne n'est authentifié
 * @param traceIdResponseHeader header de réponse qui renvoie le traceId au client
 */
@ConfigurationProperties("audit")
public record AuditProperties(
        @DefaultValue("/api/**") List<String> includedPaths,
        @DefaultValue("/actuator/**") List<String> excludedPaths,
        @DefaultValue("2") int writerThreads,
        @DefaultValue("10000") int queueCapacity,
        @DefaultValue({"authorization", "cookie", "set-cookie", "proxy-authorization"}) Set<String> maskedHeaders,
        @DefaultValue({"password", "token", "secret"}) Set<String> maskedFields,
        @DefaultValue("x-sender") String originAppHeader,
        @DefaultValue("x-sender_not-define") String undefinedSender,
        @DefaultValue("UNKNOWN_USER") String unknownUser,
        @DefaultValue("x-b3-trace-id") String traceIdResponseHeader) {
}
