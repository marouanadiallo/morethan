package lu.pgd.dri.saga.audit.http;

import java.io.IOException;
import java.time.Instant;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lu.pgd.dri.saga.audit.config.AuditProperties;
import lu.pgd.dri.saga.audit.trace.CurrentTrace;
import lu.pgd.dri.saga.constants.ValidationConstraints;
import lu.pgd.dri.saga.utils.SecurityUtilities;
import org.springframework.http.MediaType;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.util.ContentCachingRequestWrapper;

/**
 * Audit des requêtes ENTRANTES, vers AUDIT_ENTRY.
 *
 * Règle d'or : ce filtre ne fait AUCUN accès base. Il copie les données de la requête
 * puis les dépose dans HttpAuditRecorder, qui écrit en arrière-plan.
 *
 * Enregistré dans AuditConfiguration avec l'ordre -99 :
 *  - après ServerHttpObservationFilter (Micrometer) => le traceId existe déjà ;
 *  - après Spring Security (-100) => l'utilisateur est connu.
 *    Contrepartie : les 401 / 403 rejetés par Spring Security ne sont pas audités ici.
 */
@Slf4j
@RequiredArgsConstructor
public class HttpAuditFilter extends OncePerRequestFilter {

    private final AntPathMatcher pathMatcher = new AntPathMatcher();
    private final HttpAuditRecorder recorder;
    private final AuditProperties properties;
    private final CurrentTrace currentTrace;

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI().substring(request.getContextPath().length());
        boolean included = properties.includedPaths().stream().anyMatch(p -> pathMatcher.match(p, path));
        boolean excluded = properties.excludedPaths().stream().anyMatch(p -> pathMatcher.match(p, path));
        return !included || excluded;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        // Wrapper fourni par Spring (remplace CachedServletRequest) : garde une copie du body
        // pendant que l'application le lit. La limite évite de dupliquer en mémoire un body de 200 Mo.
        var cachedRequest = new ContentCachingRequestWrapper(request, ValidationConstraints.REQUEST_BODY_MAX_SIZE);
        Instant start = Instant.now();
        boolean failed = false;

        try {
            chain.doFilter(cachedRequest, response);
        } catch (IOException | ServletException | RuntimeException e) {
            failed = true;
            throw e;
        } finally {
            // finally : on audite AUSSI les requêtes en erreur (bug de l'ancien filtre)
            try {
                recorder.recordIncoming(copy(cachedRequest, response, start, failed));
            } catch (RuntimeException e) {
                log.warn("Audit entrant ignoré : {}", e.getMessage()); // l'audit ne casse jamais la requête
            }
        }
    }

    private IncomingRequest copy(ContentCachingRequestWrapper request, HttpServletResponse response,
                                 Instant start, boolean failed) {
        // Exception non gérée : le serveur posera un 500 APRÈS ce filtre, on l'anticipe.
        int status = failed && response.getStatus() < 500 ? 500 : response.getStatus();

        return new IncomingRequest(
                currentTrace.traceId(),
                request.getMethod(),
                fullUrl(request),
                // Route et path variables : fournies par Spring MVC, disponibles APRÈS chain.doFilter
                (String) request.getAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE),
                pathVariables(request),
                copyHeaders(request),
                isJson(request) ? request.getContentAsByteArray() : null, // comme avant : body JSON uniquement
                status,
                SecurityUtilities.getUsedIdFromSecurityContext().orElse(properties.unknownUser()),
                originApp(request),
                start,
                Instant.now());
    }

    /** Repris de l'existant : header x-sender, sinon le client OAuth2 du token (azp). */
    private String originApp(HttpServletRequest request) {
        String header = request.getHeader(properties.originAppHeader());
        if (header != null && !header.isBlank() && !header.equals(properties.undefinedSender())) {
            return header;
        }
        return SecurityUtilities.getAuthorizedParty().orElse(null);
    }

    @SuppressWarnings("unchecked")
    private Map<String, String> pathVariables(HttpServletRequest request) {
        var variables = (Map<String, String>) request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
        return variables != null ? Map.copyOf(variables) : Map.of();
    }

    /** Toutes les valeurs de chaque header (l'ancien code n'en gardait qu'une). */
    private Map<String, List<String>> copyHeaders(HttpServletRequest request) {
        Map<String, List<String>> headers = new HashMap<>();
        for (String name : Collections.list(request.getHeaderNames())) {
            headers.put(name, Collections.list(request.getHeaders(name)));
        }
        return headers;
    }

    private static boolean isJson(HttpServletRequest request) {
        String contentType = request.getContentType();
        return contentType != null && contentType.toLowerCase().startsWith(MediaType.APPLICATION_JSON_VALUE);
    }

    private static String fullUrl(HttpServletRequest request) {
        String query = request.getQueryString();
        return query == null ? request.getRequestURL().toString() : request.getRequestURL() + "?" + query;
    }
}
