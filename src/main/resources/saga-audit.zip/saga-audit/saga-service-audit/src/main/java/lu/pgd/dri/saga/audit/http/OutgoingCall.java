package lu.pgd.dri.saga.audit.http;

import java.time.Instant;

/**
 * Copie d'un appel SORTANT Feign, destinée à la table AUDIT_OUTGOING.
 *
 * @param status code HTTP en texte ; "0" quand le serveur n'a pas répondu (timeout, connexion refusée)
 * @param error  message de l'exception réseau, sinon null
 */
public record OutgoingCall(
        String traceId,
        String method,
        String url,
        byte[] requestBody,
        byte[] responseBody,
        String status,
        String error,
        Instant start,
        Instant end) {
}
