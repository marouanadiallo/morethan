package lu.pgd.dri.saga.audit.feign;

import feign.Capability;
import feign.Client;
import lombok.RequiredArgsConstructor;
import lu.pgd.dri.saga.audit.http.HttpAuditRecorder;
import lu.pgd.dri.saga.audit.trace.CurrentTrace;

/**
 * Branche l'audit sur TOUS les @FeignClient, sans les configurer un par un.
 *
 * Pourquoi un Capability et pas un @Primary Client (ancien FeignAuditConfig) :
 * le @Primary Client remplaçait le client de Spring Cloud par un Client.Default nu
 * (plus de load balancer, plus de pool de connexions, plus de config SSL).
 * Un Capability ENVELOPPE le client déjà configuré : on ajoute l'audit sans rien retirer.
 * C'est le même mécanisme que Micrometer utilise pour tracer Feign.
 */
@RequiredArgsConstructor
public class FeignAuditCapability implements Capability {

    private final HttpAuditRecorder recorder;
    private final CurrentTrace currentTrace;

    @Override
    public Client enrich(Client client) {
        return new FeignAuditClient(client, recorder, currentTrace);
    }
}
