package lu.pgd.dri.saga.audit.business;

import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lu.pgd.dri.saga.audit.config.AuditProperties;
import lu.pgd.dri.saga.audit.http.AuditMasker;
import lu.pgd.dri.saga.audit.trace.CurrentTrace;
import lu.pgd.dri.saga.jpa.entity.audit.ConsultationLogEntry;
import lu.pgd.dri.saga.jpa.entity.audit.DeletionLogEntry;
import lu.pgd.dri.saga.repository.ConsultationScopeTypeRepository;
import lu.pgd.dri.saga.repository.audit.ConsultationLogRepository;
import lu.pgd.dri.saga.repository.audit.DeletionLogRepository;
import lu.pgd.dri.saga.utils.SecurityUtilities;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.WebUtils;

/**
 * Journaux de consultation et de suppression (anciennement dans AuditFilter).
 *
 * Pourquoi un HandlerInterceptor et plus un filtre : ici, Spring sait QUELLE méthode Java a répondu.
 * On lit son annotation (@ConsultationLog / @DeletionLog) au lieu de deviner depuis l'URL.
 *
 * Écriture SYNCHRONE (une ligne, dans le thread de la requête) : contrairement à l'audit HTTP,
 * ce journal ne doit pas être perdu. Une erreur d'écriture est loggée en ERROR mais n'atteint pas
 * le client : en afterCompletion, la réponse est déjà partie.
 */
@Slf4j
@RequiredArgsConstructor
public class BusinessLogInterceptor implements HandlerInterceptor {

    private final ConsultationLogRepository consultationLogRepository;
    private final DeletionLogRepository deletionLogRepository;
    private final ConsultationScopeTypeRepository consultationScopeTypeRepository;
    private final CurrentTrace currentTrace;
    private final AuditMasker masker;
    private final AuditProperties properties;

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
                                Object handler, Exception ex) {
        boolean success = ex == null && response.getStatus() >= 200 && response.getStatus() < 300;
        if (!success || !(handler instanceof HandlerMethod method)) {
            return; // seules les opérations réussies sont journalisées
        }

        ConsultationLog consultation = method.getMethodAnnotation(ConsultationLog.class);
        if (consultation != null) {
            save(request, () -> consultationLogRepository.save(toConsultation(request, consultation)));
        }
        DeletionLog deletion = method.getMethodAnnotation(DeletionLog.class);
        if (deletion != null) {
            save(request, () -> deletionLogRepository.save(toDeletion(request, deletion)));
        }
    }

    private void save(HttpServletRequest request, Runnable write) {
        try {
            write.run();
        } catch (RuntimeException e) {
            log.error("Journal métier non enregistré pour [{} {}]", request.getMethod(), request.getRequestURI(), e);
        }
    }

    private ConsultationLogEntry toConsultation(HttpServletRequest request, ConsultationLog annotation) {
        Long scopeId = parseLong(request.getParameter("scopeId"));
        String onlyActive = request.getParameter("onlyActive");
        return ConsultationLogEntry.builder()
                .traceId(currentTrace.traceId())
                // getReferenceById : pose la clé étrangère SANS faire de SELECT (findById en faisait un)
                .consultationScopeType(scopeId != null ? consultationScopeTypeRepository.getReferenceById(scopeId) : null)
                .motive(request.getParameter("motive"))
                .onlyActive(onlyActive != null ? Boolean.valueOf(onlyActive) : null)
                .url(fullUrl(request))
                .entityName(annotation.entity())
                .entityId(pathVariable(request, annotation.idVariable()))
                .queryParameters(request.getQueryString())
                .requestBody(cachedBody(request))
                .userId(userId())
                .build();
    }

    private DeletionLogEntry toDeletion(HttpServletRequest request, DeletionLog annotation) {
        return DeletionLogEntry.builder()
                .traceId(currentTrace.traceId())
                .motive(request.getParameter("motive"))
                .url(fullUrl(request))
                .entityName(annotation.entity())
                .entityId(pathVariable(request, annotation.idVariable()))
                .userId(userId())
                .build();
    }

    @SuppressWarnings("unchecked")
    private String pathVariable(HttpServletRequest request, String name) {
        if (name.isEmpty()) {
            return null;
        }
        var variables = (Map<String, String>) request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
        return variables != null ? variables.get(name) : null;
    }

    /** Body déjà mis en cache par HttpAuditFilter (pas de seconde lecture du flux), masqué. */
    private String cachedBody(HttpServletRequest request) {
        var cached = WebUtils.getNativeRequest(request, ContentCachingRequestWrapper.class);
        if (cached == null || cached.getContentAsByteArray().length == 0) {
            return null;
        }
        return masker.maskBody(cached.getContentAsByteArray());
    }

    private String userId() {
        return SecurityUtilities.getUsedIdFromSecurityContext().orElse(properties.unknownUser());
    }

    private static String fullUrl(HttpServletRequest request) {
        String query = request.getQueryString();
        return query == null ? request.getRequestURL().toString() : request.getRequestURL() + "?" + query;
    }

    private static Long parseLong(String value) {
        try {
            return value != null ? Long.valueOf(value) : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
