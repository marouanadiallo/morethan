package lu.pgd.dri.saga.audit.http;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Copie d'une requête ENTRANTE, destinée à la table AUDIT_ENTRY.
 *
 * Pourquoi une copie : Tomcat réutilise les objets request/response dès que la réponse est partie.
 * Le thread d'écriture lit donc ce record, jamais la request elle-même.
 */
public record IncomingRequest(
        String traceId,
        String method,
        String url,
        String uriTemplate,
        Map<String, String> pathVariables,
        Map<String, List<String>> headers,
        byte[] jsonBody,
        int status,
        String userId,
        String originApp,
        Instant start,
        Instant end) {
}
