package lu.pgd.dri.saga.audit.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import feign.RequestInterceptor;
import io.micrometer.tracing.Tracer;
import lu.pgd.dri.saga.audit.business.BusinessLogInterceptor;
import lu.pgd.dri.saga.audit.feign.FeignAuditCapability;
import lu.pgd.dri.saga.audit.http.AuditMasker;
import lu.pgd.dri.saga.audit.http.HttpAuditFilter;
import lu.pgd.dri.saga.audit.http.HttpAuditRecorder;
import lu.pgd.dri.saga.audit.trace.CurrentTrace;
import lu.pgd.dri.saga.audit.trace.TraceIdResponseFilter;
import lu.pgd.dri.saga.repository.AuditEntryRepository;
import lu.pgd.dri.saga.repository.ConsultationScopeTypeRepository;
import lu.pgd.dri.saga.repository.audit.AuditOutgoingRepository;
import lu.pgd.dri.saga.repository.audit.ConsultationLogRepository;
import lu.pgd.dri.saga.repository.audit.DeletionLogRepository;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Point d'entrée UNIQUE du module : tout ce que l'audit ajoute à l'application est déclaré ici.
 *
 * Activation : il suffit d'ajouter la dépendance saga-service-audit au module web.
 * Le package lu.pgd.dri.saga.audit est sous celui de l'application (@SpringBootApplication),
 * donc cette classe est trouvée par le scan de composants.
 */
@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties(AuditProperties.class)
public class AuditConfiguration {

    /** Ordres des filtres : Micrometer = HIGHEST_PRECEDENCE + 1, Spring Security = -100. */
    private static final int TRACE_ID_FILTER_ORDER = Ordered.HIGHEST_PRECEDENCE + 2;
    private static final int AUDIT_FILTER_ORDER = -99;

    // ---------- Socle ----------

    /** Sans traçage actif (ex. certains tests), on utilise un tracer vide plutôt que de planter. */
    @Bean
    CurrentTrace currentTrace(ObjectProvider<Tracer> tracer) {
        return new CurrentTrace(tracer.getIfAvailable(() -> Tracer.NOOP));
    }

    @Bean
    AuditMasker auditMasker(ObjectMapper objectMapper, AuditProperties properties) {
        return new AuditMasker(objectMapper, properties.maskedHeaders(), properties.maskedFields());
    }

    @Bean
    HttpAuditRecorder httpAuditRecorder(AuditEntryRepository auditEntryRepository,
                                        AuditOutgoingRepository auditOutgoingRepository,
                                        AuditMasker masker, AuditProperties properties) {
        return new HttpAuditRecorder(auditEntryRepository, auditOutgoingRepository, masker,
                properties.writerThreads(), properties.queueCapacity());
    }

    // ---------- Requêtes entrantes ----------

    @Bean
    FilterRegistrationBean<TraceIdResponseFilter> traceIdResponseFilter(CurrentTrace currentTrace,
                                                                        AuditProperties properties) {
        var registration = new FilterRegistrationBean<>(
                new TraceIdResponseFilter(currentTrace, properties.traceIdResponseHeader()));
        registration.setOrder(TRACE_ID_FILTER_ORDER);
        return registration;
    }

    @Bean
    FilterRegistrationBean<HttpAuditFilter> httpAuditFilter(HttpAuditRecorder recorder, AuditProperties properties,
                                                            CurrentTrace currentTrace) {
        var registration = new FilterRegistrationBean<>(new HttpAuditFilter(recorder, properties, currentTrace));
        registration.setOrder(AUDIT_FILTER_ORDER);
        return registration;
    }

    // ---------- Journaux de consultation / suppression ----------

    @Bean
    BusinessLogInterceptor businessLogInterceptor(ConsultationLogRepository consultationLogRepository,
                                                  DeletionLogRepository deletionLogRepository,
                                                  ConsultationScopeTypeRepository consultationScopeTypeRepository,
                                                  CurrentTrace currentTrace, AuditMasker masker,
                                                  AuditProperties properties) {
        return new BusinessLogInterceptor(consultationLogRepository, deletionLogRepository,
                consultationScopeTypeRepository, currentTrace, masker, properties);
    }

    @Bean
    WebMvcConfigurer businessLogInterceptorRegistration(BusinessLogInterceptor interceptor) {
        return new WebMvcConfigurer() {
            @Override
            public void addInterceptors(InterceptorRegistry registry) {
                registry.addInterceptor(interceptor);
            }
        };
    }

    // ---------- Appels sortants Feign ----------

    /** Spring Cloud OpenFeign applique automatiquement ce Capability à tous les @FeignClient. */
    @Bean
    FeignAuditCapability feignAuditCapability(HttpAuditRecorder recorder, CurrentTrace currentTrace) {
        return new FeignAuditCapability(recorder, currentTrace);
    }

    /**
     * Repris de l'existant (originAppPropagator) : le service appelé sait qui l'appelle.
     * Le traceId n'est plus ajouté ici : Micrometer le propage déjà sur Feign.
     */
    @Bean
    RequestInterceptor originAppFeignInterceptor(@Value("${spring.application.name:saga-service}") String applicationName,
                                                 AuditProperties properties) {
        return template -> {
            if (!template.headers().containsKey(properties.originAppHeader())) {
                template.header(properties.originAppHeader(), applicationName);
            }
        };
    }
}
