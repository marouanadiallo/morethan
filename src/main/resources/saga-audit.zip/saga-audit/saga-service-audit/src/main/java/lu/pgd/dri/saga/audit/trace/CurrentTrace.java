package lu.pgd.dri.saga.audit.trace;

import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import lombok.RequiredArgsConstructor;

/**
 * Remplace AuditService.currentTraceId().
 *
 * L'ancienne méthode générait un UUID et faisait MDC.put sans jamais MDC.remove :
 * sur un thread de pool (@Async, @Scheduled), la tâche suivante héritait du traceId de la précédente.
 * Ici on lit seulement le traceId courant de Micrometer, sans rien écrire nulle part.
 */
@RequiredArgsConstructor
public class CurrentTrace {

    private final Tracer tracer;

    /** traceId courant, ou null hors de toute trace. */
    public String traceId() {
        Span span = tracer.currentSpan();
        return span != null ? span.context().traceId() : null;
    }
}
