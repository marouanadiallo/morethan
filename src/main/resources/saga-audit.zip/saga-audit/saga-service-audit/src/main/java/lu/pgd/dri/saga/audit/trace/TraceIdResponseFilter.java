package lu.pgd.dri.saga.audit.trace;

import java.io.IOException;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Remplace l'ancien MdcFilter : renvoie au client le traceId dans un header de réponse.
 *
 * Différence clé : on ne génère plus d'UUID. On renvoie le traceId de Micrometer,
 * le même que dans les logs, dans les tables d'audit et dans Zipkin.
 * Le MDC (traceId, spanId) est déjà rempli par Micrometer : rien à faire ici.
 *
 * Ordre HIGHEST_PRECEDENCE + 2 (fixé dans AuditConfiguration) : juste après
 * ServerHttpObservationFilter, qui crée la trace.
 */
@RequiredArgsConstructor
public class TraceIdResponseFilter extends OncePerRequestFilter {

    private final CurrentTrace currentTrace;
    private final String headerName;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        String traceId = currentTrace.traceId();
        if (traceId != null) {
            response.setHeader(headerName, traceId); // avant que la réponse parte
        }
        chain.doFilter(request, response);
    }
}
