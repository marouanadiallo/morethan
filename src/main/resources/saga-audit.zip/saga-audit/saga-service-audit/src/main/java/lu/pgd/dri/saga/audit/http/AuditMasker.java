package lu.pgd.dri.saga.audit.http;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * Prépare ce qui part en base d'audit : masque les données sensibles et met en forme.
 *
 * <h2>Pourquoi cette classe existe</h2>
 * Les tables d'audit sont lues par beaucoup de monde (support, exploitation, enquêtes).
 * Un mot de passe, un token ou un cookie qui y arrive en clair devient une fuite.
 * Tout ce qui est écrit dans AUDIT_ENTRY, AUDIT_OUTGOING ou CONSULTATION_LOG passe donc par ici.
 *
 * <h2>Où elle est appelée</h2>
 * Uniquement dans les threads d'écriture (HttpAuditRecorder) et dans BusinessLogInterceptor,
 * jamais dans le chemin critique d'une requête : parser du JSON coûte du CPU.
 *
 * <h2>Ce qui est configurable (application.yml, sans toucher au code)</h2>
 * <ul>
 *   <li>audit.masked-headers : headers remplacés par *** (ex. authorization, cookie) ;</li>
 *   <li>audit.masked-fields : champs JSON remplacés par *** (ex. password, token).</li>
 * </ul>
 * Comparaison toujours insensible à la casse : "Password", "PASSWORD" et "password" sont masqués.
 *
 * <h2>Thread-safety</h2>
 * Les champs sont fixés à la construction et jamais modifiés ; ObjectMapper et Pattern sont
 * thread-safe. Une seule instance (bean) est donc partagée par tous les threads d'audit.
 */
public class AuditMasker {

    /** Valeur de remplacement. Visible et explicite : on sait qu'il y avait une valeur, pas laquelle. */
    private static final String MASK = "***";

    private final ObjectMapper objectMapper;

    /** Noms de headers à masquer, en minuscules (voir lowerCase). */
    private final Set<String> maskedHeaders;

    /** Noms de champs JSON à masquer, en minuscules (voir lowerCase). */
    private final Set<String> maskedFields;

    /**
     * Regex de SECOURS, utilisée seulement quand le body n'est pas du JSON valide (voir maskBody).
     * Compilée UNE fois ici : compiler une regex coûte cher, l'ancien code le faisait à chaque requête
     * et pour chaque champ (String.replaceAll recompile à chaque appel).
     */
    private final Pattern fallbackPattern;

    /**
     * @param objectMapper   l'ObjectMapper de l'application (mêmes modules Jackson que le reste de SAGA)
     * @param maskedHeaders  audit.masked-headers
     * @param maskedFields   audit.masked-fields
     */
    public AuditMasker(ObjectMapper objectMapper, Set<String> maskedHeaders, Set<String> maskedFields) {
        this.objectMapper = objectMapper;
        this.maskedHeaders = lowerCase(maskedHeaders);
        this.maskedFields = lowerCase(maskedFields);
        this.fallbackPattern = buildFallbackPattern(this.maskedFields);
    }

    // =====================================================================================
    // Headers
    // =====================================================================================

    /**
     * Transforme les headers en texte pour la colonne HEADERS, en masquant les headers sensibles.
     *
     * <p>Format conservé de l'ancien CachedServletRequest.getFormattedHeaders(), pour que les écrans
     * et requêtes SQL existants continuent de fonctionner : {@code nom:valeur;nom:valeur}.
     * Un header à plusieurs valeurs les sépare par une virgule (l'ancien code n'en gardait qu'une).
     *
     * <p>Exemple :
     * <pre>
     * entrée : {Accept=[application/json], Authorization=[Bearer eyJ...], Cookie=[JSESSIONID=1; theme=dark]}
     * sortie : Accept:application/json;Authorization:***;Cookie:***
     * </pre>
     *
     * <p>Évolution : pour masquer un nouveau header (ex. x-api-key), l'ajouter dans audit.masked-headers.
     */
    public String formatHeaders(Map<String, List<String>> headers) {
        return headers.entrySet().stream()
                .map(header -> header.getKey() + ":" + headerValue(header.getKey(), header.getValue()))
                .collect(Collectors.joining(";"));
    }

    private String headerValue(String name, List<String> values) {
        return maskedHeaders.contains(name.toLowerCase()) ? MASK : String.join(",", values);
    }

    // =====================================================================================
    // Body
    // =====================================================================================

    /**
     * Rend un body lisible en base, champs sensibles masqués.
     *
     * <p>Deux chemins, du plus fiable au plus approximatif :
     * <ol>
     *   <li><b>JSON valide</b> : Jackson le lit en arbre, maskNode masque les champs à n'importe quelle
     *       profondeur et quel que soit le type de valeur (texte, nombre, objet, tableau).</li>
     *   <li><b>JSON invalide</b> : Jackson échoue. Arrive surtout quand le body a été COUPÉ à
     *       REQUEST_BODY_MAX_SIZE : il manque la fin, donc les accolades fermantes. On ne veut pas
     *       stocker ce texte tel quel (un "password" pourrait être dans la partie conservée),
     *       donc on applique la regex de secours.</li>
     * </ol>
     *
     * <p>Exemple, chemin 1 :
     * <pre>
     * entrée : {"login":"jdoe","password":"s3cret","card":{"pin":1234}}   (masked-fields = password, pin)
     * sortie : {"login":"jdoe","password":"***","card":{"pin":"***"}}
     * </pre>
     *
     * <p>Pourquoi pas seulement une regex, comme l'ancien code : la regex {@code "password"\s*:\s*".*?"}
     * ne reconnaissait que les valeurs entre guillemets. {@code "pin": 1234} ou un objet passaient en clair.
     *
     * @param body octets bruts copiés de la requête ou de la réponse ; null ou vide accepté
     * @return le texte masqué, ou null s'il n'y a pas de body
     */
    public String maskBody(byte[] body) {
        if (body == null || body.length == 0) {
            return null;
        }
        String text = new String(body, StandardCharsets.UTF_8);
        try {
            JsonNode root = objectMapper.readTree(text);   // chemin 1 : JSON valide
            maskNode(root);
            return objectMapper.writeValueAsString(root);
        } catch (JsonProcessingException notJsonOrTruncated) {
            return maskWithRegex(text);                     // chemin 2 : JSON coupé ou texte brut
        }
    }

    /**
     * Parcourt l'arbre JSON et remplace la valeur des champs sensibles par ***.
     *
     * <p>Récursif : descend dans les objets imbriqués et dans chaque élément des tableaux,
     * car un mot de passe peut être à n'importe quel niveau ({"user":{"credentials":{"password":...}}}).
     *
     * <p>On copie d'abord la liste des noms de champs, puis on modifie : modifier un objet JSON
     * pendant qu'on le parcourt provoquerait une ConcurrentModificationException.
     *
     * <p>Un champ masqué n'est pas parcouru plus loin : si "credentials" est masqué,
     * tout son contenu disparaît derrière ***.
     */
    private void maskNode(JsonNode node) {
        if (node instanceof ObjectNode object) {
            List<String> fieldNames = object.properties().stream().map(Map.Entry::getKey).toList();
            for (String fieldName : fieldNames) {
                if (isMaskedField(fieldName)) {
                    object.put(fieldName, MASK);
                } else {
                    maskNode(object.get(fieldName));
                }
            }
        } else if (node != null && node.isArray()) {
            node.forEach(this::maskNode);
        }
        // Les valeurs simples (texte, nombre, booléen) n'ont rien à parcourir : c'est leur parent qui décide.
    }

    /**
     * Masquage de secours par regex, pour un texte qui n'est pas du JSON valide.
     *
     * <p>Moins précis que Jackson (ne comprend pas la structure), mais suffisant pour le cas visé :
     * un JSON coupé en plein milieu. Exemple :
     * <pre>
     * entrée : {"login":"jdoe","password":"s3cret","comment":"texte très long coupé ici
     * sortie : {"login":"jdoe","password":"***","comment":"texte très long coupé ici
     * </pre>
     */
    private String maskWithRegex(String text) {
        if (fallbackPattern == null) {
            return text; // aucun champ à masquer configuré
        }
        return fallbackPattern.matcher(text).replaceAll("$1\"" + MASK + "\"");
    }

    // =====================================================================================
    // Divers
    // =====================================================================================

    /**
     * Convertit une valeur en JSON pour les colonnes CLOB qui stockent du JSON (ex. PATH_VARIABLES).
     * Retourne null en cas d'échec : une colonne vide vaut mieux qu'un audit perdu.
     *
     * <p>Exemple : {@code Map.of("id", "42")} donne {@code {"id":"42"}}.
     */
    public String toJson(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException e) {
            return null;
        }
    }

    private boolean isMaskedField(String fieldName) {
        return maskedFields.contains(fieldName.toLowerCase());
    }

    /** Tout en minuscules une fois pour toutes : ensuite, une simple recherche dans le Set suffit. */
    private static Set<String> lowerCase(Set<String> values) {
        return values.stream().map(String::toLowerCase).collect(Collectors.toUnmodifiableSet());
    }

    /**
     * Construit la regex de secours à partir de audit.masked-fields.
     *
     * <p>Pour masked-fields = password, token, la regex obtenue se lit ainsi :
     * <pre>
     * ("(?:password|token)"\s*:\s*)   groupe 1 : le nom du champ, les deux-points et les espaces → CONSERVÉ
     * ("[^"]*"?|[^,}\]]*)             groupe 2 : la valeur → REMPLACÉE par "***"
     *                                  - "[^"]*"?  une valeur texte, guillemet fermant optionnel (texte coupé)
     *                                  - [^,}\]]*  sinon tout jusqu'à la prochaine virgule, } ou ] (nombre, booléen)
     * </pre>
     * Pattern.quote protège les noms de champs contenant des caractères spéciaux (ex. "user.pin").
     * CASE_INSENSITIVE : même règle que pour Jackson.
     *
     * @return null si aucun champ n'est configuré (une regex vide masquerait n'importe quoi)
     */
    private static Pattern buildFallbackPattern(Set<String> fields) {
        if (fields.isEmpty()) {
            return null;
        }
        String alternatives = fields.stream().map(Pattern::quote).collect(Collectors.joining("|"));
        return Pattern.compile("(\"(?:" + alternatives + ")\"\\s*:\\s*)(\"[^\"]*\"?|[^,}\\]]*)",
                Pattern.CASE_INSENSITIVE);
    }

    /*
     * ÉVOLUTIONS COURANTES
     *
     * - Masquer un nouveau champ ou header : uniquement de la configuration (audit.masked-fields /
     *   audit.masked-headers), aucun code à toucher.
     *
     * - Masquage partiel (ex. garder les 4 derniers chiffres d'une carte) : remplacer
     *   object.put(fieldName, MASK) dans maskNode par un appel à une méthode dédiée, par exemple
     *   object.put(fieldName, maskPartially(object.get(fieldName).asText())).
     *
     * - Masquer selon le CHEMIN et pas seulement le nom (ex. "user.email" mais pas "contact.email") :
     *   passer le chemin courant en paramètre de maskNode ("" au départ, puis parent + "." + fieldName)
     *   et comparer ce chemin à la configuration.
     *
     * - Supporter le XML (SOAP) : ajouter un chemin 3 dans maskBody quand le texte commence par "<",
     *   plutôt que de complexifier la regex.
     *
     * - Tests : chaque exemple des Javadoc ci-dessus fait un test unitaire tout trouvé
     *   (new AuditMasker(new ObjectMapper(), Set.of(...), Set.of(...)), sans Spring).
     */
}
