package lu.pgd.dri.saga.audit.http;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

import lombok.extern.slf4j.Slf4j;
import lu.pgd.dri.saga.constants.ValidationConstraints;
import lu.pgd.dri.saga.jpa.entity.audit.AuditEntry;
import lu.pgd.dri.saga.jpa.entity.audit.AuditOutgoing;
import lu.pgd.dri.saga.repository.AuditEntryRepository;
import lu.pgd.dri.saga.repository.audit.AuditOutgoingRepository;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * Écrit l'audit HTTP en base, en arrière-plan : AUDIT_ENTRY pour l'entrant, AUDIT_OUTGOING pour le sortant.
 *
 * Fonctionnement : un ThreadPoolTaskExecutor de Spring, PROPRE à l'audit (volontairement pas un bean,
 * pour ne pas remplacer l'exécuteur @Async de l'application), avec
 *  - N threads fixes (audit.writer-threads, 2 par défaut) => au plus N connexions prises au pool ;
 *  - une file bornée (audit.queue-capacity) => la mémoire ne peut pas exploser ;
 *  - si la file est pleine, l'événement est ignoré et un warning est loggé => la requête n'attend JAMAIS.
 *
 * Comme un comptoir de pressing : on dépose le ticket et on repart, deux employés traitent
 * les tickets dans l'ordre. Si le comptoir déborde, on refuse le ticket plutôt que de faire attendre le client.
 *
 * Une seule écriture par échange (avant : insert au début + update à la fin, en REQUIRES_NEW).
 */
@Slf4j
public class HttpAuditRecorder implements DisposableBean {

    private static final String TRUNCATION_MARKER = "...[truncated]";

    private final AuditEntryRepository auditEntryRepository;
    private final AuditOutgoingRepository auditOutgoingRepository;
    private final AuditMasker masker;
    private final ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();

    public HttpAuditRecorder(AuditEntryRepository auditEntryRepository, AuditOutgoingRepository auditOutgoingRepository,
                             AuditMasker masker, int threads, int queueCapacity) {
        this.auditEntryRepository = auditEntryRepository;
        this.auditOutgoingRepository = auditOutgoingRepository;
        this.masker = masker;

        executor.setThreadNamePrefix("audit-writer-");
        executor.setCorePoolSize(threads);
        executor.setMaxPoolSize(threads);                // nombre FIXE : = connexions max prises au pool
        executor.setQueueCapacity(queueCapacity);        // file bornée : la mémoire reste sous contrôle
        executor.setRejectedExecutionHandler((task, pool) ->
                log.warn("File d'audit pleine : un événement d'audit est ignoré")); // jamais d'exception vers la requête
        executor.setWaitForTasksToCompleteOnShutdown(true); // à l'arrêt, on finit la file…
        executor.setAwaitTerminationSeconds(10);            // …mais 10 s maximum
        executor.initialize();
    }

    // ---------- Appelés depuis le thread de la requête : déposent et rendent la main ----------

    public void recordIncoming(IncomingRequest request) {
        executor.execute(() -> save(request.url(), () -> auditEntryRepository.save(toAuditEntry(request))));
    }

    public void recordOutgoing(OutgoingCall call) {
        executor.execute(() -> save(call.url(), () -> auditOutgoingRepository.save(toAuditOutgoing(call))));
    }

    // ---------- Exécuté par un thread audit-writer : masquage et INSERT, hors de la requête ----------

    private void save(String url, Runnable insert) {
        try {
            insert.run();
        } catch (Exception e) {
            // L'audit ne doit jamais casser l'application : on log et on continue.
            log.warn("Audit non enregistré pour [{}] : {}", url, e.getMessage());
        }
    }

    private AuditEntry toAuditEntry(IncomingRequest r) {
        return AuditEntry.builder()
                .traceId(r.traceId())
                .originApp(r.originApp())
                .userId(r.userId())
                .action(r.method())
                .url(truncate(r.url(), ValidationConstraints.URL_MAX_SIZE))
                .uriTemplate(r.uriTemplate())                      // nouvelle colonne
                .pathVariables(masker.toJson(r.pathVariables()))   // nouvelle colonne
                .headers(masker.formatHeaders(r.headers()))
                .requestBody(truncate(masker.maskBody(r.jsonBody()), ValidationConstraints.REQUEST_BODY_MAX_SIZE))
                .status(String.valueOf(r.status()))
                .startDate(local(r.start()))
                .endDate(local(r.end()))
                .build();
    }

    private AuditOutgoing toAuditOutgoing(OutgoingCall c) {
        String response = c.error() != null ? c.error() : masker.maskBody(c.responseBody());
        return AuditOutgoing.builder()
                .correlationId(c.traceId())
                .action(truncate(c.method(), ValidationConstraints.ACTION_MAX_SIZE))
                .url(truncate(c.url(), ValidationConstraints.URL_MAX_SIZE))
                .requestBody(truncate(masker.maskBody(c.requestBody()), ValidationConstraints.REQUEST_BODY_MAX_SIZE))
                .responseBody(truncate(response, ValidationConstraints.REQUEST_BODY_MAX_SIZE))
                .status(truncate(c.status(), ValidationConstraints.STATUS_MAX_SIZE))
                .startDate(local(c.start()))
                .endDate(local(c.end()))
                .build();
    }

    /** Les tables existantes sont en LocalDateTime : on convertit dans le fuseau du serveur. */
    private static LocalDateTime local(Instant instant) {
        return instant != null ? LocalDateTime.ofInstant(instant, ZoneId.systemDefault()) : null;
    }

    /** Repris de l'ancien AuditServiceImpl : on coupe et on signale la coupure. */
    private static String truncate(String value, int maxLength) {
        if (value == null || value.length() <= maxLength) {
            return value;
        }
        if (maxLength <= TRUNCATION_MARKER.length()) {
            return value.substring(0, maxLength);
        }
        return value.substring(0, maxLength - TRUNCATION_MARKER.length()) + TRUNCATION_MARKER;
    }

    /**
     * Arrêt de l'application : on n'accepte plus rien et on finit la file (10 s max).
     * Spring appelle destroy() après l'arrêt du serveur web et avant celui de JPA,
     * donc les dernières requêtes sont bien écrites.
     */
    @Override
    public void destroy() {
        executor.shutdown();
    }
}
