package lu.pgd.dri.saga.audit.business;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Journalise une suppression réussie (statut 2xx) de la méthode de contrôleur annotée.
 *
 * Exemple : {@code @DeletionLog(entity = "person")} sur {@code DELETE /persons/{id}}.
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface DeletionLog {

    /** Nom de l'entité supprimée, stocké dans entityName. */
    String entity();

    /** Nom de la path variable qui porte l'id. */
    String idVariable() default "id";
}
