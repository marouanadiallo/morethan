package lu.pgd.dri.saga.audit.feign;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.SequenceInputStream;
import java.time.Instant;
import java.util.Arrays;

import feign.Client;
import feign.Request;
import feign.Response;
import lombok.RequiredArgsConstructor;
import lu.pgd.dri.saga.audit.http.HttpAuditRecorder;
import lu.pgd.dri.saga.audit.http.OutgoingCall;
import lu.pgd.dri.saga.audit.trace.CurrentTrace;
import lu.pgd.dri.saga.constants.ValidationConstraints;

/**
 * Audit des appels SORTANTS Feign, vers AUDIT_OUTGOING. Enveloppe le vrai client (voir FeignAuditCapability).
 *
 * Trois cas, trois chemins :
 *  1. le serveur appelé ne répond pas (timeout, connexion refusée) => statut "0" + message d'erreur ;
 *  2. réponse sans body (204, HEAD) => statut seul ;
 *  3. réponse avec body => on lit le début pour l'audit, puis on rend le body intact à Feign.
 */
@RequiredArgsConstructor
class FeignAuditClient implements Client {

    private static final int MAX_BODY = ValidationConstraints.REQUEST_BODY_MAX_SIZE;

    private final Client delegate;
    private final HttpAuditRecorder recorder;
    private final CurrentTrace currentTrace;

    @Override
    public Response execute(Request request, Request.Options options) throws IOException {
        Instant start = Instant.now();

        Response response;
        try {
            response = delegate.execute(request, options);
        } catch (IOException e) {
            record(request, "0", null, e.getClass().getSimpleName() + ": " + e.getMessage(), start);
            throw e;
        }

        if (response.body() == null) {
            record(request, String.valueOf(response.status()), null, null, start);
            return response;
        }

        // Le body est un flux qu'on ne peut lire qu'UNE fois, comme une cassette sans rembobinage.
        // On lit le début pour l'audit, puis on rend à Feign "le début déjà lu + la suite du flux".
        // Sans ça, le décodeur Feign recevrait un body vide.
        InputStream body = response.body().asInputStream();
        byte[] head = body.readNBytes(MAX_BODY);
        record(request, String.valueOf(response.status()), head, null, start);

        return response.toBuilder()
                .body(new SequenceInputStream(new ByteArrayInputStream(head), body), response.body().length())
                .build();
    }

    private void record(Request request, String status, byte[] responseBody, String error, Instant start) {
        try {
            byte[] requestBody = request.body() == null ? null
                    : Arrays.copyOf(request.body(), Math.min(request.body().length, MAX_BODY));
            recorder.recordOutgoing(new OutgoingCall(
                    currentTrace.traceId(),
                    request.httpMethod().name(),
                    request.url(),
                    requestBody,
                    responseBody,
                    status,
                    error,
                    start,
                    Instant.now()));
        } catch (RuntimeException ignored) {
            // l'audit ne casse jamais l'appel Feign
        }
    }
}
