package lu.pgd.dri.saga.audit.business;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Journalise une consultation réussie (statut 2xx) de la méthode de contrôleur annotée.
 *
 * Exemples :
 * <pre>
 * &#64;ConsultationLog(entity = "person")                      // GET /persons/{id}
 * &#64;ConsultationLog(entity = "address", idVariable = "addressId") // GET /persons/{id}/addresses/{addressId}
 * &#64;ConsultationLog(entity = "person", idVariable = "")      // POST /persons/search (pas d'id)
 * </pre>
 *
 * Remplace le découpage d'URL par position : c'est le développeur qui dit quelle fiche est consultée.
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ConsultationLog {

    /** Nom de l'entité consultée, stocké dans entityName. */
    String entity();

    /** Nom de la path variable qui porte l'id ; "" si pas d'id (recherche). */
    String idVariable() default "id";
}
