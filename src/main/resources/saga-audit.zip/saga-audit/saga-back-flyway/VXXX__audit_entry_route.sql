-- À renommer avec le prochain numéro de version du projet (ex. V42__audit_entry_route.sql)
-- Route Spring et path variables des requêtes entrantes.
-- La table AUDIT_OUTGOING ne change pas : l'URL appelée contient déjà les valeurs.

ALTER TABLE AUDIT_ENTRY ADD (
    URI_TEMPLATE   VARCHAR2(1000 CHAR),
    PATH_VARIABLES CLOB,
    CONSTRAINT CK_AUDIT_ENTRY_PV_JSON CHECK (PATH_VARIABLES IS JSON)
);
