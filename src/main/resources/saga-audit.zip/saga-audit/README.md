# Module saga-service-audit

Audit HTTP (requêtes entrantes et appels Feign sortants) et journaux de consultation / suppression.
Le module se branche sur le module web dès qu'il est ajouté à ses dépendances.

## Tables utilisées

| Ce qui est audité | Table existante | Écrit par |
|---|---|---|
| Requête entrante | `AUDIT_ENTRY` (`AuditEntry`) | `HttpAuditFilter` → `HttpAuditRecorder`, en arrière-plan |
| Appel Feign sortant | `AUDIT_OUTGOING` (`AuditOutgoing`) | `FeignAuditClient` → `HttpAuditRecorder`, en arrière-plan |
| Consultation | `CONSULTATION_LOG` (`ConsultationLogEntry`) | `BusinessLogInterceptor`, synchrone |
| Suppression | `DELETION_LOG` (`DeletionLogEntry`) | `BusinessLogInterceptor`, synchrone |

Chaque échange donne **une seule écriture** (avant : insert au début + update à la fin).
Pour `AUDIT_OUTGOING`, le statut est le code HTTP, ou `0` quand le serveur n'a pas répondu.

## Où va chaque fichier

| Dossier de l'archive | Destination |
|---|---|
| `saga-service-audit/` | Nouveau module, à déclarer dans les `<modules>` du pom parent |
| `saga-back-flyway/` | Module Flyway : renommer `VXXX__` avec le prochain numéro |

Dans le pom du **module web** :

```xml
<dependency>
    <groupId>lu.pgd.dri.saga</groupId>
    <artifactId>saga-service-audit</artifactId>
    <version>${project.version}</version>
</dependency>
```

Rien d'autre : `AuditConfiguration` est trouvée par le scan de `lu.pgd.dri.saga`.

## À ajouter dans `AuditEntry` (module domain)

Deux champs pour la route et les path variables, créés par la migration :

```java
@Column(name = "URI_TEMPLATE", length = 1000)
private String uriTemplate;      // ex. /api/v1/persons/{id}

@Lob
@Column(name = "PATH_VARIABLES")
private String pathVariables;    // ex. {"id":"42"}
```

## À supprimer de l'existant

| Classe | Remplacée par |
|---|---|
| `MdcFilter` | Micrometer (MDC rempli automatiquement) + `TraceIdResponseFilter` |
| `AuditFilter` (ancien) | `HttpAuditFilter` + `BusinessLogInterceptor` |
| `CachedServletRequest` | `ContentCachingRequestWrapper` de Spring |
| `FeignAuditConfig`, `FeignAuditClient` (anciens) | `FeignAuditCapability` + `FeignAuditClient` du module |
| `FeignTraceIdConfig` | Propagation Micrometer + `originAppFeignInterceptor` |
| `AuditProperties` (ancien) | `AuditProperties` du module (record) |
| `AuditService.currentTraceId()` | `CurrentTrace.traceId()` (11 usages à remplacer) |

À garder pour l'instant : `AuditService.start/success/failure` si `SoapAuditHandlerInstaller` s'en sert. Le SOAP n'est pas encore couvert par le module.

`JacksonConfiguration` n'a rien à voir avec l'audit : à déplacer dans le module web.

## Annoter les contrôleurs

```java
@ConsultationLog(entity = "person")                          // GET /persons/{id}
@ConsultationLog(entity = "address", idVariable = "addressId") // GET /persons/{id}/addresses/{addressId}
@ConsultationLog(entity = "person", idVariable = "")          // POST /persons/search
@DeletionLog(entity = "person")                              // DELETE /persons/{id}
```

## Propriétés

| Propriété | Défaut | Ancien équivalent |
|---|---|---|
| `audit.included-paths` | `/api/**` | `audit.rest-service-uri` |
| `audit.excluded-paths` | `/actuator/**` | – |
| `audit.writer-threads` | `2` | – (au plus 1/4 du pool Hikari) |
| `audit.queue-capacity` | `10000` | – |
| `audit.masked-headers` | `authorization, cookie, set-cookie, proxy-authorization` | `Authorization` seul |
| `audit.masked-fields` | `password, token, secret` | `audit.ignored-json-fields` |
| `audit.origin-app-header` | `x-sender` | `audit.origin-app-header-name` |
| `audit.undefined-sender` | `x-sender_not-define` | identique |
| `audit.unknown-user` | `UNKNOWN_USER` | identique |
| `audit.trace-id-response-header` | `x-b3-trace-id` | `audit.trace-id-header-name` |

La taille max des bodies reste `ValidationConstraints.REQUEST_BODY_MAX_SIZE`, comme avant.

Si des services en aval lisent `x-b3-trace-id` en entrée :

```properties
management.tracing.propagation.produce=w3c,b3_multi
management.tracing.propagation.consume=w3c,b3_multi
```

## Prérequis à vérifier

- `SecurityUtilities` et `ValidationConstraints` doivent être accessibles depuis ce module (domain ou module commun), pas depuis le module web : sinon dépendance circulaire.
- Les builders de `AuditEntry`, `AuditOutgoing`, `ConsultationLogEntry` et `DeletionLogEntry` doivent exposer tous leurs champs (`@Builder` de Lombok sur la classe).
