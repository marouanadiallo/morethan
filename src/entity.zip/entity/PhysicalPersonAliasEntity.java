package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.application.enums.PersonDetailsType;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.CountryEntity;
import org.hibernate.annotations.Comment;

import java.time.LocalDate;

@Getter
@Entity
@Table(name = "IS_PHYSICAL_PERSON_ALIAS_PPA")
@AttributeOverride(name = "updatedAt", column = @Column(name = "PPA_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "PPA_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "PPA_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "PPA_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class PhysicalPersonAliasEntity extends Auditable {

    @Id
    @Column(name = "PPA_ID", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_physical_person_details_gen"
    )
    @SequenceGenerator(name = "seq_physical_person_details_gen",
            sequenceName = "IS_PPA_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @JoinColumn(name = "PP_ID", foreignKey = @ForeignKey(name = "C_FK_PPA_PP_ID"))
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private PhysicalPersonEntity physicalPerson;

    @Setter
    @Enumerated(EnumType.STRING)
    @Column(name = "PPA_TYPE")
    private PersonDetailsType type;

    @Setter
    @Column(name = "PPA_FIRST_NAME")
    @Comment("")
    private String firstName;

    @Setter
    @Column(name = "PPA_LAST_NAME")
    @Comment("")
    private String lastName;

    @Setter
    @Column(name = "PPA_DATE_OF_Birth")
    @Comment("")
    private LocalDate dateOfBirth;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "RCTY_BIRTH_PLACE_ID", foreignKey = @ForeignKey(name = "C_FK_PPA_RCTY_BIRTH_PLACE_ID"))
    private CountryEntity birthPlace;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "RCTY_BIRTH_COUNTRY_ID", foreignKey = @ForeignKey(name = "C_FK_PPA_RCTY_BIRTH_COUNTRY_ID"))
    @Comment("")
    private CountryEntity birthCountry;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "RCTY_NAT_ID", foreignKey = @ForeignKey(name = "C_FK_PPA_RCTY_NAT_ID"))
    @Comment("")
    private CountryEntity nationality;

    @Setter
    @Column(name = "PPA_IS_KNOWN_IN_CECIMA")
    @Comment("")
    private boolean isKnownInCeCIMA;

    @Setter
    @Column(name = "PPA_NOTICE")
    @Comment("")
    private String notice;

    public PhysicalPersonAliasEntity() {
        this.id = null;
    }

    public static PhysicalPersonAliasEntity of(PhysicalPersonEntity physicalPerson) {
        PhysicalPersonAliasEntity pe = new PhysicalPersonAliasEntity();
        pe.setPhysicalPerson(physicalPerson);
        return pe;
    }
}
