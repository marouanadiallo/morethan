package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.CategoryEntity;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_CASE_CS", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_CS_CASE_NUMBER", columnNames = {"CS_CASE_NUMBER"})
})
@AttributeOverride(name = "updatedAt", column = @Column(name = "CS_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "CS_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "CS_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "CS_CREATED_BY", nullable = false, updatable = false, length = 50))
public class CaseEntity extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_case_gen"
    )
    @Column(name = "CS_ID", updatable = false, nullable = false)
    @Comment("Unique identifier of the case.")
    @SequenceGenerator(name = "seq_case_gen",
            sequenceName = "IS_CS_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @Column(name = "CS_CASE_NUMBER", length = 100)
    @Comment("")
    private String number;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RCAT_ID", foreignKey = @ForeignKey(name = "C_FK_CS_RCAT_ID"))
    @Comment("")
    private CategoryEntity category;

    protected CaseEntity() {
        this.id = null;
    }

    public static CaseEntity of(String sienaNumber, CategoryEntity category) {
        CaseEntity entity = new CaseEntity();
        entity.setNumber(sienaNumber);
        entity.setCategory(category);
        return entity;
    }
}
