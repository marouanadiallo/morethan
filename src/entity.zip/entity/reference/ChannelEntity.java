package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_CHANNEL_RCH", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_RCH_CODE", columnNames = {"RCH_CODE"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RCH_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RCH_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RCH_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RCH_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RCH_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RCH_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RCH_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RCH_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RCH_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RCH_VALIDITY_FROM", length = 6))
@Comment("")
public class ChannelEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RCH_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_channel_gen")
    @SequenceGenerator(name = "seq_channel_gen",
            sequenceName = "IS_RCH_S",
            allocationSize = 20
    )
    private final Long id;

    protected ChannelEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
