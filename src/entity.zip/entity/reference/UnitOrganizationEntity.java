package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_UNIT_ORGANISATION_RUO", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_RUO_CODE", columnNames = {"RUO_CODE"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RUO_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RUO_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RUO_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RUO_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RUO_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RUO_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RUO_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RUO_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RUO_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RUO_VALIDITY_FROM", length = 6))
@Comment("Defines the organization type.")
public class UnitOrganizationEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RUO_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the organization.")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_unit_organization_gen")
    @SequenceGenerator(name = "seq_unit_organization_gen",
            sequenceName = "IS_RUO_S",
            allocationSize = 20
    )
    private final Long id;

    protected UnitOrganizationEntity() {
        this.id = null;
    }

    public static UnitOrganizationEntity of(String code) {
        UnitOrganizationEntity entity = new UnitOrganizationEntity();
        entity.setCode(code);
        return entity;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
