package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_MESSAGE_RELIABILITY_RMR", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_RMR_CODE", columnNames = {"RMR_CODE"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RMR_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RMR_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RMR_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RMR_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RMR_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RMR_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RMR_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RMR_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RMR_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RMR_VALIDITY_FROM", length = 6))
@Comment("Defines the message reliability type.")
public class MessageReliabilityEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RMR_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the message reliability type.")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_reliability_gen"
    )
    @SequenceGenerator(name = "seq_message_reliability_gen",
            sequenceName = "IS_RMR_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RCH_ID", foreignKey = @ForeignKey(name = "C_FK_RMR_RCH_ID"))
    private ChannelEntity channel;

    protected MessageReliabilityEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
