package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_MESSAGE_STATUS_RMS", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_RMS_CODE", columnNames = {"RMS_CODE"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RMS_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RMS_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RMS_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RMS_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RMS_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RMS_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RMS_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RMS_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RMS_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RMS_VALIDITY_FROM", length = 6))
@Comment("Defines the message status type.")
public class MessageStatusEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RMS_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the message status")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_status_gen"
    )
    @SequenceGenerator(name = "seq_message_status_gen",
            sequenceName = "IS_RMS_S",
            allocationSize = 20
    )
    private final Long id;

    protected MessageStatusEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
