package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_ZONE_ZNE", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_ZNE_ID", columnNames = {"ZNE_CODE"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "ZNE_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "ZNE_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "ZNE_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "ZNE_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "ZNE_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "ZNE_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "ZNE_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "ZNE_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "ZNE_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "ZNE_VALIDITY_FROM", length = 6))
@Comment("")
public class ZoneEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "ZNE_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_zone_gen")
    @SequenceGenerator(name = "seq_zone_gen",
            sequenceName = "IS_ZNE_S",
            allocationSize = 20
    )
    private final Long id;

    protected ZoneEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
