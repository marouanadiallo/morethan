package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_MESSAGE_TYPE_RMT", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_RMT_CODE", columnNames = {"RMT_CODE"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RMT_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RMT_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RMT_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RMT_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RMT_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RMT_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RMT_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RMT_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RMT_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RMT_VALIDITY_FROM", length = 6))
@Comment("Defines the message type.")
public class MessageTypeEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RMT_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the message type")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_type_gen"
    )
    @SequenceGenerator(name = "seq_message_type_gen",
            sequenceName = "IS_RMT_S",
            allocationSize = 20
    )
    private final Long id;

    protected MessageTypeEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
