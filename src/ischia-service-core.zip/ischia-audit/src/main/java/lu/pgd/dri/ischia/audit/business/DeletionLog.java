package lu.pgd.dri.ischia.audit.business;

import java.lang.annotation.*;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface DeletionLog {

    String entity() default "";

    /** Name of the path variable that carries the {id} or {code} ... */
    String idVariable() default "id";
}
