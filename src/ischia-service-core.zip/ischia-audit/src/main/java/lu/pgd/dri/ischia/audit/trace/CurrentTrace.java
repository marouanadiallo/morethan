package lu.pgd.dri.ischia.audit.trace;

import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import lombok.RequiredArgsConstructor;

import java.util.Objects;


@RequiredArgsConstructor
public class CurrentTrace {

    private final Tracer tracer;

    public String traceId() {
        Span span = tracer.currentSpan();
        return Objects.isNull(span) ? null : span.context().traceId();
    }
}
