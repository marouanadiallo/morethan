package lu.pgd.dri.ischia.audit.business;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lu.pgd.dri.ischia.audit.config.AuditProperties;
import lu.pgd.dri.ischia.audit.http.AuditMasker;
import lu.pgd.dri.ischia.audit.trace.CurrentTrace;
import lu.pgd.dri.ischia.domain.persistence.entity.ConsultationLogEntryEntity;
import lu.pgd.dri.ischia.domain.persistence.entity.DeletionLogEntryEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.ConsultationLogEntryRepository;
import lu.pgd.dri.ischia.domain.persistence.repository.DeletionLogEntryRepository;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.ConsultationScopeTypeRepository;
import lu.pgd.dri.ischia.domain.utils.SecurityUtilities;
import org.jspecify.annotations.NonNull;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.WebUtils;

import java.util.Map;
import java.util.Objects;

/**
 * Access and deletion logs
 * Why use a `HandlerInterceptor` instead of a filter ?
 * - Because, in this case, Spring knows *which* Java method handled the request.
 * You read its annotation (@ConsultationLog / @DeletionLog) instead of guessing from the URL.
 * Synchronous writing (one line, in the request thread): unlike HTTP auditing,
 * this log entry must not be lost. A writing error is logged as ERROR but does not reach
 *
 * <br>
 * the client: by the time `afterCompletion` is reached, the response has already been sent.
 */
@Slf4j
@RequiredArgsConstructor
public class BusinessLogInterceptor implements HandlerInterceptor {

    private final ConsultationLogEntryRepository consultationLogRepo;
    private final DeletionLogEntryRepository deletionLogRepo;
    private final ConsultationScopeTypeRepository consultationScopeTypeRepository;

    private final CurrentTrace currentTrace;
    private final AuditMasker masker;
    private final AuditProperties properties;

    private static String fullUrl(HttpServletRequest request) {
        String queryString = request.getQueryString();
        return Objects.isNull(queryString) ? request.getRequestURL().toString() : request.getRequestURL() + "?" + queryString;
    }

    private static Long parseLong(String value) {
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException _) {
            return null;
        }
    }

    @Override
    public void afterCompletion(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull Object handler, Exception ex) {

        boolean success = Objects.isNull(ex) && response.getStatus() >= 200 && response.getStatus() < 300;
        if (!success || !(handler instanceof HandlerMethod method)) {
            return; // Only success operation are log
        }

        ConsultationLog consultation = method.getMethodAnnotation(ConsultationLog.class);
        if (Objects.nonNull(consultation)) {
            save(request, () -> consultationLogRepo.save(toConsultation(request, consultation)));
        }

        DeletionLog deletion = method.getMethodAnnotation(DeletionLog.class);
        if (Objects.nonNull(deletion)) {
            save(request, () -> deletionLogRepo.save(toDeletion(request, deletion)));
        }
    }

    private void save(HttpServletRequest request, Runnable write) {
        try {
            write.run();
        } catch (RuntimeException ex) {
            log.error("Audit log not saved on [{} {}]", request.getMethod(), request.getRequestURI(), ex);
        }
    }

    private ConsultationLogEntryEntity toConsultation(HttpServletRequest request, ConsultationLog annotation) {
        Long scopeId = parseLong(request.getParameter("scopeId"));
        String onlyActive = request.getParameter("onlyActive");
        String motive = request.getParameter("motive");

        ConsultationLogEntryEntity newConsultationLog = ConsultationLogEntryEntity.of(
                currentTrace.traceId(),
                fullUrl(request),
                userId()
        );

        Long entityId = parseLong(pathVariable(request, annotation.idVariable()));
        newConsultationLog.setEntityId(entityId);

        newConsultationLog.setEntityName(annotation.entity());
        newConsultationLog.setQueryParameters(request.getQueryString());
        newConsultationLog.setRequestBody(cachedBody(request));
        newConsultationLog.setMotive(motive);
        newConsultationLog.setOnlyActive(onlyActive != null ? Boolean.valueOf(onlyActive) : null);
        newConsultationLog.setConsultationScopeTypeEntity(
                scopeId != null ? consultationScopeTypeRepository.getReferenceById(scopeId) : null
        );
        return newConsultationLog;
    }

    private DeletionLogEntryEntity toDeletion(HttpServletRequest request, DeletionLog annotation) {
        String motive = request.getParameter("motive");

        DeletionLogEntryEntity newDeletionLog = DeletionLogEntryEntity.of(
                currentTrace.traceId(),
                fullUrl(request),
                annotation.entity(),
                userId()
        );

        Long entityId = parseLong(pathVariable(request, annotation.idVariable()));
        newDeletionLog.setEntityId(entityId);
        newDeletionLog.setMotive(motive);
        return newDeletionLog;
    }

    @SuppressWarnings("unchecked")
    private String pathVariable(HttpServletRequest request, String name) {
        if (Objects.isNull(name) || name.isEmpty())
            return null;
        Map<String, String> variables = (Map<String, String>) request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
        return Objects.isNull(variables) ? null : variables.get(name);
    }

    /**
     * Body already cached by HttpAuditFilter (no second read of the stream), hidden.
     */
    private String cachedBody(HttpServletRequest request) {
        var cached = WebUtils.getNativeRequest(request, ContentCachingRequestWrapper.class);
        if (cached == null || cached.getContentAsByteArray().length == 0) {
            return null;
        }
        return masker.maskBody(cached.getContentAsByteArray());
    }

    private String userId() {
        return SecurityUtilities.getUsedIdFromSecurityContext().orElse(properties.unknownUser());
    }
}
