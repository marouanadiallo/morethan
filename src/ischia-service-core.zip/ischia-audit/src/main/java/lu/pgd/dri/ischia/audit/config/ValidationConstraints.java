package lu.pgd.dri.ischia.audit.config;

public final class ValidationConstraints {
    public static final int STATUS_MAX_SIZE = 3;
    public static final int ACTION_MAX_SIZE = 10;
    public static final int URL_MAX_SIZE = 2000;
    public static final int REQUEST_BODY_MAX_SIZE = 1_000_000;
    private ValidationConstraints() {
    }
}
