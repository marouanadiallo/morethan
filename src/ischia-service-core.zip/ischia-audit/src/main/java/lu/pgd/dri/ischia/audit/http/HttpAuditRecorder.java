package lu.pgd.dri.ischia.audit.http;

import lombok.extern.slf4j.Slf4j;
import lu.pgd.dri.ischia.audit.config.ValidationConstraints;
import lu.pgd.dri.ischia.domain.persistence.entity.AuditEntryEntity;
import lu.pgd.dri.ischia.domain.persistence.entity.AuditOutgoingEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.AuditEntryRepository;
import lu.pgd.dri.ischia.domain.persistence.repository.AuditOutgoingRepository;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.time.Instant;

/**
 * Writes the HTTP audit to the database in the background:
 *  AUDIT_ENTRY for incoming traffic
 *  AUDIT_OUTGOING for outgoing traffic.
 *
 * <br>
 *  Operation: A Spring `ThreadPoolTaskExecutor` dedicated to auditing (intentionally not defined as a bean, to avoid overriding the application's `@Async` executor),
 *  featuring:
 *  - A fixed number of threads (configured via `audit.writer-threads`, defaulting to 2) — meaning at most N connections are drawn from the pool;
 *  - A bounded queue (configured via `audit.queue-capacity`) — ensuring memory usage cannot spiral out of control;
 *  - A mechanism where, if the queue is full, the event is discarded and a warning is logged — ensuring the request NEVER has to wait.
 */
@Slf4j
public class HttpAuditRecorder implements DisposableBean {

    private static final String TRUNCATION_MARKER = "...[truncated]";

    private final AuditEntryRepository auditEntryRepository;
    private final AuditOutgoingRepository auditOutgoingRepository;
    private final AuditMasker masker;

    private final ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();

    public HttpAuditRecorder(AuditEntryRepository auditEntryRepository,
                             AuditOutgoingRepository auditOutgoingRepository,
                             AuditMasker masker, int threads, int queueCapacity) {

        this.auditEntryRepository = auditEntryRepository;
        this.auditOutgoingRepository = auditOutgoingRepository;
        this.masker = masker;

        executor.setThreadNamePrefix("audit-writer-");
        executor.setCorePoolSize(threads);
        executor.setMaxPoolSize(threads);
        executor.setQueueCapacity(queueCapacity);
        executor.setRejectedExecutionHandler(
                (_, _) ->log.warn("Audit queue full: an audit event is ignored")
        );
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(10);
        executor.initialize();
    }

    public void recordIncoming(IncomingRequest request) {
        executor.execute(() -> save(request.url(), () -> auditEntryRepository.save(toAuditEntry(request))));
    }

    public void recordOutgoing(OutgoingCall call) {
        executor.execute(() -> save(call.url(), () -> auditOutgoingRepository.save(toAuditOutgoing(call))));
    }

    private void save(String url, Runnable insert) {
        try {
            insert.run();
        } catch (Exception e) {
            // An audit must never break the application: log the event and carry on.
            log.warn("Unrecorded audit for [{}] : {}", url, e.getMessage());
        }
    }
    private AuditEntryEntity toAuditEntry(IncomingRequest r) {
        AuditEntryEntity newAuditEntry = AuditEntryEntity.of(r.traceId(), r.userId(), r.method(), Instant.now());
        newAuditEntry.setEndDate(Instant.now());
        newAuditEntry.setOriginApp(r.originApp());
        newAuditEntry.setStatus(String.valueOf(r.status()));
        newAuditEntry.setHeaders(masker.formatHeaders(r.headers()));
        newAuditEntry.setUrl(truncate(r.url(), ValidationConstraints.URL_MAX_SIZE));
        newAuditEntry.setRequestBody(truncate(masker.maskBody(r.jsonBody()), ValidationConstraints.REQUEST_BODY_MAX_SIZE));
        return newAuditEntry;
    }

    private AuditOutgoingEntity toAuditOutgoing(OutgoingCall c) {
        String response = c.error() != null ? c.error() : masker.maskBody(c.responseBody());
        AuditOutgoingEntity newAuditOutgoing = AuditOutgoingEntity.of(c.traceId(),
                truncate(c.method(), ValidationConstraints.ACTION_MAX_SIZE),
                truncate(c.status(), ValidationConstraints.STATUS_MAX_SIZE),
                Instant.now()
        );
        newAuditOutgoing.setEndDate(Instant.now());
        newAuditOutgoing.setUrl(truncate(c.url(), ValidationConstraints.URL_MAX_SIZE));
        newAuditOutgoing.setResponseBody(truncate(response, ValidationConstraints.REQUEST_BODY_MAX_SIZE));
        newAuditOutgoing.setRequestBody(truncate(masker.maskBody(c.requestBody()), ValidationConstraints.REQUEST_BODY_MAX_SIZE));

        return newAuditOutgoing;
    }

    private static String truncate(String value, int maxLength) {
        if (value == null || value.length() <= maxLength) {
            return value;
        }
        if (maxLength <= TRUNCATION_MARKER.length()) {
            return value.substring(0, maxLength);
        }
        return value.substring(0, maxLength - TRUNCATION_MARKER.length()) + TRUNCATION_MARKER;
    }

    /**
     * Application shutdown: no new requests are accepted, and the existing queue is processed (10 seconds maximum).
     * Spring invokes `destroy()` after the web server has shut down but before JPA shuts down,
     * ensuring that the final requests are successfully written.
     */
    @Override
    public void destroy() {
        executor.shutdown();
    }
}
