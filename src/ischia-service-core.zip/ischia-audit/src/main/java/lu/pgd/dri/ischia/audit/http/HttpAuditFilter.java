package lu.pgd.dri.ischia.audit.http;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lu.pgd.dri.ischia.audit.config.AuditProperties;
import lu.pgd.dri.ischia.audit.config.ValidationConstraints;
import lu.pgd.dri.ischia.audit.trace.CurrentTrace;
import lu.pgd.dri.ischia.domain.utils.SecurityUtilities;
import org.jspecify.annotations.NonNull;
import org.springframework.http.MediaType;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;

import java.io.IOException;
import java.time.Instant;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Audit of INCOMING requests, to AUDIT_ENTRY.
 *
 * <br>
 * Golden rule: this filter performs NO database access. It copies the request data
 * and then passes it to HttpAuditRecorder, which performs the write operation in the background.
 *
 * <br>
 * Registered in AuditConfiguration with an order of -99:
 *  - after ServerHttpObservationFilter (Micrometer) => the traceId already exists;
 *  - after Spring Security (-100) => the user is known.
 *
 * <br>
 *  Trade-off: 401/403 responses rejected by Spring Security are not audited here.
 */
@Slf4j
@RequiredArgsConstructor
public class HttpAuditFilter extends OncePerRequestFilter {

    private final AntPathMatcher pathMatcher = new AntPathMatcher();
    private final HttpAuditRecorder recorder;
    private final AuditProperties properties;
    private final CurrentTrace currentTrace;

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI().substring(request.getContextPath().length());
        boolean included = properties.includedPaths().stream().anyMatch(p -> pathMatcher.match(p, path));
        boolean excluded = properties.excludedPaths().stream().anyMatch(p -> pathMatcher.match(p, path));
        return !included || excluded;
    }

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull FilterChain filterChain) throws ServletException, IOException {
        // Wrapper provided by Spring, keeps a copy of the body
        // while the application reads it. The limit prevents a 200 MB body from being duplicated in memory.
        ContentCachingRequestWrapper cachedRequest = new ContentCachingRequestWrapper(request, ValidationConstraints.REQUEST_BODY_MAX_SIZE);
        Instant start = Instant.now();
        boolean failed = false;

        try {
            filterChain.doFilter(cachedRequest, response);
        } catch (IOException | ServletException | RuntimeException e) {
            failed = true;
            throw e;
        } finally {
            // Finally: we are ALSO auditing requests that result in errors
            try {
                recorder.recordIncoming(copy(cachedRequest, response, start, failed));
            } catch (RuntimeException e) {
                // The audit never breaks the request.
                log.warn("Incoming audit ignored : {}", e.getMessage());
            }
        }
    }

    private IncomingRequest copy(ContentCachingRequestWrapper request, HttpServletResponse response, Instant start, boolean failed) {
        // Unhandled exception: the server will issue a 500 error AFTER this filter—we anticipate this.
        int status = failed && response.getStatus() < 500 ? 500 : response.getStatus();

        return new IncomingRequest(
                currentTrace.traceId(),
                request.getMethod(),
                fullUrl(request),
                copyHeaders(request),
                isJson(request) ? request.getContentAsByteArray() : null,
                status,
                SecurityUtilities.getUsedIdFromSecurityContext().orElse(properties.unknownUser()),
                originApp(request),
                start,
                Instant.now());
    }

    /** x-sender header; otherwise, the OAuth2 client from the token (azp). */
    private String originApp(HttpServletRequest request) {
        String header = request.getHeader(properties.originAppHeader());
        if (header != null && !header.isBlank() && !header.equals(properties.undefinedSender())) {
            return header;
        }
        return SecurityUtilities.getAuthorizedParty().orElse(null);
    }

    private Map<String, List<String>> copyHeaders(HttpServletRequest request) {
        Map<String, List<String>> headers = new HashMap<>();
        for (String name : Collections.list(request.getHeaderNames())) {
            headers.put(name, Collections.list(request.getHeaders(name)));
        }
        return headers;
    }

    private static boolean isJson(HttpServletRequest request) {
        String contentType = request.getContentType();
        return contentType != null && contentType.toLowerCase().startsWith(MediaType.APPLICATION_JSON_VALUE);
    }

    private static String fullUrl(HttpServletRequest request) {
        String query = request.getQueryString();
        return query == null ? request.getRequestURL().toString() : request.getRequestURL() + "?" + query;
    }
}
