package lu.pgd.dri.ischia.domain.application.service;

import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.referential.MessageConfidentialityService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageConfidentialityEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.MessageConfidentialityRepository;
import lu.pgd.dri.ischia.domainapi.response.ReferentialResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * To test the implementation logic for reference-type services,
 * one of the concrete services is used—in this case,
 * MessageConfidentialityService.
 * <br>
 * So we mock MessageConfidentialityRepository
 */
@ExtendWith(MockitoExtension.class)
class AbstractReferentialServiceTests {

    @Mock
    private ReferentialMapper mapper;
    @Mock
    private ReferentialResponse response;
    @Mock
    private MessageConfidentialityEntity entity;
    @Mock
    private MessageConfidentialityRepository repository;


    private MessageConfidentialityService service;

    @BeforeEach
    void setup() {
        service = new MessageConfidentialityService(mapper, repository);
    }

    @Nested
    @DisplayName("Find all references - unit tests")
    class FindAllReferentialTests {

        @Test
        void shouldReturnMappedReferences() {
            given(repository.findValidateReferences()).willReturn(List.of(entity));
            given(mapper.toReferenceResponse(entity)).willReturn(response);

            assertThat(service.getAll()).containsExactly(response);
        }

        @Test
        void shouldReturnEmptyListWhenNoReferencesAreFound() {
            given(repository.findValidateReferences()).willReturn(List.of());

            assertThat(service.getAll()).isEmpty();
            then(mapper).shouldHaveNoInteractions();
        }

    }

    @Nested
    @DisplayName("Get reference by id - unit tests")
    class GetByIdReferentialTests {

        @Test
        void shouldReturnMappedReferenceWhenFound() {
            given(repository.findById(1L)).willReturn(Optional.of(entity));
            given(mapper.toReferenceResponse(entity)).willReturn(response);

            assertThat(service.getById(1L)).isEqualTo(response);
        }

        @Test
        void shouldThrowExceptionWhenNotFound() {
            given(repository.findById(1L)).willReturn(Optional.empty());

            assertThatThrownBy(() -> service.getById(1L)).isInstanceOf(ResourceNotFoundException.class);
            then(mapper).shouldHaveNoInteractions();
        }
    }

    @Nested
    @DisplayName("Get reference by code - unit tests")
    class GetByCodeReferentialTests {

        @Test
        void shouldReturnMappedReferenceWhenFound() {
            given(repository.findByCodeIgnoreCase(anyString())).willReturn(Optional.of(entity));
            given(mapper.toReferenceResponse(entity)).willReturn(response);

            assertThat(service.getByCode("RefCode")).isEqualTo(response);
        }

        @Test
        void shouldThrowExceptionWhenNotFound() {
            given(repository.findByCodeIgnoreCase(anyString())).willReturn(Optional.empty());
            assertThatThrownBy(() -> service.getByCode("RefCode")).isInstanceOf(ResourceNotFoundException.class);
            then(mapper).shouldHaveNoInteractions();
        }
    }
}
