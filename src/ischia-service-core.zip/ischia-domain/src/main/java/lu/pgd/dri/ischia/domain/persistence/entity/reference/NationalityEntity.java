package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_NATIONALITY_RNT", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_RNT_ID", columnNames = {"code"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RNT_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RNT_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RNT_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RNT_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RNT_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RNT_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RNT_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RNT_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RNT_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RNT_VALIDITY_FROM", length = 6))
@Comment("Defines the nationality type.")
public class NationalityEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RNT_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the nationality.")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_nationality_gen")
    @SequenceGenerator(name = "seq_nationality_gen",
            sequenceName = "IS_RNT_S",
            allocationSize = 20
    )
    private final Long id;

    protected NationalityEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
