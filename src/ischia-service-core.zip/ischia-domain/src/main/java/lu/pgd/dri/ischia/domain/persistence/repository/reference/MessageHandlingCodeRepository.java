package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageHandlingCodeEntity;

public interface MessageHandlingCodeRepository extends  ReferenceBaseRepository<MessageHandlingCodeEntity> {
}
