package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessagePriorityEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.MessagePriorityRepository;
import org.springframework.stereotype.Service;

@Service
public class MessagePriorityService extends AbstractReferentialService<MessagePriorityEntity> {
    public MessagePriorityService(ReferentialMapper referentialMapper, MessagePriorityRepository repository) {
        super(referentialMapper, repository);
    }
}
