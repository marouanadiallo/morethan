package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.CrimeAreaEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.CrimeAreaRepository;
import org.springframework.stereotype.Service;

@Service
public class CrimeAreaService extends AbstractReferentialService<CrimeAreaEntity> {
    public CrimeAreaService(ReferentialMapper referentialMapper, CrimeAreaRepository repository) {
        super(referentialMapper, repository);
    }
}
