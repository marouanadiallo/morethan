package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_CATEGORY_RCAT", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_RCAT_CODE", columnNames = {"code"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RCAT_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RCAT_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RCAT_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RCAT_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RCAT_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RCAT_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RCAT_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RCAT_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RCAT_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RCAT_VALIDITY_FROM", length = 6))
@Comment("")
public class CategoryEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RCAT_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_category_gen")
    @SequenceGenerator(name = "seq_category_gen",
            sequenceName = "IS_RCAT_S",
            allocationSize = 20
    )
    private final Long id;

    protected CategoryEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
