package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.application.enums.SagaFolderType;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_SAGA_FOLDER_SGF")
@AttributeOverride(name = "updatedAt", column = @Column(name = "SGF_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "SGF_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "SGF_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "SGF_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class SagaFolderEntity extends Auditable {

    @Id
    @Column(name = "SGF_ID", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_physical_person_gen"
    )
    @SequenceGenerator(name = "seq_physical_person_gen",
            sequenceName = "IS_CEG_S",
            allocationSize = 20
    )
    private final Long id;

    @Column(name = "SGF_FOLDER_ID", nullable = false)
    @Comment("")
    private Long sagaFolderId;

    @Setter
    @Column(name = "SGF_FOLDER_TYPE")
    @Enumerated(EnumType.STRING)
    private SagaFolderType type;


    @SuppressWarnings("unused")
    protected SagaFolderEntity() {
        this.id = null;
    }

    public SagaFolderEntity(Long sagaFolderId, SagaFolderType type) {
        this.id = null;
        this.sagaFolderId = sagaFolderId;
        this.type = type;
    }
}
