package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;

@Getter
@Entity
@Table(name = "IS_DELETION_LOG_DL")
@EntityListeners(AuditingEntityListener.class)
@Comment("Stores deletion traces for ISCHIA entities")
public class DeletionLogEntryEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_deletion_log_generator"
    )
    @Column(name = "DL_ID", updatable = false, nullable = false)
    @SequenceGenerator(name = "seq_deletion_log_generator",
            sequenceName = "IS_DL_S",
            allocationSize = 20
    )
    @Comment("Technical identifier of the deletion log entry")
    private final Long id;

    @Setter
    @Column(name = "DL_TRACE_ID", nullable = false, length = 64)
    @Comment("Trace identifier propagated across the request flow")
    private String traceId;

    @Setter
    @Column(name = "DL_URL", nullable = false, length = 2000)
    @Comment("Full URL of the deleted resource")
    private String url;

    @Setter
    @Column(name = "DL_ENTITY_NAME", nullable = false, length = 100)
    @Comment("Name of the deleted ISCHIA entity or resource")
    private String entityName;

    @Setter
    @Column(name = "DL_ENTITY_ID")
    @Comment("Identifier of the deleted ISCHIA entity when present in the URL")
    private Long entityId;

    @Setter
    @Column(name = "DL_MOTIVE", length = 300)
    @Comment("Optional motive provided for the deletion")
    private String motive;

    @Setter
    @CreatedDate
    @Column(name = "DL_TIME", nullable = false, updatable = false)
    @Comment("Timestamp when the deletion was logged")
    private Instant time;

    @Setter
    @Column(name = "DL_USER_ID", nullable = false)
    @Comment("Identifier of the authenticated user who performed the deletion")
    private String userId;

    protected DeletionLogEntryEntity() {
        this.id = null;
    }

    /**
     * Construct whit required fields
     */
    public static DeletionLogEntryEntity of(String traceId, String url, String entityName, String userId) {
        DeletionLogEntryEntity entity = new DeletionLogEntryEntity();
        entity.setTraceId(traceId);
        entity.setUrl(url);
        entity.setEntityName(entityName);
        entity.setUserId(userId);
        return entity;
    }
}
