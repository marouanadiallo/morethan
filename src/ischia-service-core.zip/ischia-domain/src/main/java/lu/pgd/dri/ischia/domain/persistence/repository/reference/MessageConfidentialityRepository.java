package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageConfidentialityEntity;

public interface MessageConfidentialityRepository extends  ReferenceBaseRepository<MessageConfidentialityEntity> {
}
