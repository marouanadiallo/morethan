package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageReliabilityEntity;

public interface MessageReliabilityRepository extends  ReferenceBaseRepository<MessageReliabilityEntity> {
}
