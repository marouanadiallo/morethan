package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageConfidentialityEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.MessageConfidentialityRepository;
import org.springframework.stereotype.Service;

@Service
public class MessageConfidentialityService extends AbstractReferentialService<MessageConfidentialityEntity> {
    public MessageConfidentialityService(ReferentialMapper referentialMapper, MessageConfidentialityRepository repository) {
        super(referentialMapper, repository);
    }
}
