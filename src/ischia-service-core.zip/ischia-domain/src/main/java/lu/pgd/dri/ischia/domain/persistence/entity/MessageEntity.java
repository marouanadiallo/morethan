package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.application.enums.MessageDirection;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.*;
import org.hibernate.annotations.Comment;

import java.util.Objects;

@Getter
@Entity
@Table(name = "IS_MESSAGE_MSG", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_MSG_REFENCE_ID", columnNames = {"referenceID"})
})
@AttributeOverride(name = "updatedAt", column = @Column(name = "MSG_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "MSG_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "MSG_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "MSG_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class MessageEntity extends Auditable {

    @Id
    @Column(name = "MSG_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_gen"
    )
    @SequenceGenerator(
            name = "seq_message_gen",
            sequenceName = "IS_MSG_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @Column(name = "MSG_PARENT_REFENCE_ID")
    @Comment("Message parent identifier")
    private String parentReferenceId;

    @Setter
    @Column(name = "MSG_REFENCE_ID")
    @Comment("")
    private String referenceID;

    @Setter
    @Column(name = "MSG_DIRECTION")
    @Enumerated(EnumType.STRING)
    @Comment("")
    private MessageDirection direction;

    @Setter
    @Column(name = "MSG_SUBJECT", length = 2000)
    @Comment("")
    private String subject;

    @Setter
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "MSG_BODY", columnDefinition = "CLOB")
    @Comment("")
    private String body;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "MAD_ID", foreignKey = @ForeignKey(name = "C_FK_MSG_MAD_ID"))
    private MailAddressEntity sender;

    @Setter
    @Column(name = "MSG_OTHER_CRIME_AREA")
    @Comment("")
    private String otherCrimeArea;

    @Setter
    @Column(name = "MSG_VERSION")
    @Comment("")
    private Long version;

    @Setter
    @Column(name = "MSG_INFO_AVAILABLE", nullable = false)
    @Comment("")
    private Boolean infoAvailable;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RMR_ID", foreignKey = @ForeignKey(name = "C_FK_MSG_RMR_ID"))
    @Comment("")
    private MessageReliabilityEntity reliability;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RCH_ID", foreignKey = @ForeignKey(name = "C_FK_MSG_RCH_ID"))
    @Comment("")
    private ChannelEntity channel;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RMS_ID", foreignKey = @ForeignKey(name = "C_FK_MSG_RMS_ID"))
    @Comment("")
    private MessageStatusEntity status;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RMP_ID", foreignKey = @ForeignKey(name = "C_FK_MSG_RMP_ID"))
    @Comment("")
    private MessagePriorityEntity priority;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RMC_ID", foreignKey = @ForeignKey(name = "C_FK_MSG_RMC_ID"))
    @Comment("")
    private MessageConfidentialityEntity confidentiality;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RMT_ID", foreignKey = @ForeignKey(name = "C_FK_MSG_RMT_ID"))
    @Comment("")
    private MessageTypeEntity type;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "CS_ID", foreignKey = @ForeignKey(name = "C_FK_MSG_CS_ID"))
    @Comment("")
    private CaseEntity aCase;

    protected MessageEntity() {
        this.id = null;
    }

    public static MessageEntity of(MailAddressEntity sender, String subject, String body) {
        MessageEntity entity = new MessageEntity();
        entity.setSender(sender);
        entity.setSubject(subject);
        entity.setBody(body);
        return entity;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass())
            return false;

        MessageEntity that = (MessageEntity) o;
        return Objects.equals(id, that.id) && referenceID.equals(that.referenceID);
    }

    @Override
    public int hashCode() {
        return referenceID.hashCode();
    }
}
