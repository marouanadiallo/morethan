package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.persistence.entity.Auditable;
import org.hibernate.annotations.Comment;

import java.time.LocalDate;


@Getter
@Setter
@MappedSuperclass
public abstract class AbstractReferenceEntity extends Auditable {

    @Comment("Unique code identifying the referential type")
    protected String code;

    @Comment("Reason label in German")
    protected String labelDe;

    @Comment("Reason label in French")
    protected String labelFr;

    @Comment("Reason label in English")
    protected String labelEn;

    @Comment("Date from which the assignee type is valid")
    protected LocalDate validityFrom;

    @Comment("Date until which the assignee type remains valid")
    protected LocalDate validityTo;

    protected AbstractReferenceEntity() {
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass())
            return false;

        AbstractReferenceEntity that = (AbstractReferenceEntity) o;
        return code.equals(that.code);
    }

    @Override
    public int hashCode() {
        return code.hashCode();
    }
}
