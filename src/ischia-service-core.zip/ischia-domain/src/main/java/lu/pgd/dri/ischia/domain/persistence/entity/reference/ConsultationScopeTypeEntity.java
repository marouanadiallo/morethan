package lu.pgd.dri.ischia.domain.persistence.entity.reference;


import jakarta.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_CONSULTATION_SCOPE_TYPE_RCSTE", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_RCSTE_CODE", columnNames = {"code"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RCSTE_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RCSTE_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RCSTE_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RCSTE_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RCSTE_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RCSTE_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RCSTE_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RCSTE_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RCSTE_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RCSTE_VALIDITY_FROM", length = 6))
public class ConsultationScopeTypeEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RCSTE_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the consultation  scope type")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_consultation_type_generator"
    )
    @SequenceGenerator(name = "seq_consultation_type_generator",
            sequenceName = "IS_RCSTE_S",
            allocationSize = 20
    )
    private final Long id;

    protected ConsultationScopeTypeEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
