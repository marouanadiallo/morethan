package lu.pgd.dri.ischia.domain.application.validation;

import lombok.Getter;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Builds a structured error response that mirrors the request JSON structure.
 * <br>
 * Simple field:
 * {
 *   "title": { "code": "TITLE_MANDATORY", "message": "...", "value": "" }
 * }
 * <br>
 * List of objects — error on sub-fields (List<Assignee>):
 * {
 *   "assignees": [
 *     null,
 *     { "id": { "code": "NOT_FOUND", "message": "...", "value": "user_abc" } },
 *     null
 *   ]
 * }
 * <br>
 * List of strings — single error (List<String>):
 * {
 *   "observers": [
 *     null,
 *     { "code": "NOT_FOUND", "message": "...", "value": "GUY3223" },
 *     null
 *   ]
 * }
 * <br>
 * List of strings — multiple errors on same index:
 * {
 *   "childFolderNumbers": [
 *     null,
 *     [
 *       { "code": "NOT_FOUND", "message": "...", "value": "9999/9999" },
 *       { "code": "HAS_PARENT", "message": "...", "value": "9999/9999" }
 *     ],
 *     null
 *   ]
 * }
 */
@Getter
public final class ValidationErrorFactory {

    private final Map<String, Object> errors = new LinkedHashMap<>();

    public static final Pattern LIST_FIELD_PATTERN = Pattern.compile("^(.+)\\[(\\d+)](?:\\.(.+))?$");

    private ValidationErrorFactory() {
    }

    public static ValidationErrorFactory getInstance() {
        return new ValidationErrorFactory();
    }

    /**
     * List of the errors on a simple field (not inside a list).
     */
    @SuppressWarnings("unchecked")
    public void addFieldError(String field, String code, String message, Object rejectedValue) {
        Map<String, Object> detail = buildDetail(code, message, rejectedValue);
        Object existing = errors.get(field);
        if (existing == null) {
            errors.put(field, detail);
        } else if (existing instanceof List) {
            ((List<Object>) existing).add(detail);
        } else {
            List<Object> errorList = new ArrayList<>();
            errorList.add(existing);
            errorList.add(detail);
            errors.put(field, errorList);
        }
    }

    /**
     * Error on a sub-field of an object inside a list.
     * For List<Assignee> → error on assignees[1].id
     * Supports multiple errors on the same sub-field.
     */
    @SuppressWarnings("unchecked")
    public void addListFieldError(String listName, int index, int listSize,
                                  String field, String code, String message,
                                  Object rejectedValue) {
        List<Object> list = getOrCreateList(listName, listSize);
        expandList(list, index);

        if (list.get(index) == null) {
            list.set(index, new LinkedHashMap<String, Object>());
        }

        Map<String, Object> elementErrors = (Map<String, Object>) list.get(index);
        Map<String, Object> detail = buildDetail(code, message, rejectedValue);

        Object existing = elementErrors.get(field);
        if (existing == null) {
            elementErrors.put(field, detail);
        } else if (existing instanceof List) {
            ((List<Object>) existing).add(detail);
        } else {
            List<Object> errorList = new ArrayList<>();
            errorList.add(existing);
            errorList.add(detail);
            elementErrors.put(field, errorList);
        }
    }

    /**
     * Error on a simple element inside a list (no sub-field).
     * For List<String> → error on observers[1] or childFolderNumbers[0]
     * Supports multiple errors on the same index.
     */
    @SuppressWarnings("unchecked")
    public void addListElementError(String listName, int index, int listSize,
                                    String code, String message, Object rejectedValue) {
        List<Object> list = getOrCreateList(listName, listSize);
        expandList(list, index);

        Map<String, Object> detail = buildDetail(code, message, rejectedValue);

        Object existing = list.get(index);
        if (existing == null) {
            list.set(index, detail);
        } else if (existing instanceof List) {
            ((List<Object>) existing).add(detail);
        } else {
            List<Object> errorList = new ArrayList<>();
            errorList.add(existing);
            errorList.add(detail);
            list.set(index, errorList);
        }
    }

    /**
     * Error from class-level validation (@ValidDateRange, @CreateFolderRequestValid).
     */
    public void addGlobalError(String objectName, String field, String code, String message) {
        errors.put(field != null ? field : objectName, buildDetail(code, message, null));
    }

    private Map<String, Object> buildDetail(String code, String message, Object rejectedValue) {
        Map<String, Object> detail = new LinkedHashMap<>();
        detail.put("code", code);
        detail.put("message", message);
        if (rejectedValue != null) {
            detail.put("value", rejectedValue.toString());
        }
        return detail;
    }

    @SuppressWarnings("unchecked")
    private List<Object> getOrCreateList(String listName, int listSize) {
        return (List<Object>) errors.computeIfAbsent(listName, _ -> {
            List<Object> list = new ArrayList<>(listSize);
            for (int i = 0; i < listSize; i++) {
                list.add(null);
            }
            return list;
        });
    }

    private void expandList(List<Object> list, int index) {
        while (list.size() <= index) {
            list.add(null);
        }
    }
}
