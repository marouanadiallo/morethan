package lu.pgd.dri.ischia.domain.application.mapper;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.*;
import lu.pgd.dri.ischia.domainapi.response.ChannelReferentialResponse;
import lu.pgd.dri.ischia.domainapi.response.ReferentialCountryResponse;
import lu.pgd.dri.ischia.domainapi.response.ReferentialResponse;
import lu.pgd.dri.ischia.domainapi.response.ReferentialUserUnitResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants.ComponentModel;

@Mapper(componentModel = ComponentModel.SPRING)
public interface ReferentialMapper {

    ReferentialResponse toReferenceResponse(AbstractReferenceEntity reference);

    @Mapping(source = "organization.id", target = "organizationId")
    ReferentialUserUnitResponse toUserUnitResponse(UserUnitEntity userUnit);

    @Mapping(source = "channel.id", target = "channelId")
    ChannelReferentialResponse toChannelReferentialResponse(MessageConfidentialityEntity channel);

    @Mapping(source = "channel.id", target = "channelId")
    ChannelReferentialResponse toChannelReferentialResponse(MessageHandlingCodeEntity channel);

    @Mapping(source = "channel.id", target = "channelId")
    ChannelReferentialResponse toChannelReferentialResponse(MessagePriorityEntity channel);

    @Mapping(source = "channel.id", target = "channelId")
    ChannelReferentialResponse toChannelReferentialResponse(MessageDelayRefEntity channel);

    ReferentialCountryResponse toReferentialCountry(CountryEntity countryEntity);
}
