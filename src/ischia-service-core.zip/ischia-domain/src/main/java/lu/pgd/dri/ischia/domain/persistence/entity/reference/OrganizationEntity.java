package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_ORGANISATION_RO", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_RO_CODE", columnNames = {"code"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RO_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RO_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RO_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RO_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RO_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RO_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RO_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RO_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RO_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RO_VALIDITY_FROM", length = 6))
@Comment("Defines the organization type.")
public class OrganizationEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RO_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the organization.")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_organization_gen")
    @SequenceGenerator(name = "seq_organization_gen",
            sequenceName = "IS_RO_S",
            allocationSize = 20
    )
    private final Long id;

    protected OrganizationEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
