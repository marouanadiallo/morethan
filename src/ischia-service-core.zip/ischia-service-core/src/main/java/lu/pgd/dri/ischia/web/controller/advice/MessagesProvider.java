package lu.pgd.dri.ischia.web.controller.advice;

import org.springframework.context.MessageSource;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Component;

@Component
public class MessagesProvider {
    private final MessageSourceAccessor accessor;

    MessagesProvider(MessageSource messageSource) {
        this.accessor = new MessageSourceAccessor(messageSource);
    }

    public String get(String messageKey, Object... args) {
        return accessor.getMessage(messageKey, args);
    }
}
