package lu.pgd.dri.ischia.web.controller.referential;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lu.pgd.dri.ischia.domain.application.service.referential.UserUnitService;
import lu.pgd.dri.ischia.domainapi.response.ReferentialUserUnitResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/referential/user-unit-types")
public class UserUnitController {

    private final UserUnitService service;

    @GetMapping
    @Tag(name = "Referential - List")
    @Operation(
            description = "Provides the list of data for the reference type",
            responses = {@ApiResponse(responseCode = "200", description = "Successful operation")}
    )
    public ResponseEntity<List<ReferentialUserUnitResponse>> getAll() {
        return ResponseEntity.ok(this.service.getAll());
    }

    @GetMapping("/{id}")
    @Tag(name = "Referential - by ID")
    @Operation(
            description = "Reference type determined by its identifier",
            responses = {@ApiResponse(responseCode = "200", description = "Successful operation")}
    )
    public ResponseEntity<ReferentialUserUnitResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(this.service.getById(id));
    }

    @GetMapping("/code/{code}")
    @Tag(name = "Referential - by code")
    @Operation(
            description = "Reference type determined by its code",
            responses = {@ApiResponse(responseCode = "200", description = "Successful operation")}
    )
    public ResponseEntity<ReferentialUserUnitResponse> getByCode(@PathVariable String code) {
        return ResponseEntity.ok(this.service.getByCode(code));
    }
}
