package lu.pgd.dri.ischia.web.config;

import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.regex.Pattern;

@Configuration
class ApiDocumentationConfigurer {
    Pattern referentialPattern = Pattern.compile("/api/v\\d+/referential.*");

    @Bean
    GroupedOpenApi referencesApi() {
        return GroupedOpenApi.builder()
                .group("API - Reference types")
                .addOpenApiCustomizer(openApi -> openApi.getPaths().entrySet().removeIf(
                        e -> !referentialPattern.matcher(e.getKey()).matches()
                )).build();
    }

    @Bean
    GroupedOpenApi defaultApi() {
        return GroupedOpenApi.builder()
                .group("API - Main")
                .addOpenApiCustomizer(openApi -> openApi.getPaths().entrySet().removeIf(
                        e -> referentialPattern.matcher(e.getKey()).matches()
                )).build();
    }
}
