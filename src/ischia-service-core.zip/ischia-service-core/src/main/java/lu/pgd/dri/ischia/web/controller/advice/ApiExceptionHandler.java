package lu.pgd.dri.ischia.web.controller.advice;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lu.pgd.dri.ischia.domain.application.exception.DomainException;
import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.domain.application.validation.ValidationErrorFactory;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.*;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.io.IOException;
import java.net.SocketException;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collection;
import java.util.regex.Matcher;

import static lu.pgd.dri.ischia.domain.application.validation.ValidationErrorFactory.LIST_FIELD_PATTERN;

@Slf4j
@RestControllerAdvice
@RequiredArgsConstructor
public class ApiExceptionHandler extends ResponseEntityExceptionHandler {

    private final MessagesProvider messages;

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            @NonNull MethodArgumentNotValidException ex,
            @NonNull HttpHeaders headers,
            @NonNull HttpStatusCode status,
            @NonNull WebRequest request) {

        ValidationErrorFactory validationError = ValidationErrorFactory.getInstance();

        ex.getBindingResult().getFieldErrors().forEach(error -> {
            String fullField = error.getField();
            String code = error.getDefaultMessage();
            String message = this.messages.get(code);
            Object rejectedValue = error.getRejectedValue();

            Matcher matcher = LIST_FIELD_PATTERN.matcher(fullField);
            if (matcher.matches()) {
                String listName = matcher.group(1);
                int index = Integer.parseInt(matcher.group(2));
                String subField = matcher.group(3);
                int listSize = getListSize(ex.getBindingResult(), listName);

                if (subField != null) {
                    validationError.addListFieldError(
                            listName, index, listSize,
                            subField, code, message, rejectedValue);
                } else {
                    validationError.addListElementError(
                            listName, index, listSize,
                            code, message, rejectedValue);
                }
            } else {
                validationError.addFieldError(fullField, code, message, rejectedValue);
            }
        });

        ex.getBindingResult().getGlobalErrors().forEach(error -> {
            String code = error.getDefaultMessage();
            String message = this.messages.get(code);
            String field = parseFieldFromCode(code);
            validationError.addGlobalError(error.getObjectName(), field, code, message);
        });

        ex.getBody().setProperty("errors", validationError.getErrors());
        return handleExceptionInternal(ex, null, headers, status, request);
    }

    @ExceptionHandler({DomainException.class})
    ResponseEntity<Object> handleDomainException(DomainException ex, WebRequest request) {
        log.warn("Domain exception : {}", ex.getMessage());
        HttpStatus status = switch (ex) {
            case ResourceNotFoundException _ -> HttpStatus.NOT_FOUND;
            // handle other exception type here
            default -> HttpStatus.BAD_REQUEST;
        };
        ProblemDetail body = createProblemDetail(ex, status, ex.getMessage(),
                ex.getMessageKey(), ex.getMessageArgs(), request);
        return handleExceptionInternal(ex, body, new HttpHeaders(), status, request);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    ResponseEntity<Object> handleDataIntegrityViolation(DataIntegrityViolationException ex, WebRequest request) {
        log.warn("Data integrity violation: {}", ex.getMessage());
        ProblemDetail body = createProblemDetail(ex, HttpStatus.CONFLICT, "Data integrity violation",
                "data.integrity.violation", null, request);
        return handleExceptionInternal(ex, body, new HttpHeaders(), HttpStatus.CONFLICT, request);
    }

    @ExceptionHandler(DataAccessException.class)
    ResponseEntity<Object> handleDataAccessException(DataAccessException ex, WebRequest request) {
        log.error("Data access error: {}", ex.getMessage());
        ProblemDetail body = createProblemDetail(ex, HttpStatus.INTERNAL_SERVER_ERROR, "Unable to access the data",
                "data.access.error", null, request);
        return handleExceptionInternal(ex, body, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }


    @ExceptionHandler(IOException.class)
    ResponseEntity<Object> handleIOException(IOException ex, WebRequest request) {
        // Client disconnected
        if (ex.getClass().getName().contains("ClientAbortException") || ex instanceof SocketException) {
            log.debug("Client disconnected: {}", ex.getMessage());
            return null; // Ignore and just log
        }

        // Other errors during file processing
        log.error("IO error during file processing", ex);
        ProblemDetail body = createProblemDetail(ex, HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while processing the file.",
                "file.processing.error", null, request);
        return handleExceptionInternal(ex, body, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    @ExceptionHandler(Exception.class)
    ResponseEntity<Object> handleUnexpected(Exception ex, WebRequest request) {
        log.error("Unexpected error", ex);

        ProblemDetail body = createProblemDetail(ex, HttpStatus.INTERNAL_SERVER_ERROR,
                "An unexpected error occurred. Please try again later.",
                "internal.server.error", null, request);
        return handleExceptionInternal(ex, body, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }


    @Override
    @NonNull
    protected ResponseEntity<Object> createResponseEntity(
            @Nullable Object body,
            @NonNull HttpHeaders headers,
            @NonNull HttpStatusCode statusCode,
            @NonNull WebRequest request) {

        if (body instanceof ProblemDetail problemDetail) {
            problemDetail.setProperty("timestamp", Instant.now());
        }
        return super.createResponseEntity(body, headers, statusCode, request);
    }

    private String parseFieldFromCode(String code) {
        if (code == null) {
            return null;
        }
        String clean = code.replace("{", "").replace("}", "");
        String[] parts = clean.split("\\.");
        if (parts.length >= 3) {
            return String.join(".", Arrays.copyOfRange(parts, 1, parts.length - 1));
        }
        if (parts.length == 2) {
            return parts[1];
        }
        return null;
    }

    private int getListSize(BindingResult bindingResult, String field) {
        try {
            Object value = bindingResult.getRawFieldValue(field);
            if (value instanceof Collection<?> col) {
                return col.size();
            }
        } catch (Exception _) {
            log.warn("Unable to resolve list size for field {}", field);
        }
        return 0;
    }
}
