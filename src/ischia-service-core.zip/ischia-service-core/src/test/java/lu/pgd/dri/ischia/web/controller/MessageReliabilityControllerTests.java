package lu.pgd.dri.ischia.web.controller;

import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.domain.application.service.referential.MessageReliabilityService;
import lu.pgd.dri.ischia.domainapi.response.ReferentialResponse;
import lu.pgd.dri.ischia.web.controller.advice.MessagesProvider;
import lu.pgd.dri.ischia.web.controller.referential.MessageReliabilityController;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.BDDMockito.given;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = MessageReliabilityController.class)
@ActiveProfiles("test")
@Import(MessagesProvider.class)
class MessageReliabilityControllerTests {

    private static final String URL = "/api/v1/referential/message-reliability-types";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private MessagesProvider messagesProvider;

    @MockitoBean
    private MessageReliabilityService service;

    @Test
    void getAll_shouldReturn200WithList() throws Exception {
        given(service.getAll()).willReturn(List.of(responseByCode("ABC")));

        MockHttpServletRequestBuilder requestBuilder = get(URL).contentType(MediaType.APPLICATION_JSON);

        this.mockMvc.perform(authenticatedRequest(requestBuilder))
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].code").value("ABC"));
    }

    @Test
    void getByCode_shouldReturn200() throws Exception {
        given(service.getByCode("Ref")).willReturn(responseByCode("Ref"));

        MockHttpServletRequestBuilder requestBuilder = get(URL + "/code/{code}", "Ref")
                .contentType(MediaType.APPLICATION_JSON);

        mockMvc.perform(authenticatedRequest(requestBuilder))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("Ref"));
    }

    @Test
    void getById_shouldReturn200() throws Exception {
        given(service.getById(1L)).willReturn(responseById());

        MockHttpServletRequestBuilder requestBuilder = get(URL + "/{id}", 1).contentType(MediaType.APPLICATION_JSON);
        mockMvc.perform(authenticatedRequest(requestBuilder))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value("1"));
    }


    @Test
    void getCode_shouldReturn404WhenNotFound() throws Exception {
        given(service.getByCode("RefM")).willThrow(new ResourceNotFoundException("referential.notfound.byCode", "RefM"));

        MockHttpServletRequestBuilder requestBuilder = get(URL + "/code/{code}", "RefM").contentType(MediaType.APPLICATION_JSON);
        mockMvc.perform(authenticatedRequest(requestBuilder))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.detail").value(this.messagesProvider.get("referential.notfound.byCode", "RefM")));
    }

    @Test
    void getId_shouldReturn404WhenNotFound() throws Exception {
        given(service.getById(1L)).willThrow(new ResourceNotFoundException("referential.notfound.byId", 1L));

        MockHttpServletRequestBuilder requestBuilder = get(URL + "/{id}", "1").contentType(MediaType.APPLICATION_JSON);
        mockMvc.perform(authenticatedRequest(requestBuilder))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.detail").value(this.messagesProvider.get("referential.notfound.byId", 1L)));
    }

    private ReferentialResponse responseByCode(String code) {
        return new ReferentialResponse(1L, code, "Label Fr", "Label En", "Label De", null, null);
    }

    private ReferentialResponse responseById() {
        return new ReferentialResponse(1L, "Ref", "Label Fr", "Label En", "Label De", null, null);
    }

    private RequestBuilder authenticatedRequest(MockHttpServletRequestBuilder requestBuilder) {
        return requestBuilder
                .with(jwt().jwt(
                        jwt -> jwt.subject("xac7865").claim("preferred_username", "xac7865")
                ));
    }
}
