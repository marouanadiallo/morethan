package lu.pgd.dri.ischia.web.controller;

import lu.pgd.dri.ischia.domain.application.service.referential.MessageReliabilityService;
import lu.pgd.dri.ischia.domainapi.response.ReferentialResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.transaction.annotation.Transactional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT
)
@ActiveProfiles("test")
@Transactional // rollback after each test
@Sql("/sql/message-reliability.sql")
class ReferentialIT {

    @Autowired
    private MessageReliabilityService messageReliabilityService;
    // other referential services

    @Test
    void getAll_shouldReturnOnlyValidReference() {
        assertThat(messageReliabilityService.getAll())
                .extracting(ReferentialResponse::code)
                .containsExactly("VALID");
    }

    // other tests
}
