package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractChannelReferentialService;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Named.named;
import static org.junit.jupiter.params.provider.Arguments.arguments;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.mock;

/**
 * Each channel-scoped service must use its own repository, with and without channel filter.
 */
class ChannelReferentialServiceWiringTests {

    private static final long CHANNEL_ID = 3L;

    static Stream<Arguments> services() {
        ReferentialMapper mapper = mock(ReferentialMapper.class);

        var crimeAreaRepo = mock(CrimeAreaRepository.class);
        var confidentialityRepo = mock(MessageConfidentialityRepository.class);
        var handlingCodeRepo = mock(MessageHandlingCodeRepository.class);
        var priorityRepo = mock(MessagePriorityRepository.class);
        var reliabilityRepo = mock(MessageReliabilityRepository.class);

        return Stream.of(
                arguments(named("CrimeAreaService", new CrimeAreaService(mapper, crimeAreaRepo)), crimeAreaRepo),
                arguments(named("MessageConfidentialityService", new MessageConfidentialityService(mapper, confidentialityRepo)), confidentialityRepo),
                arguments(named("MessageHandlingCodeService", new MessageHandlingCodeService(mapper, handlingCodeRepo)), handlingCodeRepo),
                arguments(named("MessagePriorityService", new MessagePriorityService(mapper, priorityRepo)), priorityRepo),
                arguments(named("MessageReliabilityService", new MessageReliabilityService(mapper, reliabilityRepo)), reliabilityRepo)
        );
    }

    @ParameterizedTest(name = "{0} - all channels")
    @MethodSource("services")
    void withoutChannelShouldUseItsOwnRepository(AbstractChannelReferentialService<?> service,
                                                 ChannelReferenceBaseRepository<?> repository) {
        assertThat(service.getAll(null)).isEmpty();
        then(repository).should().findValidateReferences();
    }

    @ParameterizedTest(name = "{0} - one channel")
    @MethodSource("services")
    void withChannelShouldUseItsOwnRepository(AbstractChannelReferentialService<?> service,
                                              ChannelReferenceBaseRepository<?> repository) {
        assertThat(service.getAll(CHANNEL_ID)).isEmpty();
        then(repository).should().findValidateReferencesByChannelId(CHANNEL_ID);
    }
}
