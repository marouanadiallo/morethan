package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.CountryEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.CountryRepository;
import lu.pgd.dri.ischia.domainapi.response.ReferentialCountryResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

@ExtendWith(MockitoExtension.class)
class CountryServiceTests {

    @Mock
    private CountryRepository repository;
    @Mock
    private ReferentialMapper mapper;

    private CountryService service;

    @Mock
    private CountryEntity country;
    @Mock
    private ReferentialCountryResponse countryResponse;

    @BeforeEach
    void setUp() {
        this.service = new CountryService(mapper, repository);
    }

    @Nested
    @DisplayName("Find all countries - unit tests")
    class FindAllTests {
        @Test
        void shouldReturnMappedReferences() {
            given(repository.findValidateCountries()).willReturn(List.of(country));
            given(mapper.toReferentialCountry(country)).willReturn(countryResponse);

            assertThat(service.getAll()).containsExactly(countryResponse);
        }

        @Test
        void shouldReturnEmptyListWhenNoReferencesAreFound() {
            given(repository.findValidateCountries()).willReturn(List.of());

            assertThat(service.getAll()).isEmpty();
            then(mapper).shouldHaveNoInteractions();
        }
    }

    @Nested
    @DisplayName("Get country by id - unit tests")
    class GetByIdTests {
        @Test
        void shouldReturnMappedReferenceWhenFound() {
            given(repository.findById(1L)).willReturn(Optional.of(country));
            given(mapper.toReferentialCountry(country)).willReturn(countryResponse);

            assertThat(service.getById(1L)).isEqualTo(countryResponse);
        }

        @Test
        void shouldThrowExceptionWhenNotFound() {
            given(repository.findById(1L)).willReturn(Optional.empty());

            assertThatThrownBy(() -> service.getById(1L)).isInstanceOf(ResourceNotFoundException.class);
            then(mapper).shouldHaveNoInteractions();
        }
    }

    @Nested
    @DisplayName("Get country by alphacode2 or alphacode3 - unit tests")
    class GetByCode {
        @Test
        void shouldThrowExceptionWhenNotFound() {
            given(repository.findByAlphacode2OrAlphacode3IgnoreCase(anyString())).willReturn(Optional.empty());
            assertThatThrownBy(() -> service.getByCode("RefCode")).isInstanceOf(ResourceNotFoundException.class);
            then(mapper).shouldHaveNoInteractions();
        }

        @Test
        void shouldThrowExceptionWhenCodeIsNullOrEmpty() {
            assertThatThrownBy(() -> service.getByCode("")).isInstanceOf(ResourceNotFoundException.class);
            assertThatThrownBy(() -> service.getByCode(null)).isInstanceOf(ResourceNotFoundException.class);

            then(repository).shouldHaveNoInteractions();
            then(mapper).shouldHaveNoInteractions();
        }

        @Test
        void shouldReturnMappedCountryWhenFound() {
            given(repository.findByAlphacode2OrAlphacode3IgnoreCase(anyString())).willReturn(Optional.of(country));
            given(mapper.toReferentialCountry(country)).willReturn(countryResponse);

            assertThat(service.getByCode("RefCode")).isEqualTo(countryResponse);
        }
    }
}
