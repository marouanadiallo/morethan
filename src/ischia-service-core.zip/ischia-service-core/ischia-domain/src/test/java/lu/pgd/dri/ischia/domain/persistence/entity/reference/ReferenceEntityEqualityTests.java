package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static lu.pgd.dri.ischia.domain.testsupport.TestEntities.newEntity;
import static lu.pgd.dri.ischia.domain.testsupport.TestEntities.reference;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNoException;

class ReferenceEntityEqualityTests {

    @Nested
    class AbstractReference {

        @Test
        void sameCodeSameTypeAreEqual() {
            var a = reference(MessageTypeEntity.class, 1L, "MAIL");
            var b = reference(MessageTypeEntity.class, 2L, "MAIL");

            assertThat(a).isEqualTo(b).hasSameHashCodeAs(b);
        }

        @Test
        void differentCodesAreNotEqual() {
            assertThat(reference(MessageTypeEntity.class, 1L, "MAIL"))
                    .isNotEqualTo(reference(MessageTypeEntity.class, 1L, "FAX"));
        }

        @Test
        void sameCodeDifferentTypesAreNotEqual() {
            assertThat(reference(MessageTypeEntity.class, 1L, "X"))
                    .isNotEqualTo(reference(MessageStatusEntity.class, 1L, "X"));
        }

        @Test
        void withoutCodeNoNullPointerAndOnlyEqualToItself() {
            var a = newEntity(MessageTypeEntity.class, null);
            var b = newEntity(MessageTypeEntity.class, null);

            assertThatNoException().isThrownBy(a::hashCode);
            assertThat(a).isEqualTo(a).isNotEqualTo(b);
        }

        @Test
        void canBeUsedInHashSet() {
            Set<MessageTypeEntity> set = new HashSet<>();
            set.add(reference(MessageTypeEntity.class, 1L, "MAIL"));
            set.add(reference(MessageTypeEntity.class, 2L, "MAIL"));

            assertThat(set).hasSize(1);
        }

        @Test
        void notEqualToNull() {
            assertThat(reference(MessageTypeEntity.class, 1L, "MAIL")).isNotEqualTo(null);
        }
    }

    @Nested
    class Country {

        private CountryEntity country(String alpha2, String alpha3) {
            CountryEntity country = newEntity(CountryEntity.class, 1L);
            country.setAlphacode2(alpha2);
            country.setAlphacode3(alpha3);
            return country;
        }

        @Test
        void sameAlphaCodesAreEqual() {
            assertThat(country("LU", "LUX")).isEqualTo(country("LU", "LUX")).hasSameHashCodeAs(country("LU", "LUX"));
        }

        @Test
        void differentAlphaCodesAreNotEqual() {
            assertThat(country("LU", "LUX")).isNotEqualTo(country("FR", "FRA"));
        }

        @Test
        void withoutAlphaCodesNoNullPointerAndOnlyEqualToItself() {
            CountryEntity a = country(null, null);

            assertThatNoException().isThrownBy(a::hashCode);
            assertThat(a).isEqualTo(a).isNotEqualTo(country(null, null));
        }
    }
}
