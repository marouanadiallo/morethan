package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Named.named;
import static org.junit.jupiter.params.provider.Arguments.arguments;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.mock;

/**
 * To ensure proper coverage,
 * we verify here that the reference-type services are correctly instantiated
 * with their respective repositories.
 * <br>
 * Channel-scoped services (CrimeArea, MessageConfidentiality, MessageHandlingCode, MessagePriority,
 * MessageReliability) are covered by {@link ChannelReferentialServiceWiringTests}.
 */
class ReferentialServiceWiringTests {

    static Stream<Arguments> services() {
        ReferentialMapper mapper = mock(ReferentialMapper.class);

        var channelRepo = mock(ChannelRepository.class);
        var messageTypeRepo = mock(MessageTypeRepository.class);
        var nationalityRepo = mock(NationalityRepository.class);
        var organizationRepo = mock(OrganizationRepository.class);
        var messageStatusRepo = mock(MessageStatusRepository.class);
        var messageDelayRefRepo = mock(MessageDelayRefRepository.class);
        var documentCategoryRepo = mock(DocumentCategoryRepository.class);
        var unitOrganizationRepo = mock(UnitOrganizationRepository.class);

        return Stream.of(
                arguments(named("ChannelService", new ChannelService(mapper, channelRepo)), channelRepo),
                arguments(named("MessageTypeService", new MessageTypeService(mapper, messageTypeRepo)), messageTypeRepo),
                arguments(named("NationalityService", new NationalityService(mapper, nationalityRepo)), nationalityRepo),
                arguments(named("OrganizationService", new OrganizationService(mapper, organizationRepo)), organizationRepo),
                arguments(named("MessageStatusService", new MessageStatusService(mapper, messageStatusRepo)), messageStatusRepo),
                arguments(named("MessageDelayRefService", new MessageDelayRefService(mapper, messageDelayRefRepo)), messageDelayRefRepo),
                arguments(named("UnitOrganizationService", new UnitOrganizationService(mapper, unitOrganizationRepo)), unitOrganizationRepo),
                arguments(named("DocumentCategoryService", new DocumentCategoryService(mapper, documentCategoryRepo)), documentCategoryRepo)
        );
    }

    @ParameterizedTest(name = "{0}")
    @MethodSource("services")
    void shouldUseItsOwnRepository(AbstractReferentialService<?> service, ReferenceBaseRepository<?> repository) {
        assertThat(service.getAll()).isEmpty();
        then(repository).should().findValidateReferences();
    }
}
