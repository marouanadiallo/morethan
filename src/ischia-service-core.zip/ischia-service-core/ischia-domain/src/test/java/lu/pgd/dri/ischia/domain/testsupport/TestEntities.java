package lu.pgd.dri.ischia.domain.testsupport;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.AbstractReferenceEntity;
import org.springframework.beans.BeanUtils;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDate;

/**
 * Builds real entity instances in unit tests.
 * Entity constructors are protected and ids are final (set by Hibernate): reflection is used, as Hibernate does.
 */
public final class TestEntities {

    private TestEntities() {
    }

    public static <T> T newEntity(Class<T> type, Long id) {
        T entity = BeanUtils.instantiateClass(type);
        ReflectionTestUtils.setField(entity, "id", id);
        return entity;
    }

    public static <T extends AbstractReferenceEntity> T reference(Class<T> type, Long id, String code) {
        T entity = newEntity(type, id);
        entity.setCode(code);
        entity.setLabelFr(code + " fr");
        entity.setLabelEn(code + " en");
        entity.setLabelDe(code + " de");
        entity.setValidityFrom(LocalDate.of(2020, 1, 1));
        entity.setValidityTo(LocalDate.of(2099, 12, 31));
        return entity;
    }
}
