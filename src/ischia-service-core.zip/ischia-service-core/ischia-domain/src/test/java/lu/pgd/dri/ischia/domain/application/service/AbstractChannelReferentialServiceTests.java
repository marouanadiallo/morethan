package lu.pgd.dri.ischia.domain.application.service;

import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.referential.MessagePriorityService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessagePriorityEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.MessagePriorityRepository;
import lu.pgd.dri.ischia.domainapi.response.ChannelReferentialResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.never;

/**
 * Logic of {@link AbstractChannelReferentialService}, tested through one concrete service: MessagePriorityService.
 * The wiring of the other channel services is checked by ChannelReferentialServiceWiringTests.
 */
@ExtendWith(MockitoExtension.class)
class AbstractChannelReferentialServiceTests {

    private static final long CHANNEL_ID = 7L;

    @Mock
    private ReferentialMapper mapper;
    @Mock
    private MessagePriorityRepository repository;
    @Mock
    private MessagePriorityEntity entity;
    @Mock
    private ChannelReferentialResponse response;

    private MessagePriorityService service;

    @BeforeEach
    void setup() {
        service = new MessagePriorityService(mapper, repository);
    }

    @Nested
    @DisplayName("Find all references - unit tests")
    class FindAllTests {

        @Test
        void withoutChannelShouldReturnAllValidReferences() {
            given(repository.findValidateReferences()).willReturn(List.of(entity));
            given(mapper.toChannelReferentialResponse(entity)).willReturn(response);

            assertThat(service.getAll(null)).containsExactly(response);
            then(repository).should().findValidateReferences();
            then(repository).should(never()).findValidateReferencesByChannelId(anyLong());
        }

        @Test
        void withChannelShouldFilterOnChannel() {
            given(repository.findValidateReferencesByChannelId(CHANNEL_ID)).willReturn(List.of(entity));
            given(mapper.toChannelReferentialResponse(entity)).willReturn(response);

            assertThat(service.getAll(CHANNEL_ID)).containsExactly(response);
            then(repository).should(never()).findValidateReferences();
        }

        @Test
        void shouldReturnEmptyListWhenNothingIsFound() {
            given(repository.findValidateReferencesByChannelId(CHANNEL_ID)).willReturn(List.of());

            assertThat(service.getAll(CHANNEL_ID)).isEmpty();
            then(mapper).shouldHaveNoInteractions();
        }
    }

    @Nested
    @DisplayName("Get reference by id - unit tests")
    class GetByIdTests {

        @Test
        void shouldReturnMappedReferenceWhenFound() {
            given(repository.findById(1L)).willReturn(Optional.of(entity));
            given(mapper.toChannelReferentialResponse(entity)).willReturn(response);

            assertThat(service.getById(1L)).isEqualTo(response);
        }

        @Test
        void shouldThrowExceptionWhenNotFound() {
            given(repository.findById(1L)).willReturn(Optional.empty());

            assertThatThrownBy(() -> service.getById(1L))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .extracting("messageKey").isEqualTo("referential.notfound.byId");
            then(mapper).shouldHaveNoInteractions();
        }
    }

    @Nested
    @DisplayName("Get reference by code - unit tests")
    class GetByCodeTests {

        @Test
        void shouldReturnMappedReferenceWhenFound() {
            given(repository.findByCodeIgnoreCase(anyString())).willReturn(Optional.of(entity));
            given(mapper.toChannelReferentialResponse(any(MessagePriorityEntity.class))).willReturn(response);

            assertThat(service.getByCode("HIGH")).isEqualTo(response);
        }

        @Test
        void shouldThrowExceptionWhenNotFound() {
            given(repository.findByCodeIgnoreCase(anyString())).willReturn(Optional.empty());

            assertThatThrownBy(() -> service.getByCode("UNKNOWN"))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .extracting("messageKey").isEqualTo("referential.notfound.byCode");
            then(mapper).shouldHaveNoInteractions();
        }
    }
}
