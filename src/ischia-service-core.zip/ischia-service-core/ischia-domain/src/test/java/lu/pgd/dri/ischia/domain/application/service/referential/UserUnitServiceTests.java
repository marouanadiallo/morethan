package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.UserUnitEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.UserUnitRepository;
import lu.pgd.dri.ischia.domainapi.response.ReferentialUserUnitResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

@ExtendWith(MockitoExtension.class)
class UserUnitServiceTests {

    @Mock
    private ReferentialMapper mapper;

    @Mock
    private UserUnitRepository repository;

    @Mock
    private UserUnitEntity userUnit;

    @Mock
    private ReferentialUserUnitResponse userUnitResponse;

    private UserUnitService service;

    @BeforeEach
    void setUp() {
        service = new UserUnitService(mapper, repository);
    }

    @Nested
    @DisplayName("Find all unit of user - unit tests")
    class FindAllTests {

        @Test
        void shouldReturnMappedReferences() {
            given(repository.findValidateReferences()).willReturn(List.of(userUnit));
            given(mapper.toUserUnitResponse(userUnit)).willReturn(userUnitResponse);

            assertThat(service.getAll()).containsExactly(userUnitResponse);
        }

        @Test
        void shouldReturnEmptyListWhenNoReferencesAreFound() {
            given(repository.findValidateReferences()).willReturn(List.of());

            assertThat(service.getAll()).isEmpty();
            then(mapper).shouldHaveNoInteractions();
        }

    }

    @Nested
    @DisplayName("Get reference by id - unit tests")
    class GetByIdTests {

        @Test
        void shouldReturnMappedReferenceWhenFound() {
            given(repository.findById(1L)).willReturn(Optional.of(userUnit));
            given(mapper.toUserUnitResponse(userUnit)).willReturn(userUnitResponse);

            assertThat(service.getById(1L)).isEqualTo(userUnitResponse);
        }

        @Test
        void shouldThrowExceptionWhenNotFound() {
            given(repository.findById(1L)).willReturn(Optional.empty());

            assertThatThrownBy(() -> service.getById(1L)).isInstanceOf(ResourceNotFoundException.class);
            then(mapper).shouldHaveNoInteractions();
        }
    }

    @Nested
    @DisplayName("Get reference by code - unit tests")
    class GetByCodeTests {

        @Test
        void shouldReturnMappedReferenceWhenFound() {
            given(repository.findByCodeIgnoreCase(anyString())).willReturn(Optional.of(userUnit));
            given(mapper.toUserUnitResponse(userUnit)).willReturn(userUnitResponse);

            assertThat(service.getByCode("RefCode")).isEqualTo(userUnitResponse);
        }

        @Test
        void shouldThrowExceptionWhenNotFound() {
            given(repository.findByCodeIgnoreCase(anyString())).willReturn(Optional.empty());
            assertThatThrownBy(() -> service.getByCode("RefCode")).isInstanceOf(ResourceNotFoundException.class);
            then(mapper).shouldHaveNoInteractions();
        }
    }

}
