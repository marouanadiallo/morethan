package lu.pgd.dri.ischia.domain.application.enums;

import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

@Slf4j
public enum MessageAssignmentRole {

    RESPONSIBLE("RESPONSIBLE"),
    CONTRIBUTOR("CONTRIBUTOR");

    private final String role;

    MessageAssignmentRole(String value) {
        this.role = value;
    }

    public static Optional<MessageAssignmentRole> fromString(String value) {
        try {
            return Optional.of(MessageAssignmentRole.valueOf(value));
        } catch (IllegalArgumentException e) {
            log.info("invalid role '{}', error={} ", value, e.getMessage());
            return Optional.empty();
        }
    }

    public String role() {
        return role;
    }
}
