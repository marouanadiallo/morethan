package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_PHYSICAL_PERSON_PP")
@AttributeOverride(name = "updatedAt", column = @Column(name = "PP_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "PP_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "PP_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "PP_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class PhysicalPersonEntity extends Auditable {

    @Id
    @Column(name = "PP_ID", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_physical_person_gen"
    )
    @SequenceGenerator(name = "seq_physical_person_gen",
            sequenceName = "IS_PP_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_PP_MSG_ID"))
    @Comment("")
    private MessageEntity message;

    protected PhysicalPersonEntity() {
        this.id = null;
    }

    public static PhysicalPersonEntity of(MessageEntity message) {
        PhysicalPersonEntity entity = new PhysicalPersonEntity();
        entity.setMessage(message);
        return entity;
    }
}
