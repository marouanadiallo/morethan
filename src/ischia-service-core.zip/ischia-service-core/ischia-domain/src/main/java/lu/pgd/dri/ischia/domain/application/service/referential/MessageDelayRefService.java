package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageDelayRefEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.MessageDelayRefRepository;
import org.springframework.stereotype.Service;

@Service
public class MessageDelayRefService extends AbstractReferentialService<MessageDelayRefEntity> {
    public MessageDelayRefService(ReferentialMapper referentialMapper, MessageDelayRefRepository repository) {
        super(referentialMapper, repository);
    }
}
