package lu.pgd.dri.ischia.domain.application.exception;

public class ResourceNotFoundException extends DomainException {
    public ResourceNotFoundException(String messageKey, Object... args) {
        super(messageKey, args);
    }
}