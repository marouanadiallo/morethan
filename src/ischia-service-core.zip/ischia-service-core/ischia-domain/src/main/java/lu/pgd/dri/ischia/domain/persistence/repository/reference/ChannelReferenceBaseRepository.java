package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.AbstractReferenceEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Reference types that belong to a channel (column RCH_ID, attribute {@code channel}).
 * <br>
 * Every entity of a repository extending this interface MUST have a {@code channel} attribute,
 * otherwise the query below fails at startup.
 */
@NoRepositoryBean
public interface ChannelReferenceBaseRepository<E extends AbstractReferenceEntity> extends ReferenceBaseRepository<E> {

    @Query("""
            SELECT e
            FROM #{#entityName} e
            WHERE e.channel.id = :channelId
            AND (e.validityFrom IS NULL OR e.validityFrom <= :#{datez.today()})
            AND (e.validityTo IS NULL OR e.validityTo >= :#{datez.today()})
            """)
    List<E> findValidateReferencesByChannelId(@Param("channelId") Long channelId);
}
