package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.application.enums.CecimaIdentityGroupMatches;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_CECIMA_GROUP_CEG")
@AttributeOverride(name = "updatedAt", column = @Column(name = "CEG_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "CEG_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "CEG_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "CEG_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class CecimaIdentityGroupEntity extends Auditable {

    @Id
    @Column(name = "CEG_ID", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_cecima_identity_group_gen"
    )
    @SequenceGenerator(name = "seq_cecima_identity_group_gen",
            sequenceName = "IS_CEG_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @Column(name = "CEG_CECIMA_GROUP_ID")
    private Long cecimaGroupId;

    @Setter
    @Column(name = "CEG_GROUP_MATCHES")
    @Enumerated(EnumType.STRING)
    private CecimaIdentityGroupMatches matches;

    protected CecimaIdentityGroupEntity() {
        this.id = null;
    }

    public static CecimaIdentityGroupEntity of(Long cecimaGroupId, CecimaIdentityGroupMatches matches) {
        CecimaIdentityGroupEntity entity = new CecimaIdentityGroupEntity();
        entity.setCecimaGroupId(cecimaGroupId);
        entity.setMatches(matches);
        return entity;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass())
            return false;

        CecimaIdentityGroupEntity that = (CecimaIdentityGroupEntity) o;
        return cecimaGroupId.equals(that.cecimaGroupId);
    }

    @Override
    public int hashCode() {
        return cecimaGroupId.hashCode();
    }
}
