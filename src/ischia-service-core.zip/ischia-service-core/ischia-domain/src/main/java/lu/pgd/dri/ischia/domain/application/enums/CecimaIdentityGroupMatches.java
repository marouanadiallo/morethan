package lu.pgd.dri.ischia.domain.application.enums;

import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

@Slf4j
public enum CecimaIdentityGroupMatches {

    YES("OUI"),
    NO("NON"),
    MAYBE("PEUT-ÊTRE");

    private final String value;

    CecimaIdentityGroupMatches(String value) {
        this.value = value;
    }

    public static Optional<CecimaIdentityGroupMatches> fromValue(String value) {
        try {
            return Optional.of(CecimaIdentityGroupMatches.valueOf(value));
        } catch (IllegalArgumentException e) {
            log.error("Invalid value for CecimaGroupMatches: '{}', error={}", value, e.getMessage());
            return Optional.empty();
        }
    }

    public String value() {
        return value;
    }
}
