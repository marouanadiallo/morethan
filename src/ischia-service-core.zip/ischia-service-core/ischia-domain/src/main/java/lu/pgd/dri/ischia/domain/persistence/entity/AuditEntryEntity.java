package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

import java.time.Instant;

@Getter
@Entity
@Table(name = "IS_AUDIT_ENTRY_AE")
@Comment("Stores inbound REST API audit events for ischia-service requests")
public class AuditEntryEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sq_audit_entry_generator")
    @SequenceGenerator(name = "sq_audit_entry_generator",
            sequenceName = "IS_AE_S",
            allocationSize = 20
    )
    @Column(name = "AE_ID", updatable = false, nullable = false)
    @Comment("Technical identifier of the audit entry")
    private final Long id;

    @Setter
    @Column(name = "AE_TRACE_ID", nullable = false, length = 64)
    @Comment("Trace identifier propagated across the request flow using the x-b3-trace-id header")
    private String traceId;

    @Setter
    @Column(name = "AE_USER_ID", nullable = false)
    @Comment("Authenticated user identifier propagated from the preferred_username JWT property")
    private String userId;

    @Setter
    @Column(name = "AE_STATUS", length = 3)
    @Comment("HTTP response status code returned by saga-service")
    private String status;

    @Setter
    @Column(name = "AE_ACTION", nullable = false, length = 10)
    @Comment("HTTP method used for the audited request")
    private String action;

    @Setter
    @Column(name = "AE_URL", nullable = false, length = 2000)
    @Comment("Full request URL including query string when present")
    private String url;

    @Lob
    @Setter
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "AE_REQ_BODY")
    @Comment("Request body captured for JSON payloads after masking configured sensitive fields")
    private String requestBody;

    @Setter
    @Column(name = "AE_HEADERS", length = 4000)
    @Comment("Formatted request headers excluding the Authorization header")
    private String headers;

    @Setter
    @Column(name = "AE_START_DATE", nullable = false)
    @Comment("Timestamp when request processing started in saga-service")
    private Instant startDate;

    @Setter
    @Column(name = "AE_END_DATE")
    @Comment("Timestamp when request processing ended in saga-service")
    private Instant endDate;

    @Setter
    @Column(name = "AE_ORIGIN_APP")
    @Comment("Caller application propagated by dri-starter-log using the x-sender header")
    private String originApp;

    protected AuditEntryEntity() {
        this.id = null;
    }

    /**
     * Construct whit required fields
     */
    public static AuditEntryEntity of(String traceId, String userId, String action, Instant startDate) {
        AuditEntryEntity ae = new AuditEntryEntity();
        ae.setTraceId(traceId);
        ae.setUserId(userId);
        ae.setAction(action);
        ae.setStartDate(startDate);
        return ae;
    }
}
