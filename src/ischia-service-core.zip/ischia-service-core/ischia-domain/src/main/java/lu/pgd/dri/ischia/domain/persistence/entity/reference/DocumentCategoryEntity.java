package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_DOCUMENT_CATEGORY_RDC", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_RDC_ID", columnNames = {"RDC_CODE"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RDC_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RDC_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RDC_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RDC_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RDC_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RDC_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RDC_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RDC_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RDC_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RDC_VALIDITY_FROM", length = 6))
@Comment("Defines the document category type.")
public class DocumentCategoryEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RDC_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the document category.")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_document_category_gen"
    )
    @SequenceGenerator(name = "seq_document_category_gen",
            sequenceName = "IS_RDC_S",
            allocationSize = 20
    )
    private final Long id;

    protected DocumentCategoryEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
