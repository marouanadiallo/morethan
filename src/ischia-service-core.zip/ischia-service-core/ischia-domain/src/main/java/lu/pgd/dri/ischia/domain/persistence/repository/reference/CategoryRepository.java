package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.CategoryEntity;

public interface CategoryRepository extends ReferenceBaseRepository<CategoryEntity> {
}
