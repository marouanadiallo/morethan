package lu.pgd.dri.ischia.domain.persistence.repository;

import lu.pgd.dri.ischia.domain.persistence.entity.MessageCommentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageCommentRepository extends JpaRepository<MessageCommentEntity, Long> {
}
