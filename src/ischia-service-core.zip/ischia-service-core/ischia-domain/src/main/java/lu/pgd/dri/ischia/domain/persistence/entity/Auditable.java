package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.EntityListeners;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;

@Getter @Setter
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public abstract class Auditable {

    @CreatedDate
    @Comment("Timestamp when the record was created")
    private Instant createdAt;

    @LastModifiedDate
    @Comment("Timestamp of the last update")
    private Instant updatedAt;

    @CreatedBy
    @Comment("Identifier of the user who created the record")
    private String createdBy;

    @LastModifiedBy
    @Comment("Identifier of the user who last updated the record")
    private String updatedBy;

    protected Auditable() {}
}
