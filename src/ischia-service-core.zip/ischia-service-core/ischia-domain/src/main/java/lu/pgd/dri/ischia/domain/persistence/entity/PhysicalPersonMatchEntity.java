package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Comment;

@Entity
@Getter
@Table(name = "IS_PHYSICAL_PERSON_MATCH_PPM")
@AttributeOverride(name = "updatedAt", column = @Column(name = "PPM_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "PPM_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "PPM_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "PPM_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class PhysicalPersonMatchEntity extends Auditable {

    @Id
    @Column(name = "PPM_ID", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_physical_person_match_gen"
    )
    @SequenceGenerator(name = "seq_physical_person_match_gen",
            sequenceName = "IS_PPM_S",
            allocationSize = 20
    )
    private final Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "SGF_ID", foreignKey = @ForeignKey(name = "C_FK_PPM_SGF_ID"))
    @Comment("")
    private final SagaFolderEntity sagaFolder;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "PPA_ID", foreignKey = @ForeignKey(name = "C_FK_PPM_PPA_ID"))
    @Comment("")
    private final PhysicalPersonAliasEntity physicalPersonAlias;

    @SuppressWarnings("unused")
    protected PhysicalPersonMatchEntity() {
        this.id = null;
        this.sagaFolder = null;
        this.physicalPersonAlias = null;
    }

    public PhysicalPersonMatchEntity(SagaFolderEntity sagaFolder, PhysicalPersonAliasEntity physicalPersonAlias) {
        this.id = null;
        this.sagaFolder = sagaFolder;
        this.physicalPersonAlias = physicalPersonAlias;
    }
}
