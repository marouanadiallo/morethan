package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_IDENTITY_CECIMA_IDC")
@AttributeOverride(name = "updatedAt", column = @Column(name = "IDC_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "IDC_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "IDC_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "IDC_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class IdentityCecimaEntity extends Auditable {

    @Id
    @Column(name = "IDC_ID", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_identity_cecima_gen"
    )
    @SequenceGenerator(name = "seq_identity_cecima_gen",
            sequenceName = "IS_IDC_S",
            allocationSize = 20
    )
    private final Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "CEG_ID", foreignKey = @ForeignKey(name = "C_FK_IDC_CEG_ID"))
    @Comment("")
    private final CecimaIdentityGroupEntity identityGroup;

    @Setter
    @Column(name = "IDC_CECIMA_IDENTITY_ID")
    @Comment("")
    private Long cecimaIdentityId;

    @Setter
    @Column(name = "IDC_REVISION_ID")
    @Comment("")
    private Long revisionId;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "SGF_ID", foreignKey = @ForeignKey(name = "C_FK_IDC_SGF_ID"))
    @Comment("")
    private SagaFolderEntity sagaFolder;

    @SuppressWarnings("unused")
    protected IdentityCecimaEntity() {
        this.id = null;
        this.identityGroup = null;
    }

    public IdentityCecimaEntity(CecimaIdentityGroupEntity identityGroup, SagaFolderEntity sagaFolder) {
        this.id = null;
        this.identityGroup = identityGroup;
        this.sagaFolder = sagaFolder;
    }
}
