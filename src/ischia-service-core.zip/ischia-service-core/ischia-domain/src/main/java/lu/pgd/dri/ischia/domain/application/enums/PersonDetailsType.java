package lu.pgd.dri.ischia.domain.application.enums;

public enum PersonDetailsType {
    PRINCIPAL("PRINCIPAL"),
    ALIAS("ALIAS");

    private final String type;

    PersonDetailsType(String type) {
        this.type = type;
    }

    public String type() {
        return type;
    }
}
