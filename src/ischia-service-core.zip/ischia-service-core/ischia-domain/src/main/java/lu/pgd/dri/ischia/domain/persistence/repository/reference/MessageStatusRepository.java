package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageStatusEntity;

public interface MessageStatusRepository extends  ReferenceBaseRepository<MessageStatusEntity> {
}
