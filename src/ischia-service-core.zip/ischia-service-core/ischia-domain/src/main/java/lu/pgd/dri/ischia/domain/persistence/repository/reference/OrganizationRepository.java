package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.OrganizationEntity;

public interface OrganizationRepository extends ReferenceBaseRepository<OrganizationEntity> {
}
