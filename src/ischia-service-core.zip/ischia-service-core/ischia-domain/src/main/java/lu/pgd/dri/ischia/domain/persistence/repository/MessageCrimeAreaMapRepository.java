package lu.pgd.dri.ischia.domain.persistence.repository;

import lu.pgd.dri.ischia.domain.persistence.entity.MessageCrimeAreaMapEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageCrimeAreaMapRepository extends JpaRepository<MessageCrimeAreaMapEntity, Long> {
}
