package lu.pgd.dri.ischia.domain.application.enums;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum SagaFolderType {
    ADMINISTRATIVE("ADMINISTRATIVE"),
    JUDICIAL("JUDICIAL");

    private final String value;

    SagaFolderType(String value) {
        this.value = value;
    }


    public String value() {
        return value;
    }
}
