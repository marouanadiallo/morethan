package lu.pgd.dri.ischia.domain.application.service.impl;

import lombok.RequiredArgsConstructor;
import lu.pgd.dri.ischia.domain.application.service.MessageService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
class MessageServiceImp implements MessageService {
}
