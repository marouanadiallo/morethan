package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

import java.time.Instant;

@Getter
@AllArgsConstructor
@Entity
@Table(name = "IS_VEHICLE_VE")
@AttributeOverride(name = "updatedAt", column = @Column(name = "VE_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "VE_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "VE_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "VE_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class VehicleEntity extends Auditable {

    @Id
    @Column(name = "VE_ID", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_vehicle_gen")
    @SequenceGenerator(name = "seq_vehicle_gen", sequenceName = "IS_VE_S", allocationSize = 20)
    private final Long id;

    @Setter
    @Column(name = "VE_LICENCE_PLATE", length = 50)
    @Comment("")
    private String licencePlate;

    @Setter
    @Column(name = "VE_HULL", length = 50)
    @Comment("")
    private String hull;

    @Setter
    @Column(name = "VE_COUNTRY", length = 50)
    @Comment("")
    private String country;

    @Column(name = "VE_FIRST_REGISTRATION_DATE")
    private Instant firstRegistrationDate;

    @Setter
    @Column(name = "VE_CATEGORY", length = 50)
    @Comment("")
    private String category;

    @Setter
    @Column(name = "VE_COLOR", length = 50)
    @Comment("")
    private String color;

    @Setter
    @Column(name = "VE_BRAND", length = 50)
    @Comment("")
    private String brand;

    @Setter
    @Column(name = "VE_MODEL", length = 50)
    @Comment("")
    private String model;

    @Setter
    @Column(name = "VE_REMARKS", length = 2000)
    @Comment("")
    private String remarks;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_VE_MSG_ID"))
    @Comment("")
    private MessageEntity message;

    protected VehicleEntity() {
        this.id = null;
    }

    public static VehicleEntity of(String model, MessageEntity message) {
        VehicleEntity entity = new VehicleEntity();
        entity.setModel(model);
        entity.setMessage(message);
        return entity;
    }
}
