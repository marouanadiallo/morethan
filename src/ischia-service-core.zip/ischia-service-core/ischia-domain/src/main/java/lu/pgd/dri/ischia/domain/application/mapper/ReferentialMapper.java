package lu.pgd.dri.ischia.domain.application.mapper;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.*;
import lu.pgd.dri.ischia.domainapi.response.ChannelReferentialResponse;
import lu.pgd.dri.ischia.domainapi.response.ReferentialCountryResponse;
import lu.pgd.dri.ischia.domainapi.response.ReferentialResponse;
import lu.pgd.dri.ischia.domainapi.response.ReferentialUserUnitResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants.ComponentModel;

@Mapper(componentModel = ComponentModel.SPRING)
public interface ReferentialMapper {

    ReferentialResponse toReferenceResponse(AbstractReferenceEntity reference);

    @Mapping(source = "organization.id", target = "organizationId")
    ReferentialUserUnitResponse toUserUnitResponse(UserUnitEntity userUnit);

    // ---- Reference types that belong to a channel (column RCH_ID) ---------------------------
    // One method per entity: MapStruct needs the concrete type to read "channel".

    @Mapping(source = "channel.id", target = "channelId")
    ChannelReferentialResponse toChannelReferentialResponse(CrimeAreaEntity reference);

    @Mapping(source = "channel.id", target = "channelId")
    ChannelReferentialResponse toChannelReferentialResponse(MessageConfidentialityEntity reference);

    @Mapping(source = "channel.id", target = "channelId")
    ChannelReferentialResponse toChannelReferentialResponse(MessageHandlingCodeEntity reference);

    @Mapping(source = "channel.id", target = "channelId")
    ChannelReferentialResponse toChannelReferentialResponse(MessagePriorityEntity reference);

    @Mapping(source = "channel.id", target = "channelId")
    ChannelReferentialResponse toChannelReferentialResponse(MessageReliabilityEntity reference);

    // ---- Country ------------------------------------------------------------------------------
    // Explicit mapping: MapStruct matches names case-sensitively ("alphacode2" != "alphaCode2"),
    // without it both codes were always null in the response.

    @Mapping(source = "alphacode2", target = "alphaCode2")
    @Mapping(source = "alphacode3", target = "alphaCode3")
    ReferentialCountryResponse toReferentialCountry(CountryEntity countryEntity);
}
