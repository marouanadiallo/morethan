package lu.pgd.dri.ischia.domain.persistence.repository;

import lu.pgd.dri.ischia.domain.persistence.entity.LegalDocumentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LegalDocumentRepository extends JpaRepository<LegalDocumentEntity, Long> {
}
