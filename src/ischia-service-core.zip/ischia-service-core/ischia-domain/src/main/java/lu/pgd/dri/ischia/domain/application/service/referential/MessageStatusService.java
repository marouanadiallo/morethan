package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageStatusEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.MessageStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class MessageStatusService extends AbstractReferentialService<MessageStatusEntity> {
    public MessageStatusService(ReferentialMapper referentialMapper, MessageStatusRepository repository) {
        super(referentialMapper, repository);
    }
}
