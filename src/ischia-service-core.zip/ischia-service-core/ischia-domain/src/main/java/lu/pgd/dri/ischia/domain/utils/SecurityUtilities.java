package lu.pgd.dri.ischia.domain.utils;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

import java.util.*;

public final class SecurityUtilities {

    public static final String AUTHORIZED_PARTY_FIELD = "azp";
    public static final String CAN_DI_FIELD = "can_di";
    public static final String OTP_FIELD = "otp";

    public static final String ROLES_FIELD = "roles";
    public static final String SAGA_SERVICE_AUD = "saga-service";
    public static final String RESOURCE_ACCESS = "resource_access";
    private static final String SAGA_SUPER_ADMIN_ROLE = "BACKOFFICE";

    private SecurityUtilities() {}

    public static Optional<String> getUsedIdFromSecurityContext() {
        return Optional.ofNullable(SecurityContextHolder.getContext())
                .map(SecurityContext::getAuthentication)
                .map(Authentication::getName);
    }

    public static boolean isSAGASuperAdmin() {
        return getClaims()
                .map(claims -> claims.get(RESOURCE_ACCESS))
                .filter(Map.class::isInstance).map(Map.class::cast)
                .map(map -> map.get(SAGA_SERVICE_AUD))
                .filter(Map.class::isInstance).map(Map.class::cast)
                .map(map -> map.get(ROLES_FIELD))
                .filter(List.class::isInstance).map(List.class::cast)
                .map(roles -> roles.contains(SAGA_SUPER_ADMIN_ROLE))
                .orElse(false);
    }

    public static Optional<String> getUserOtp() {
        return getClaims()
                .map(claims -> claims.get(CAN_DI_FIELD))
                .filter(Map.class::isInstance).map(Map.class::cast)
                .map(map -> map.get(OTP_FIELD))
                .filter(String.class::isInstance).map(String.class::cast)
                .map(String::valueOf);
    }

    public static Optional<String> getAuthorizedParty() {
        return getClaims()
                .map(claims -> claims.get(AUTHORIZED_PARTY_FIELD))
                .map(String.class::cast);
    }

    public static Collection<GrantedAuthority> getAuthoritiesFromSecurityContext() {
        return Collections.unmodifiableCollection(
                Optional.ofNullable(SecurityContextHolder.getContext())
                        .map(SecurityContext::getAuthentication)
                        .map(Authentication::getAuthorities)
                        .orElse(Collections.emptyList())
        );
    }

    public static boolean hasRole(String role) {
        return getAuthoritiesFromSecurityContext().stream()
                .map(GrantedAuthority::getAuthority)
                .anyMatch(authority -> authority.equals(role));
    }


    private static Optional<Map<String, Object>> getClaims() {
        return Optional.ofNullable(SecurityContextHolder.getContext())
                .map(SecurityContext::getAuthentication)
                .filter(JwtAuthenticationToken.class::isInstance)
                .map(JwtAuthenticationToken.class::cast)
                .map(JwtAuthenticationToken::getTokenAttributes);
    }
}
