package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Entity
@Getter
@Table(name = "IS_LEGAL_DISPOSITION_LEGD")
@AttributeOverride(name = "updatedAt", column = @Column(name = "LEGD_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "LEGD_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "LEGD_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "LEGD_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class LegalDispositionEntity extends Auditable {

    @Id
    @Column(name = "LEGD_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_legal_disposition_gen"
    )
    @SequenceGenerator(name = "seq_legal_disposition_gen",
            sequenceName = "IS_LEGD_S",
            allocationSize = 20
    )
    private final Long id;

    @Column(name = "LEGD_LEGAL_DISPOSITION")
    @Comment("")
    private Long legalDispositionId;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "SCP_ID", foreignKey = @ForeignKey(name = "C_FK_LEGD_SCP_ID"))
    @Comment("")
    private SagaComponentEntity sagaComponent;

    @SuppressWarnings("unused")
    protected LegalDispositionEntity() {
        this.id = null;
    }

    public LegalDispositionEntity(SagaComponentEntity sagaComponent, Long legalDispositionId) {
        this.id = null;
        this.sagaComponent = sagaComponent;
        this.legalDispositionId = legalDispositionId;
    }
}
