package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageHandlingCodeEntity;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_MAP_MESSAGE_HANDLING_CODE_MMHC")
@AttributeOverride(name = "updatedAt", column = @Column(name = "MMHC_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "MMHC_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "MMHC_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "MMHC_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class MessageHandlingCodeMapEntity extends Auditable {

    @Id
    @Column(name = "MMHC_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_handling_code_map_gen"
    )
    @SequenceGenerator(
            name = "seq_message_handling_code_map_gen",
            sequenceName = "IS_MMHC_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_MMHC_MSG_ID"))
    @Comment("")
    private MessageEntity message;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RMHC_ID", foreignKey = @ForeignKey(name = "C_FK_MMHC_RMHC_ID"))
    @Comment("")
    private MessageHandlingCodeEntity messageHandlingCode;

    protected MessageHandlingCodeMapEntity() {
        this.id = null;
    }

    public static MessageHandlingCodeMapEntity of(MessageEntity message, MessageHandlingCodeEntity messageHandlingCode) {
        MessageHandlingCodeMapEntity entity = new MessageHandlingCodeMapEntity();
        entity.setMessage(message);
        entity.setMessageHandlingCode(messageHandlingCode);
        return entity;
    }
}
