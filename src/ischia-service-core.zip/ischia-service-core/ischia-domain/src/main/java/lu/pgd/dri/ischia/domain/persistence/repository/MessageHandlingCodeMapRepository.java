package lu.pgd.dri.ischia.domain.persistence.repository;

import lu.pgd.dri.ischia.domain.persistence.entity.MessageHandlingCodeMapEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageHandlingCodeMapRepository extends JpaRepository<MessageHandlingCodeMapEntity, Long> {
}
