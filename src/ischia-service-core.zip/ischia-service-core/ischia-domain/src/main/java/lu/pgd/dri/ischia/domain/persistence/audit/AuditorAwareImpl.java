package lu.pgd.dri.ischia.domain.persistence.audit;

import lu.pgd.dri.ischia.domain.utils.SecurityUtilities;
import org.jspecify.annotations.NonNull;
import org.springframework.data.domain.AuditorAware;

import java.util.Optional;

public class AuditorAwareImpl implements AuditorAware<String> {

    public static final String TECHNICAL_USER_NAME = "TECH_USER";

    @Override
    @NonNull
    public Optional<String> getCurrentAuditor() {
        return Optional.of(SecurityUtilities.getUsedIdFromSecurityContext().orElse(TECHNICAL_USER_NAME));
    }
}