package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.DocumentCategoryEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.DocumentCategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class DocumentCategoryService extends AbstractReferentialService<DocumentCategoryEntity> {
    public DocumentCategoryService(ReferentialMapper referentialMapper, DocumentCategoryRepository repository) {
        super(referentialMapper, repository);
    }
}
