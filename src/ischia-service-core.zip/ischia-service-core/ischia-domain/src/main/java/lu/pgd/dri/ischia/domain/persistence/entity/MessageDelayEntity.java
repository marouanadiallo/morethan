package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageDelayRefEntity;
import org.hibernate.annotations.Comment;

import java.time.Instant;

@Getter
@Entity
@Table(name = "IS_MESSAGE_DELAY_MD")
@AttributeOverride(name = "updatedAt", column = @Column(name = "MD_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "MD_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "MD_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "MD_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class MessageDelayEntity extends Auditable {
    @Id
    @Column(name = "MD_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_delay_gen"
    )
    @SequenceGenerator(
            name = "seq_message_delay_gen",
            sequenceName = "IS_MD_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @Column(name = "MD_START_DATE")
    @Comment("")
    private Instant startDate;

    @Setter
    @Column(name = "MD_DEADLINE_DATE")
    @Comment("")
    private Instant deadlineDate;

    @Setter
    @Column(name = "MD_SUSPEND_START_DATE")
    @Comment("")
    private Instant suspendStartDate;

    @Setter
    @Column(name = "MD_SUSPEND_END_DATE")
    @Comment("")
    private Instant suspendEndDate;

    @Setter
    @Column(name = "MD_ALLOCATED_DELAY")
    @Comment("")
    private Long allocatedDelay;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_MD_MSG_ID"))
    @Comment("")
    private MessageEntity message;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RMD_ID", foreignKey = @ForeignKey(name = "C_FK_MD_RMD_ID"))
    @Comment("")
    private MessageDelayRefEntity messageDelayRef;

    protected MessageDelayEntity() {
        this.id = null;
    }

    public static MessageDelayEntity of(MessageEntity message, MessageDelayRefEntity messageDelayRef) {
        MessageDelayEntity messageDelayEntity = new MessageDelayEntity();
        messageDelayEntity.setMessage(message);
        messageDelayEntity.setMessageDelayRef(messageDelayRef);
        return messageDelayEntity;
    }
}
