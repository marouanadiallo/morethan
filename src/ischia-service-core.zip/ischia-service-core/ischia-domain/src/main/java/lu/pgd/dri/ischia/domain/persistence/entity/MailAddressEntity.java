package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.CountryEntity;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.OrganizationEntity;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_MAIL_ADDRESS_MAD")
@AttributeOverride(name = "updatedAt", column = @Column(name = "MAD_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "MAD_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "MAD_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "MAD_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class MailAddressEntity extends Auditable {

    @Id
    @Column(name = "MAD_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_address_gen"
    )
    @SequenceGenerator(
            name = "seq_message_address_gen",
            sequenceName = "IS_MAD_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @Column(name = "MAD_EMAIL")
    @Comment("")
    private String email;

    @Setter
    @Column(name = "MAD_IS_ACTIVE")
    @Comment("")
    private Boolean isActive;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RCTY_ID", foreignKey = @ForeignKey(name = "C_FK_MR_RCTY_ID"))
    @Comment("")
    private CountryEntity country;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RO_ID", foreignKey = @ForeignKey(name = "C_FK_MR_RO_ID"))
    @Comment("")
    private OrganizationEntity organization;

    protected MailAddressEntity() {
        this.id = null;
    }

    public static MailAddressEntity of(String email, Boolean active) {
        MailAddressEntity entity = new MailAddressEntity();
        entity.setEmail(email);
        entity.setIsActive(active);
        return entity;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass())
            return false;

        MailAddressEntity that = (MailAddressEntity) o;
        return email.equals(that.email);
    }

    @Override
    public int hashCode() {
        return email.hashCode();
    }
}
