package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.UnitOrganizationEntity;

public interface UnitOrganizationRepository extends  ReferenceBaseRepository<UnitOrganizationEntity> {
}
