package lu.pgd.dri.ischia.domain.application.service;

public interface MessageService {
}
