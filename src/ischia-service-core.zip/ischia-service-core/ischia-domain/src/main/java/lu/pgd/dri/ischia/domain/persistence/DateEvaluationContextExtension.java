package lu.pgd.dri.ischia.domain.persistence;

import lombok.RequiredArgsConstructor;
import org.jspecify.annotations.NonNull;
import org.springframework.data.spel.spi.EvaluationContextExtension;

import java.time.Clock;
import java.time.LocalDate;

/**
 * Inspired by the implementation of Spring Security's `EvaluationContext` extension.
 * - #{principal.xx}
 * This will allow us to inject into the Spring evaluation context the ability
 * to call `#{today()}` or `#{datez.today()}` with the time zone configured.
 */
@RequiredArgsConstructor
public class DateEvaluationContextExtension implements EvaluationContextExtension {

    private final Clock clock;

    @NonNull
    @Override
    public String getExtensionId() {
        return "datez";
    }

    @Override
    public DateEvaluationContextExtension getRootObject() {
        return this;
    }

    @SuppressWarnings("unused")
    public LocalDate today() {
        return LocalDate.now(clock);
    }
}
