package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.ChannelEntity;

public interface ChannelRepository extends ReferenceBaseRepository<ChannelEntity> {
}
