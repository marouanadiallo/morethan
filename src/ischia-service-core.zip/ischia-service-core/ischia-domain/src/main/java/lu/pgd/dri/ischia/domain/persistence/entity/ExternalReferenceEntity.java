package lu.pgd.dri.ischia.domain.persistence.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_EXTERNAL_REF_ER")
@AttributeOverride(name = "updatedAt", column = @Column(name = "ER_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "ER_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "ER_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "ER_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class ExternalReferenceEntity extends Auditable {

    @Id
    @Column(name = "ER_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_external_ref_gen"
    )
    @SequenceGenerator(
            name = "seq_external_ref_gen",
            sequenceName = "IS_ER_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @Column(name = "ER_APPLICATION_SOURCE", length = 100)
    @Comment("")
    private String applicationSource;

    @Setter
    @Column(name = "ER_EXTERNAL_REF", length = 100)
    @Comment("")
    private String externalRef;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_ER_MSG_ID"))
    @Comment("")
    private MessageEntity message;

    protected ExternalReferenceEntity() {
        this.id = null;
    }

    public static ExternalReferenceEntity of(MessageEntity message) {
        ExternalReferenceEntity entity = new ExternalReferenceEntity();
        entity.setMessage(message);
        return entity;
    }
}
