package lu.pgd.dri.ischia.domain.application;

/**
 * This interface serves as an index to instruct Spring to scan the application package.
 * Therefore, be aware that this package is scanned by Spring.
 */
public interface DomainApplicationPackage {
}
