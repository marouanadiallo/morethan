package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.NationalityEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.NationalityRepository;
import org.springframework.stereotype.Service;

@Service
public class NationalityService extends AbstractReferentialService<NationalityEntity> {
    public NationalityService(ReferentialMapper referentialMapper, NationalityRepository repository) {
        super(referentialMapper, repository);
    }
}
