package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageTypeEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.MessageTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class MessageTypeService extends AbstractReferentialService<MessageTypeEntity> {
    public MessageTypeService(ReferentialMapper referentialMapper, MessageTypeRepository repository) {
        super(referentialMapper, repository);
    }
}
