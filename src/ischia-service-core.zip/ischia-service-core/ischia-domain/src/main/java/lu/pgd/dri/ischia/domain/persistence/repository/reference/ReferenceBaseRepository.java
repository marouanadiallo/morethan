package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.AbstractReferenceEntity;
import org.jspecify.annotations.NonNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.List;
import java.util.Optional;

@NoRepositoryBean
public interface ReferenceBaseRepository<E extends AbstractReferenceEntity> extends JpaRepository<E, Long> {

    @NonNull
    Optional<E> findById(@NonNull Long id);

    @NonNull
    Optional<E> findByCodeIgnoreCase(@NonNull String code);

    @Query("""
            SELECT e
            FROM #{#entityName} e
            WHERE (e.validityFrom IS NULL OR e.validityFrom <= :#{datez.today()})
            AND (e.validityTo IS NULL OR e.validityTo >= :#{datez.today()})
            """)
    List<E> findValidateReferences();
}
