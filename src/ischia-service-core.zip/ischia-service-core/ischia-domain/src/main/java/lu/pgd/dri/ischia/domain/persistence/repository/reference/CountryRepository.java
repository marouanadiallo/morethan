package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.CountryEntity;
import org.jspecify.annotations.NonNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface CountryRepository extends JpaRepository<CountryEntity, Long> {

    @NonNull
    Optional<CountryEntity> findById(@NonNull Long id);

    @Query("""
            SELECT c
            FROM CountryEntity c
            WHERE upper(c.alphacode2) = upper(:code) OR upper(c.alphacode3) = upper(:code)
            """)
    Optional<CountryEntity> findByAlphacode2OrAlphacode3IgnoreCase(@NonNull String code);

    @Query("""
            SELECT c
            FROM CountryEntity c
            WHERE (c.validityFrom IS NULL OR c.validityFrom <= :#{datez.today()})
            AND (c.validityTo IS NULL OR c.validityTo >= :#{datez.today()})
            """)
    List<CountryEntity> findValidateCountries();
}
