package lu.pgd.dri.ischia.domain.application.enums;

import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

@Slf4j
public enum MessageDirection {

    INBOUND("INBOUND"),
    OUTBOUND("OUTBOUND");

    private final String direction;

    MessageDirection(String value) {
        this.direction = value;
    }

    public static Optional<MessageDirection> fromString(String direction) {
        try {
            return Optional.of(MessageDirection.valueOf(direction));
        } catch (IllegalArgumentException e) {
            log.error("Invalid MessageDirection value '{}', error={}", direction, e.getMessage());
            return Optional.empty();
        }
    }

    public String direction() {
        return direction;
    }

}
