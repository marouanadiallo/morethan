package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.UserUnitEntity;

public interface UserUnitRepository extends ReferenceBaseRepository<UserUnitEntity> {
}
