package lu.pgd.dri.ischia.domain.application.service.referential;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.UserUnitRepository;
import lu.pgd.dri.ischia.domainapi.response.ReferentialUserUnitResponse;
import org.jspecify.annotations.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class UserUnitService {

    private final ReferentialMapper referentialMapper;
    private final UserUnitRepository userUnitRepository;

    public List<ReferentialUserUnitResponse> getAll() {
        log.info("Getting all user units");
        return this.userUnitRepository.findValidateReferences().stream()
                .map(referentialMapper::toUserUnitResponse)
                .toList();
    }

    public ReferentialUserUnitResponse getById(@NonNull Long id) {
        log.info("Getting user unit by id: {}", id);
        return this.userUnitRepository.findById(id)
                .map(referentialMapper::toUserUnitResponse)
                .orElseThrow(()-> new ResourceNotFoundException("referential.notfound.byId", id));
    }

    public ReferentialUserUnitResponse getByCode(@NonNull String code) {
        log.info("Getting user unit by code: {}", code);
        return this.userUnitRepository.findByCodeIgnoreCase(code)
                .map(referentialMapper::toUserUnitResponse)
                .orElseThrow(()->  new ResourceNotFoundException("referential.notfound.byCode", code));
    }
}
