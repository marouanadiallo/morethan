package lu.pgd.dri.ischia.domain.persistence.repository;

import lu.pgd.dri.ischia.domain.persistence.entity.MailAddressEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MailAddressRepository extends JpaRepository<MailAddressEntity, Long> {
}
