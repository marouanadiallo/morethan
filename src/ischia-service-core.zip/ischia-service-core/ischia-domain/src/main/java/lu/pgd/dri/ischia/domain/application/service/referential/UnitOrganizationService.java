package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.UnitOrganizationEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.UnitOrganizationRepository;
import org.springframework.stereotype.Service;

@Service
public class UnitOrganizationService extends AbstractReferentialService<UnitOrganizationEntity> {
    public UnitOrganizationService(ReferentialMapper referentialMapper, UnitOrganizationRepository repository) {
        super(referentialMapper, repository);
    }
}
