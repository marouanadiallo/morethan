package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_MESSAGE_RECIPIENT_MR")
@AttributeOverride(name = "updatedAt", column = @Column(name = "MR_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "MR_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "MR_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "MR_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class MessageRecipientEntity extends Auditable {

    @Id
    @Column(name = "MR_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_recipient_gen"
    )
    @SequenceGenerator(
            name = "seq_message_recipient_gen",
            sequenceName = "IS_MR_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @Column(name = "MR_IS_CC")
    @Comment("")
    private Boolean isCC;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_MR_MSG_ID"))
    @Comment("")
    private MessageEntity message;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MAD_ID", foreignKey = @ForeignKey(name = "C_FK_MR_MAD_ID"))
    @Comment("")
    private MailAddressEntity mailAddress;

    protected MessageRecipientEntity() {
        this.id = null;
    }

    public static MessageRecipientEntity of(MessageEntity message, MailAddressEntity mailAddress, boolean isCC) {
        MessageRecipientEntity entity = new MessageRecipientEntity();
        entity.setMessage(message);
        entity.setMailAddress(mailAddress);
        entity.setIsCC(isCC);
        return entity;
    }
}
