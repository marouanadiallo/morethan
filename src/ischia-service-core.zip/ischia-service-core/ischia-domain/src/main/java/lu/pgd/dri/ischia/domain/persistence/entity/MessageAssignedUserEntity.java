package lu.pgd.dri.ischia.domain.persistence.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.application.enums.MessageAssignmentRole;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_MAP_MESSAGE_ASSIGNMENT_MMAUS")
@AttributeOverride(name = "createdAt", column = @Column(name = "MMAUS_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "MMAUS_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "MMAUS_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "MMAUS_UPDATED_BY", length = 50))
public class MessageAssignedUserEntity extends Auditable {

    @Id
    @Column(name = "MMAUS_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_assignment_user_gen"
    )
    @SequenceGenerator(name = "seq_message_assignment_user_gen",
            sequenceName = "IS_MMAUS_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "US_ID", foreignKey = @ForeignKey(name = "C_FK_MMAUS_US_ID"))
    @Comment("")
    private AppUserEntity user;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_MMAUS_MSG_ID"))
    @Comment("")
    private MessageEntity message;

    @Setter
    @Column(name = "MMAUS_ASSIGNEE_ROLE")
    @Enumerated(EnumType.STRING)
    @Comment("")
    private MessageAssignmentRole role;

    @SuppressWarnings("unused")
    protected MessageAssignedUserEntity() {
        this.id = null;
    }

    public MessageAssignedUserEntity(AppUserEntity user, MessageEntity message, MessageAssignmentRole role) {
        this.id = null;
        this.user = user;
        this.message = message;
        this.role = role;
    }
}
