package lu.pgd.dri.ischia.domain.persistence.repository;

import lu.pgd.dri.ischia.domain.persistence.entity.DeletionLogEntryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

@Transactional(readOnly = true)
public interface DeletionLogEntryRepository extends JpaRepository<DeletionLogEntryEntity, Long> {
}
