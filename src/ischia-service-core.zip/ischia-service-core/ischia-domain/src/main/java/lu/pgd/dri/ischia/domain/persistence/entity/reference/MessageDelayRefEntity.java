package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_MESSAGE_DELAY_RMD", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_RMD_CODE", columnNames = {"RMD_CODE"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RMD_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RMD_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RMD_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RMD_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RMD_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RMD_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RMD_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RMD_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RMD_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RMD_VALIDITY_FROM", length = 6))
@Comment("Defines the message delay type.")
public class MessageDelayRefEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RMD_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the message delay.")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_delay_ref_gen"
    )
    @SequenceGenerator(name = "seq_message_delay_ref_gen",
            sequenceName = "IS_RMD_S",
            allocationSize = 20
    )
    private final Long id;

    protected MessageDelayRefEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
