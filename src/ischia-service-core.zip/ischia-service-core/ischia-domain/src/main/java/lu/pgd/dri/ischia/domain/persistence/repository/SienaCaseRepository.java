package lu.pgd.dri.ischia.domain.persistence.repository;

import lu.pgd.dri.ischia.domain.persistence.entity.CaseEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SienaCaseRepository extends JpaRepository<CaseEntity, Long> {
}
