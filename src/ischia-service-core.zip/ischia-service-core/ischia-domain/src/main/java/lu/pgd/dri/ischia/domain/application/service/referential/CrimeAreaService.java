package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractChannelReferentialService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.CrimeAreaEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.CrimeAreaRepository;
import org.springframework.stereotype.Service;

@Service
public class CrimeAreaService extends AbstractChannelReferentialService<CrimeAreaEntity> {
    public CrimeAreaService(ReferentialMapper referentialMapper, CrimeAreaRepository repository) {
        super(repository, referentialMapper::toChannelReferentialResponse);
    }
}
