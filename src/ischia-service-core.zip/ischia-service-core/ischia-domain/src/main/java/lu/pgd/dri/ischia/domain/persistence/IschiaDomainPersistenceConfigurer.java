package lu.pgd.dri.ischia.domain.persistence;

import lu.pgd.dri.ischia.domain.persistence.audit.AuditorAwareImpl;
import lu.pgd.dri.ischia.domain.persistence.entity.AppUserEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.AppUserRepository;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.time.Clock;

@Configuration
@EnableJpaAuditing
@EntityScan(basePackageClasses = {AppUserEntity.class})
@EnableJpaRepositories(basePackageClasses = {AppUserRepository.class})
public class IschiaDomainPersistenceConfigurer {

    @Bean
    public AuditorAware<String> auditorProvider() {
        return new AuditorAwareImpl();
    }

    @Bean
    DateEvaluationContextExtension dateEvaluationContextExtension(Clock clock) {
        return new DateEvaluationContextExtension(clock);
    }
}
