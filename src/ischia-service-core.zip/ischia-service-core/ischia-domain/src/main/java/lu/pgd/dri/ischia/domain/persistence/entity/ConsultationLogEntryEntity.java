package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.ConsultationScopeTypeEntity;
import org.hibernate.annotations.Comment;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;

@Getter
@Entity
@Table(name = "IS_CONSULTATION_LOG_CL")
@EntityListeners(AuditingEntityListener.class)
@Comment("Stores consultation traces for read operations on ischia-service resources")
public class ConsultationLogEntryEntity {

    @Id
    @Column(name = "CL_ID", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "sq_consultation_log_generator"
    )
    @SequenceGenerator(
            name = "sq_consultation_log_generator",
            sequenceName = "IS_CL_S",
            allocationSize = 20
    )
    @Comment("Technical identifier of the consultation log entry")
    private final Long id;

    @Setter
    @Column(name = "CL_TRACE_ID", nullable = false, length = 64)
    @Comment("Trace identifier propagated across the request flow")
    private String traceId;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "RCSTE_ID", foreignKey = @ForeignKey(name = "C_FK_CL_RCSTE_ID"))
    @Comment("Optional consultation scope type associated with the consultation")
    private ConsultationScopeTypeEntity consultationScopeTypeEntity;

    @Setter
    @Column(name = "CL_MOTIVE", length = 300)
    @Comment("Optional motive provided for the consultation")
    private String motive;

    @Setter
    @Column(name = "CL_ONLY_ACTIVE")
    @Comment("Optional flag indicating that only active data was requested")
    private Boolean onlyActive;

    @Setter
    @Column(name = "CL_URL", nullable = false, length = 2000)
    @Comment("Full URL of the consulted resource")
    private String url;

    @Setter
    @Column(name = "CL_QUERY_PARAMETERS", length = 2000)
    @Comment("Raw query string used for the consultation")
    private String queryParameters;

    @Setter
    @CreatedDate
    @Column(name = "CL_TIME", nullable = false, updatable = false)
    @Comment("Timestamp when the consultation was logged")
    private Instant time;

    @Setter
    @Column(name = "CL_USER_ID", nullable = false)
    @Comment("Identifier of the authenticated user who performed the consultation")
    private String userId;

    @Lob
    @Setter
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "CL_REQ_BODY")
    @Comment("Request body captured for JSON payloads after masking configured sensitive fields")
    private String requestBody;

    protected ConsultationLogEntryEntity() {
        this.id = null;
    }

    /**
     * Construct whit required fields
     */
    public static ConsultationLogEntryEntity of(String traceId, String url, String userId) {
        ConsultationLogEntryEntity entity = new ConsultationLogEntryEntity();
        entity.setTraceId(traceId);
        entity.setUrl(url);
        entity.setUserId(userId);
        return entity;
    }
}
