package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_SAGA_COMPONENT_SCP")
@AttributeOverride(name = "updatedAt", column = @Column(name = "SCP_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "SCP_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "SCP_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "SCP_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class SagaComponentEntity extends Auditable {

    @Id
    @Column(name = "SCP_ID", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_saga_component_gen"
    )
    @SequenceGenerator(name = "seq_saga_component_gen",
            sequenceName = "IS_SCP_S",
            allocationSize = 20
    )
    private final Long id;

    @Column(name = "SCP_COMPONENT_ID")
    @Comment("")
    private Long componentId;

    @Setter
    @Column(name = "SCP_COMPONENT_SELECTED")
    private boolean selected;

    @SuppressWarnings("unused")
    protected SagaComponentEntity() {
        this.id = null;
    }

    public SagaComponentEntity(Long componentId, boolean selected) {
        this.id = null;
        this.componentId = componentId;
        this.selected = selected;
    }
}
