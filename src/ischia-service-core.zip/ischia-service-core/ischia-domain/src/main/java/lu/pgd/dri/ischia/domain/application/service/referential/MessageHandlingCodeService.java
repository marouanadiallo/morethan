package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractChannelReferentialService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageHandlingCodeEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.MessageHandlingCodeRepository;
import org.springframework.stereotype.Service;

@Service
public class MessageHandlingCodeService extends AbstractChannelReferentialService<MessageHandlingCodeEntity> {
    public MessageHandlingCodeService(ReferentialMapper referentialMapper, MessageHandlingCodeRepository repository) {
        super(repository, referentialMapper::toChannelReferentialResponse);
    }
}
