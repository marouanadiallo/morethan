package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageDelayRefEntity;

public interface MessageDelayRefRepository extends  ReferenceBaseRepository<MessageDelayRefEntity> {
}
