package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.ChannelEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.ChannelRepository;
import org.springframework.stereotype.Service;

@Service
public class ChannelService extends AbstractReferentialService<ChannelEntity> {
    public ChannelService(ReferentialMapper referentialMapper, ChannelRepository repository) {
        super(referentialMapper, repository);
    }
}
