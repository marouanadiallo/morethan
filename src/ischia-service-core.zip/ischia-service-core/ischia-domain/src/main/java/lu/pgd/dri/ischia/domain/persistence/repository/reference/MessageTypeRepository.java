package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageTypeEntity;

public interface MessageTypeRepository extends  ReferenceBaseRepository<MessageTypeEntity> {
}
