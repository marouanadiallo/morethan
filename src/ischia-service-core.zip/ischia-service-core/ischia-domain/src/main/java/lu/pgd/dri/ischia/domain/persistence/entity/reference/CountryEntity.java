package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.persistence.entity.Auditable;
import org.hibernate.annotations.Comment;

import java.time.LocalDate;
import java.util.Objects;

@Getter
@Entity
@Table(name = "IS_REF_COUNTRY_RCTY")
@AttributeOverride(name = "createdAt", column = @Column(name = "RCTY_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RCTY_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RCTY_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RCTY_UPDATED_BY", length = 50))
@Comment("Defines the country type.")
public class CountryEntity extends Auditable {

    @Id
    @Column(name = "RCTY_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the country.")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_country_gen")
    @SequenceGenerator(name = "seq_country_gen",
            sequenceName = "IS_RCTY_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @Comment("Alpha code of the country")
    @Column(name = "RCTY_ALPHACODE2", length = 2)
    private String alphacode2;

    @Setter
    @Comment("Alpha code of the country")
    @Column(name = "RCTY_ALPHACODE3", length = 3)
    private String alphacode3;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ZNE_ID", foreignKey = @ForeignKey(name = "C_FK_RCTY_ZNE_ID"))
    private ZoneEntity zone;

    @Setter
    @Comment("Reason label in German")
    @Column(name = "RCTY_LABEL_DE", length = 100)
    private String labelDe;

    @Setter
    @Comment("Reason label in French")
    @Column(name = "RCTY_LABEL_FR", length = 100)
    private String labelFr;

    @Setter
    @Comment("Reason label in English")
    @Column(name = "RCTY_LABEL_EN", length = 100)
    private String labelEn;

    @Setter
    @Column(name = "RCTY_VALIDITY_FROM", length = 6)
    @Comment("Date from which the assignee type is valid")
    private LocalDate validityFrom;

    @Setter
    @Column(name = "RCTY_VALIDITY_TO", length = 6)
    @Comment("Date until which the assignee type remains valid")
    private LocalDate validityTo;

    protected CountryEntity() {
        this.id = null;
    }

    /**
     * Same rules as {@link AbstractReferenceEntity#equals(Object)}: proxy-safe (getters only), null-safe.
     * Business key = alphacode2 + alphacode3.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || AbstractReferenceEntity.effectiveClass(this) != AbstractReferenceEntity.effectiveClass(o)) {
            return false;
        }
        CountryEntity that = (CountryEntity) o;
        return getAlphacode2() != null
                && getAlphacode2().equals(that.getAlphacode2())
                && Objects.equals(getAlphacode3(), that.getAlphacode3());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getAlphacode2(), getAlphacode3());
    }
}
