package lu.pgd.dri.ischia.domain.persistence.repository;

import lu.pgd.dri.ischia.domain.persistence.entity.AuditOutgoingEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditOutgoingRepository extends JpaRepository<AuditOutgoingEntity, Long> {
}
