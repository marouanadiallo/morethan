package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.DocumentCategoryEntity;

public interface DocumentCategoryRepository extends ReferenceBaseRepository<DocumentCategoryEntity> {
}
