package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.persistence.entity.Auditable;
import org.hibernate.annotations.Comment;
import org.hibernate.proxy.HibernateProxy;

import java.time.LocalDate;
import java.util.Objects;


@Getter
@Setter
@MappedSuperclass
public abstract class AbstractReferenceEntity extends Auditable {

    @Comment("Unique code identifying the referential type")
    protected String code;

    @Comment("Reason label in German")
    protected String labelDe;

    @Comment("Reason label in French")
    protected String labelFr;

    @Comment("Reason label in English")
    protected String labelEn;

    @Comment("Date from which the assignee type is valid")
    protected LocalDate validityFrom;

    @Comment("Date until which the assignee type remains valid")
    protected LocalDate validityTo;

    protected AbstractReferenceEntity() {
    }

    /**
     * Implemented by Lombok's {@code @Getter} on each subclass (the id column differs per table).
     * Declared here so that code working on the abstract type (MapStruct, generic services) can read it:
     * without it, {@code ReferentialMapper.toReferenceResponse} always returned {@code id = null}.
     */
    public abstract Long getId();

    /**
     * Equality on the business key (code), which is unique per table.
     * <ul>
     *   <li>Proxy-safe: references are loaded LAZY, so {@code o} may be a Hibernate proxy
     *       (its class is a generated subclass, and its fields are empty: always read through getters).</li>
     *   <li>Null-safe: a new entity without code is only equal to itself.</li>
     * </ul>
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || effectiveClass(this) != effectiveClass(o)) {
            return false;
        }
        AbstractReferenceEntity that = (AbstractReferenceEntity) o;
        return getCode() != null && getCode().equals(that.getCode());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getCode());
    }

    /**
     * Real entity class, without initializing the proxy.
     */
    static Class<?> effectiveClass(Object entity) {
        return entity instanceof HibernateProxy proxy
                ? proxy.getHibernateLazyInitializer().getPersistentClass()
                : entity.getClass();
    }
}
