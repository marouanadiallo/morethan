package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.ZoneEntity;

public interface ZoneRepository extends ReferenceBaseRepository<ZoneEntity> {
}
