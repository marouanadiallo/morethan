package lu.pgd.dri.ischia.domain.persistence.projection;

public class Todo {
    //TODO: this package should be content de POJO or Interfaces projections
}
