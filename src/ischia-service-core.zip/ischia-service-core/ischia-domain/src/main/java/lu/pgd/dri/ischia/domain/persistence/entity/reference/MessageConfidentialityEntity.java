package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_MESSAGE_CONFIDENTIALITY_RMC", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_RMC_ID", columnNames = {"RMC_CODE"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RMC_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RMC_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RMC_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RMC_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RMC_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RMC_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RMC_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RMC_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RMC_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RMC_VALIDITY_FROM", length = 6))
@Comment("Defines the message type.")
public class MessageConfidentialityEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RMC_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the message type")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_confidentiality_gen"
    )
    @SequenceGenerator(name = "seq_message_confidentiality_gen",
            sequenceName = "IS_RMC_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RCH_ID", foreignKey = @ForeignKey(name = "C_FK_RMC_RCH_ID"))
    private ChannelEntity channel;

    protected MessageConfidentialityEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
