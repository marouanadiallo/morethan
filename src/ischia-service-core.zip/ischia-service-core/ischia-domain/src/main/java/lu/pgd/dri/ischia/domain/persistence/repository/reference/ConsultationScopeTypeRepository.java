package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.ConsultationScopeTypeEntity;

public interface ConsultationScopeTypeRepository extends ReferenceBaseRepository<ConsultationScopeTypeEntity> {
}
