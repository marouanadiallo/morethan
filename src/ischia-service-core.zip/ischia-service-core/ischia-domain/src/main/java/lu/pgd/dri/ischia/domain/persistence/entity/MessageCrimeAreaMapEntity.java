package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.CrimeAreaEntity;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_MAP_MESSAGE_CRIME_AREA_MMCA")
@AttributeOverride(name = "updatedAt", column = @Column(name = "MMCA_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "MMCA_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "MMCA_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "MMCA_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class MessageCrimeAreaMapEntity extends Auditable {

    @Id
    @Column(name = "MMCA_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_crime_area_gen"
    )
    @SequenceGenerator(
            name = "seq_message_crime_area_gen",
            sequenceName = "IS_MMCA_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_MMCA_MSG_ID"))
    @Comment("")
    private MessageEntity message;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RCA_ID", foreignKey = @ForeignKey(name = "C_FK_MMCA_RCA_ID"))
    @Comment("")
    private CrimeAreaEntity crimeArea;

    protected MessageCrimeAreaMapEntity() {
        this.id = null;
    }

    public static MessageCrimeAreaMapEntity of(MessageEntity message, CrimeAreaEntity crimeArea) {
        MessageCrimeAreaMapEntity entity = new MessageCrimeAreaMapEntity();
        entity.setMessage(message);
        entity.setCrimeArea(crimeArea);
        return entity;
    }
}
