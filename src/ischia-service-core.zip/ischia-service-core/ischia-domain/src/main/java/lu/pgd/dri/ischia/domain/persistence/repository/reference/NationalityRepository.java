package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.NationalityEntity;

public interface NationalityRepository extends ReferenceBaseRepository<NationalityEntity> {
}
