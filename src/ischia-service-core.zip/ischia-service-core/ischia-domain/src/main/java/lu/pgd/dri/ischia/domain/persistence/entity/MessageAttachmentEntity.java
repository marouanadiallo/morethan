package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_MESSAGE_ATTACHMENT_MA")
@AttributeOverride(name = "updatedAt", column = @Column(name = "MA_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "MA_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "MA_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "MA_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class MessageAttachmentEntity extends Auditable {

    @Id
    @Column(name = "MA_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_attachment_gen"
    )
    @SequenceGenerator(
            name = "seq_message_attachment_gen",
            sequenceName = "IS_MA_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @Column(name = "MA_ATTACHMENT_EXT_REF")
    @Comment("")
    private Long attachmentExtRef;

    @Setter
    @Column(name = "MA_ATTACHMENT_EXT_BINARY_REF")
    @Comment("")
    private String attachmentExtBinaryRef;

    @Setter
    @Column(name = "MA_DELETED")
    @Comment("")
    private boolean deleted;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_MA_MSG_ID"))
    @Comment("")
    private MessageEntity message;

    protected MessageAttachmentEntity() {
        this.id = null;
        this.deleted = false;
    }

    public static MessageAttachmentEntity of(MessageEntity message) {
        MessageAttachmentEntity entity = new MessageAttachmentEntity();
        entity.setMessage(message);
        return entity;
    }

}
