package lu.pgd.dri.ischia.domain.persistence.repository;

import lu.pgd.dri.ischia.domain.persistence.entity.JudicialAuthorisationEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JudicialAuthorisationRepository extends JpaRepository<JudicialAuthorisationEntity, Long> {
}
