package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.CrimeAreaEntity;

public interface CrimeAreaRepository extends ChannelReferenceBaseRepository<CrimeAreaEntity> {
}
