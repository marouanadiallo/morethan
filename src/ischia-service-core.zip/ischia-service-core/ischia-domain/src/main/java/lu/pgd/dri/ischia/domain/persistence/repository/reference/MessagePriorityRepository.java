package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessagePriorityEntity;

public interface MessagePriorityRepository extends ChannelReferenceBaseRepository<MessagePriorityEntity> {
}
