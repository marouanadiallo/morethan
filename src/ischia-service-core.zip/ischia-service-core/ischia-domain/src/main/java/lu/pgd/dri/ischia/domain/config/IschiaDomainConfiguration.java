package lu.pgd.dri.ischia.domain.config;

import lu.pgd.dri.ischia.domain.application.DomainApplicationPackage;
import lu.pgd.dri.ischia.domain.persistence.IschiaDomainPersistenceConfigurer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import java.time.Clock;
import java.time.ZoneId;

@Configuration(proxyBeanMethods = false)
@ComponentScan(basePackageClasses = {
        DomainApplicationPackage.class
})
@Import(IschiaDomainPersistenceConfigurer.class)
public class IschiaDomainConfiguration {

    @Bean
    Clock clock(@Value("${ischia.timezone:UTC}") String timezone) {
        return "UTC".equals(timezone) ? Clock.systemUTC() : Clock.system(ZoneId.of(timezone));
    }

}
