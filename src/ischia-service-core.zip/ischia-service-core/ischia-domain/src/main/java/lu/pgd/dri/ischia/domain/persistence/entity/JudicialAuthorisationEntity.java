package lu.pgd.dri.ischia.domain.persistence.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

import java.time.Instant;

@Getter
@Entity
@Table(name = "IS_JUDICIAL_AUTHORISATION_JA")
@AttributeOverride(name = "updatedAt", column = @Column(name = "JA_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "JA_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "JA_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "JA_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class JudicialAuthorisationEntity extends Auditable {

    @Id
    @Column(name = "JA_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_judicial_authorisation_gen"
    )
    @SequenceGenerator(
            name = "seq_judicial_authorisation_gen",
            sequenceName = "IS_JA_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @Column(name = "JA_SUBMIT_DATE")
    @Comment("")
    private Instant submitDate;

    @Setter
    @Column(name = "JA_VALIDATION_DATE")
    @Comment("")
    private Instant validationDate;

    @Setter
    @Column(name = "JA_IS_VALID")
    @Comment("")
    private boolean valid = true;

    @Setter
    @Column(name = "JA_NOTICE_NUMBER")
    @Comment("")
    private String noticeNumber;

    @Setter
    @Column(name = "JA_ATTACHMENT_EXT_REF")
    @Comment("")
    private Long attachmentExtRef;

    @Setter
    @Column(name = "JA_ATTACHMENT_EXT_BINARY_REF")
    @Comment("")
    private String attachmentExtBinaryRef;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_JA_MSG_ID"))
    @Comment("")
    private MessageEntity message;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "US_ID", foreignKey = @ForeignKey(name = "C_FK_JA_US_ID"))
    @Comment("")
    private AppUserEntity appUser;

    protected JudicialAuthorisationEntity() {
        this.id = null;
    }

    public static JudicialAuthorisationEntity of(MessageEntity message, AppUserEntity appUser) {
        JudicialAuthorisationEntity entity = new JudicialAuthorisationEntity();
        entity.setMessage(message);
        entity.setAppUser(appUser);
        return entity;
    }
}
