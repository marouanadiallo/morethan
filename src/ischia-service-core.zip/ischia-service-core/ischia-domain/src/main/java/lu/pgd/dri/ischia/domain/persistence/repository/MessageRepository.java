package lu.pgd.dri.ischia.domain.persistence.repository;

import lu.pgd.dri.ischia.domain.persistence.entity.MessageEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageRepository extends JpaRepository<MessageEntity, Long> {
}
