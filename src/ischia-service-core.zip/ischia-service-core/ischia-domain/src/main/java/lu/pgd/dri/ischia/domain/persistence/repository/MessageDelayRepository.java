package lu.pgd.dri.ischia.domain.persistence.repository;

import lu.pgd.dri.ischia.domain.persistence.entity.MessageDelayEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageDelayRepository extends JpaRepository<MessageDelayEntity, Long> {
}
