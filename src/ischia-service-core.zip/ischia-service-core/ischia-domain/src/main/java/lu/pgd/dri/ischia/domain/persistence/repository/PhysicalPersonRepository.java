package lu.pgd.dri.ischia.domain.persistence.repository;

import lu.pgd.dri.ischia.domain.persistence.entity.PhysicalPersonEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PhysicalPersonRepository extends JpaRepository<PhysicalPersonEntity, Long> {
}
