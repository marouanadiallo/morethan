package lu.pgd.dri.ischia.domain.persistence.repository;

import lu.pgd.dri.ischia.domain.persistence.entity.ExternalReferenceEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExternalReferenceRepository extends JpaRepository<ExternalReferenceEntity, Long> {
}
