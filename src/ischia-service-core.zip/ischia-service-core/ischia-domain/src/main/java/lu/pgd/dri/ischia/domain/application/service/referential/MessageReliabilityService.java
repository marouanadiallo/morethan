package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractChannelReferentialService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageReliabilityEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.MessageReliabilityRepository;
import org.springframework.stereotype.Service;

@Service
public class MessageReliabilityService extends AbstractChannelReferentialService<MessageReliabilityEntity> {
    public MessageReliabilityService(ReferentialMapper referentialMapper, MessageReliabilityRepository repository) {
        super(repository, referentialMapper::toChannelReferentialResponse);
    }
}
