package lu.pgd.dri.ischia.domain.application.service.referential;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.CountryRepository;
import lu.pgd.dri.ischia.domainapi.response.ReferentialCountryResponse;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CountryService {

    private final ReferentialMapper referentialMapper;
    private final CountryRepository countryRepository;

    public List<ReferentialCountryResponse> getAll() {
        log.info("Get all countries");
        return this.countryRepository.findValidateCountries().stream()
                .map(referentialMapper::toReferentialCountry)
                .toList();
    }

    public ReferentialCountryResponse getByCode(String code) {
        log.info("Get country by code {}", code);
        if (Objects.isNull(code) || code.isEmpty()) {
            throw new ResourceNotFoundException("referential.notfound.byCode", code);
        }

        return this.countryRepository.findByAlphacode2OrAlphacode3IgnoreCase(code)
                .map(referentialMapper::toReferentialCountry)
                .orElseThrow(() -> new ResourceNotFoundException("referential.notfound.byCode", code));
    }

    public ReferentialCountryResponse getById(Long id) {
        log.info("Get country by id {}", id);
        return this.countryRepository.findById(id)
                .map(referentialMapper::toReferentialCountry)
                .orElseThrow(() -> new ResourceNotFoundException("referential.notfound.byId", id));
    }
}
