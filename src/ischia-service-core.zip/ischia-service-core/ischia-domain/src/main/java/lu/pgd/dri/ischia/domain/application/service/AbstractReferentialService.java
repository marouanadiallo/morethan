package lu.pgd.dri.ischia.domain.application.service;

import lombok.RequiredArgsConstructor;
import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.AbstractReferenceEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.ReferenceBaseRepository;
import lu.pgd.dri.ischia.domainapi.response.ReferentialResponse;
import org.jspecify.annotations.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@RequiredArgsConstructor
@Transactional(readOnly = true)
public abstract class AbstractReferentialService<E extends AbstractReferenceEntity> {

    private final ReferentialMapper referentialMapper;
    private final ReferenceBaseRepository<E> referentialRepository;

    // This makes it possible to see the concrete implementation of the service in the logs.
    // Instead of using @Sl4j on generic class
    private final Logger log = LoggerFactory.getLogger(getClass());

    public List<ReferentialResponse> getAll() {
        log.info("Getting all reference types");
        return this.referentialRepository.findValidateReferences().stream()
                .map(referentialMapper::toReferenceResponse)
                .toList();
    }

    public ReferentialResponse getById(@NonNull Long id) {
        log.info("Referential - getById {}", id);
        return this.referentialRepository.findById(id)
                .map(referentialMapper::toReferenceResponse)
                .orElseThrow(() -> new ResourceNotFoundException("referential.notfound.byId", id));
    }

    public ReferentialResponse getByCode(@NonNull String code) {
        log.info("Referential - getByCode {}", code);
        return this.referentialRepository.findByCodeIgnoreCase(code)
                .map(referentialMapper::toReferenceResponse)
                .orElseThrow(() -> new ResourceNotFoundException("referential.notfound.byCode", code));
    }
}
