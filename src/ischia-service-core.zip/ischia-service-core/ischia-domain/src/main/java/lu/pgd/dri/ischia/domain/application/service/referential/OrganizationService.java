package lu.pgd.dri.ischia.domain.application.service.referential;

import lu.pgd.dri.ischia.domain.application.mapper.ReferentialMapper;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.OrganizationEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.OrganizationRepository;
import org.springframework.stereotype.Service;

@Service
public class OrganizationService extends AbstractReferentialService<OrganizationEntity> {
    public OrganizationService(ReferentialMapper referentialMapper, OrganizationRepository repository) {
        super(referentialMapper, repository);
    }
}
