package lu.pgd.dri.ischia.audit.business;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lu.pgd.dri.ischia.audit.config.AuditProperties;
import lu.pgd.dri.ischia.audit.config.ValidationConstraints;
import lu.pgd.dri.ischia.audit.http.AuditMasker;
import lu.pgd.dri.ischia.audit.trace.CurrentTrace;
import lu.pgd.dri.ischia.domain.persistence.entity.ConsultationLogEntryEntity;
import lu.pgd.dri.ischia.domain.persistence.entity.DeletionLogEntryEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.ConsultationLogEntryRepository;
import lu.pgd.dri.ischia.domain.persistence.repository.DeletionLogEntryRepository;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.ConsultationScopeTypeRepository;
import lu.pgd.dri.ischia.domain.utils.SecurityUtilities;
import org.jspecify.annotations.NonNull;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.WebUtils;

import java.util.Objects;
import java.util.Set;

import static lu.pgd.dri.ischia.audit.config.Truncator.truncate;

/**
 * Access and deletion logs
 * Why use a `HandlerInterceptor` instead of a filter ?
 * - Because, in this case, Spring knows *which* Java method handled the request.
 * You read its marker annotations (@ConsultationLog / @DeletionLog / @NoBusinessLog, on the method or the class)
 * instead of guessing from the URL. Resolution rules: {@link BusinessLogResolver}.
 *
 * <br>
 * Synchronous writing (one line, in the request thread): unlike HTTP auditing,
 * this log entry must not be lost. A writing error is logged as ERROR but does not reach
 * the client: by the time `afterCompletion` is reached, the response has already been sent.
 */
@Slf4j
@RequiredArgsConstructor
public class BusinessLogInterceptor implements HandlerInterceptor {

    private final ConsultationLogEntryRepository consultationLogRepo;
    private final DeletionLogEntryRepository deletionLogRepo;
    private final ConsultationScopeTypeRepository consultationScopeTypeRepository;

    private final CurrentTrace currentTrace;
    private final AuditMasker masker;
    private final AuditProperties properties;

    /** Not injected: pure logic + cache, see its Javadoc for the class / method rules. */
    private final BusinessLogResolver resolver = new BusinessLogResolver();

    private static String fullUrl(HttpServletRequest request) {
        String queryString = request.getQueryString();
        String url = Objects.isNull(queryString) ? request.getRequestURL().toString() : request.getRequestURL() + "?" + queryString;
        return truncate(url, ValidationConstraints.URL_MAX_SIZE);
    }

    private static Long parseLong(String value) {
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException _) {
            return null;
        }
    }

    @Override
    public void afterCompletion(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull Object handler, Exception ex) {

        boolean success = Objects.isNull(ex) && response.getStatus() >= 200 && response.getStatus() < 300;
        if (!success || !(handler instanceof HandlerMethod method)) {
            return; // Only success operation are log
        }

        Set<BusinessLogType> types = resolver.resolve(method, request.getMethod());

        if (types.contains(BusinessLogType.CONSULTATION)) {
            save(request, () -> consultationLogRepo.save(toConsultation(request)));
        }

        if (types.contains(BusinessLogType.DELETION)) {
            save(request, () -> deletionLogRepo.save(toDeletion(request)));
        }
    }

    private void save(HttpServletRequest request, Runnable write) {
        try {
            write.run();
        } catch (RuntimeException ex) {
            log.error("Audit log not saved on [{} {}]", request.getMethod(), request.getRequestURI(), ex);
        }
    }

    private ConsultationLogEntryEntity toConsultation(HttpServletRequest request) {
        Long scopeId = parseLong(request.getParameter("scopeId"));
        String onlyActive = request.getParameter("onlyActive");

        ConsultationLogEntryEntity newConsultationLog = ConsultationLogEntryEntity.of(
                traceId(),
                fullUrl(request),
                userId()
        );

        newConsultationLog.setQueryParameters(truncate(request.getQueryString(), ValidationConstraints.QUERY_PARAMETERS_MAX_SIZE));
        newConsultationLog.setRequestBody(cachedBody(request));
        newConsultationLog.setMotive(motive(request));
        newConsultationLog.setOnlyActive(onlyActive != null ? Boolean.valueOf(onlyActive) : null);
        newConsultationLog.setConsultationScopeTypeEntity(
                scopeId != null ? consultationScopeTypeRepository.getReferenceById(scopeId) : null
        );
        return newConsultationLog;
    }

    private DeletionLogEntryEntity toDeletion(HttpServletRequest request) {
        DeletionLogEntryEntity newDeletionLog = DeletionLogEntryEntity.of(
                traceId(),
                fullUrl(request),
                userId()
        );
        newDeletionLog.setMotive(motive(request));
        return newDeletionLog;
    }

    /**
     * Body already cached by HttpAuditFilter (no second read of the stream), hidden.
     */
    private String cachedBody(HttpServletRequest request) {
        var cached = WebUtils.getNativeRequest(request, ContentCachingRequestWrapper.class);
        if (cached == null || cached.getContentAsByteArray().length == 0) {
            return null;
        }
        return truncate(masker.maskBody(cached.getContentAsByteArray()), ValidationConstraints.REQUEST_BODY_MAX_SIZE);
    }

    private static String motive(HttpServletRequest request) {
        return truncate(request.getParameter("motive"), ValidationConstraints.MOTIVE_MAX_SIZE);
    }

    private String traceId() {
        return truncate(currentTrace.auditTraceId(), ValidationConstraints.TRACE_ID_MAX_SIZE);
    }

    private String userId() {
        String userId = SecurityUtilities.getUsedIdFromSecurityContext().orElse(properties.unknownUser());
        return truncate(userId, ValidationConstraints.DEFAULT_VARCHAR_MAX_SIZE);
    }
}
