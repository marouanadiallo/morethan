package lu.pgd.dri.ischia.audit.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import feign.RequestInterceptor;
import io.micrometer.tracing.Tracer;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.audit.business.BusinessLogInterceptor;
import lu.pgd.dri.ischia.audit.feign.FeignAuditCapability;
import lu.pgd.dri.ischia.audit.http.AuditMasker;
import lu.pgd.dri.ischia.audit.http.HttpAuditFilter;
import lu.pgd.dri.ischia.audit.http.HttpAuditRecorder;
import lu.pgd.dri.ischia.audit.trace.CurrentTrace;
import lu.pgd.dri.ischia.audit.trace.TraceIdResponseFilter;
import lu.pgd.dri.ischia.domain.persistence.repository.AuditEntryRepository;
import lu.pgd.dri.ischia.domain.persistence.repository.AuditOutgoingRepository;
import lu.pgd.dri.ischia.domain.persistence.repository.ConsultationLogEntryRepository;
import lu.pgd.dri.ischia.domain.persistence.repository.DeletionLogEntryRepository;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.ConsultationScopeTypeRepository;
import org.jspecify.annotations.NonNull;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties(AuditProperties.class)
public class AuditConfiguration {

    /**
     * Filter orders: Micrometer = HIGHEST_PRECEDENCE + 1, Spring Security = -100.
     */
    private static final int TRACE_ID_FILTER_ORDER = Ordered.HIGHEST_PRECEDENCE + 2;
    private static final int AUDIT_FILTER_ORDER = -99;

    @Setter
    @Getter
    @Value("${spring.datasource.hikari.maximum-pool-size}")
    private int hikariMaxPoolSize;

    /**
     * In the absence of active tracing (e.g., during certain tests),
     * a null tracer is used instead of causing a crash.
     */
    @Bean
    CurrentTrace currentTrace(ObjectProvider<Tracer> tracer, AuditProperties properties) {
        return new CurrentTrace(tracer.getIfAvailable(() -> Tracer.NOOP), properties.unknownTrace());
    }

    @Bean
    AuditMasker auditMasker(ObjectMapper objectMapper, AuditProperties properties) {
        return new AuditMasker(objectMapper, properties.maskedHeaders(), properties.maskedFields());
    }

    @Bean
    HttpAuditRecorder httpAuditRecorder(AuditEntryRepository auditEntryRepository,
                                        AuditOutgoingRepository auditOutgoingRepository,
                                        AuditMasker masker, AuditProperties properties) {
        if (hikariMaxPoolSize <= 0) {
            throw new IllegalArgumentException("hikariMaxPoolSize must be greater than 0");
        }

        // rule: at most 1/4 of spring.datasource.hikari.maximum-pool-size
        int maxAllowedThreads = hikariMaxPoolSize / 4;

        if (properties.writerThreads() > maxAllowedThreads) {
            throw new IllegalArgumentException(String.format(
                    "Configuration error: 'properties.writerThreads' (%d) exceeds the maximum allowed limit. " +
                            "Rule: at most 1/4 of 'spring.datasource.hikari.maximum-pool-size' (%d), which is %d threads max.",
                    properties.writerThreads(), hikariMaxPoolSize, maxAllowedThreads
            ));
        }
        return new HttpAuditRecorder(auditEntryRepository, auditOutgoingRepository, masker,
                properties.writerThreads(), properties.queueCapacity());
    }

    @Bean
    FilterRegistrationBean<TraceIdResponseFilter> traceIdResponseFilter(CurrentTrace currentTrace, AuditProperties properties) {
        var registration = new FilterRegistrationBean<>(
                new TraceIdResponseFilter(currentTrace, properties.traceIdResponseHeader()));
        registration.setOrder(TRACE_ID_FILTER_ORDER);
        return registration;
    }

    @Bean
    FilterRegistrationBean<HttpAuditFilter> httpAuditFilter(HttpAuditRecorder recorder, AuditProperties properties, CurrentTrace currentTrace) {
        var registration = new FilterRegistrationBean<>(new HttpAuditFilter(recorder, properties, currentTrace));
        registration.setOrder(AUDIT_FILTER_ORDER);
        return registration;
    }

    /**
     * Consultation / Deletion audit interceptor
     */
    @Bean
    BusinessLogInterceptor businessLogInterceptor(ConsultationLogEntryRepository consultationLogRepository,
                                                  DeletionLogEntryRepository deletionLogRepository,
                                                  ConsultationScopeTypeRepository consultationScopeTypeRepository,
                                                  CurrentTrace currentTrace, AuditMasker masker,
                                                  AuditProperties properties) {
        return new BusinessLogInterceptor(consultationLogRepository, deletionLogRepository,
                consultationScopeTypeRepository, currentTrace, masker, properties);
    }

    @Bean
    WebMvcConfigurer webMvcConfigurer(BusinessLogInterceptor businessLogInterceptor) {
        return new WebMvcConfigurer() {
            @Override
            public void addInterceptors(@NonNull InterceptorRegistry registry) {
                registry.addInterceptor(businessLogInterceptor);
            }
        };
    }

    /**
     * Spring Cloud OpenFeign automatically applies this Capability to all @FeignClient instances.
     */
    @Bean
    FeignAuditCapability feignAuditCapability(HttpAuditRecorder recorder, CurrentTrace currentTrace) {
        return new FeignAuditCapability(recorder, currentTrace);
    }

    /**
     * Adds the origin app header (x-sender) on outGoing Feign requests
     * The service being called knows who is calling it.
     * The traceId is no longer added here: Micrometer already propagates it via Feign.
     */
    @Bean
    RequestInterceptor originAppFeignInterceptor(@Value("${spring.application.name:ischia-service}") String applicationName, AuditProperties properties) {
        return template -> {
            if (!template.headers().containsKey(properties.originAppHeader())) {
                template.header(properties.originAppHeader(), applicationName);
            }
        };
    }
}
