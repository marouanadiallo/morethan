package lu.pgd.dri.ischia.audit.business;

import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.http.HttpMethod;
import org.springframework.web.method.HandlerMethod;

import java.lang.reflect.Method;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Decides which business logs (consultation, deletion) apply to a handler call.
 * <p>
 * Rules, in order:
 * <ol>
 *   <li>{@link NoBusinessLog} on the method → nothing is logged.</li>
 *   <li>{@link ConsultationLog} and/or {@link DeletionLog} on the method → exactly those, whatever the HTTP verb;
 *       class-level annotations are ignored for this method.</li>
 *   <li>Otherwise, class-level annotations (searched on the controller class and its parents) apply by verb:
 *       {@code @ConsultationLog} → {@code GET} only, {@code @DeletionLog} → {@code DELETE} only.</li>
 * </ol>
 * HEAD requests (implicitly mapped to GET handlers by Spring) are not logged by the class-level rule:
 * no data is returned to the caller.
 * <p>
 * Annotation lookups are cached per (controller class, method): they are done once, not on every request.
 */
final class BusinessLogResolver {

    private final Map<Key, Rule> cache = new ConcurrentHashMap<>();

    Set<BusinessLogType> resolve(HandlerMethod handler, String httpMethod) {
        Rule rule = cache.computeIfAbsent(new Key(handler.getBeanType(), handler.getMethod()), _ -> Rule.of(handler));
        return rule.typesFor(httpMethod);
    }

    /**
     * The bean type is part of the key: an inherited method (e.g. from AbstractReferentialController)
     * is the same {@link Method} for every subclass, but each subclass may carry different class-level annotations.
     */
    private record Key(Class<?> beanType, Method method) {
    }

    private record Rule(boolean excluded,
                        boolean methodConsultation,
                        boolean methodDeletion,
                        boolean classConsultation,
                        boolean classDeletion) {

        static Rule of(HandlerMethod handler) {
            Class<?> controller = handler.getBeanType();
            return new Rule(
                    handler.hasMethodAnnotation(NoBusinessLog.class),
                    handler.hasMethodAnnotation(ConsultationLog.class),
                    handler.hasMethodAnnotation(DeletionLog.class),
                    // TYPE_HIERARCHY search: also finds the annotation on an abstract parent controller
                    AnnotatedElementUtils.hasAnnotation(controller, ConsultationLog.class),
                    AnnotatedElementUtils.hasAnnotation(controller, DeletionLog.class));
        }

        Set<BusinessLogType> typesFor(String httpMethod) {
            if (excluded) {
                return Set.of();
            }
            if (methodConsultation || methodDeletion) {
                Set<BusinessLogType> types = EnumSet.noneOf(BusinessLogType.class);
                if (methodConsultation) {
                    types.add(BusinessLogType.CONSULTATION);
                }
                if (methodDeletion) {
                    types.add(BusinessLogType.DELETION);
                }
                return types;
            }
            if (classConsultation && HttpMethod.GET.matches(httpMethod)) {
                return Set.of(BusinessLogType.CONSULTATION);
            }
            if (classDeletion && HttpMethod.DELETE.matches(httpMethod)) {
                return Set.of(BusinessLogType.DELETION);
            }
            return Set.of();
        }
    }
}
