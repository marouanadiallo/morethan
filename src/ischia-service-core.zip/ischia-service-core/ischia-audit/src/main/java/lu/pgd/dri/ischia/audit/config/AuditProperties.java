package lu.pgd.dri.ischia.audit.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

import java.util.List;
import java.util.Set;

/**
 * The maximum size for bodies comes from ValidationConstraints
 *
 * @param includedPaths         audited paths, Ant patterns excluding context-path (replaces restServiceUri)
 * @param excludedPaths         paths that have never been audited, with priority over includedPaths
 * @param writerThreads         Threads that write the audit to the database = maximum connections taken from the pool ;
 *                              rule: at most 1/4 of spring.datasource.hikari.maximum-pool-size
 * <br>
 * @param queueCapacity         max. pending events; queue full = event ignored, never blocking
 * @param maskedHeaders         headers replaced by ***
 * @param maskedFields          JSON fields replaced by *** (replaces ignoredJsonFields)
 * @param originAppHeader       header that identifies the calling application
 * @param undefinedSender       value of this header to be considered absent
 * @param unknownUser           user stored when no one is authenticated
 * @param traceIdResponseHeader response header that returns the traceId to the client
 * @param unknownTrace          traceId stored when no span is active (TRACE_ID columns are NOT NULL)
 */
@ConfigurationProperties("api.audit")
public record AuditProperties(
        @DefaultValue("/api/**") List<String> includedPaths,
        @DefaultValue("/actuator/**") List<String> excludedPaths,
        @DefaultValue("2") int writerThreads,
        @DefaultValue("10000") int queueCapacity,
        @DefaultValue({"authorization", "cookie", "set-cookie", "proxy-authorization"}) Set<String> maskedHeaders,
        @DefaultValue({"password", "token", "secret"}) Set<String> maskedFields,
        @DefaultValue("x-sender") String originAppHeader,
        @DefaultValue("x-sender_not-define") String undefinedSender,
        @DefaultValue("UNKNOWN_USER") String unknownUser,
        @DefaultValue("x-b3-trace-id") String traceIdResponseHeader,
        @DefaultValue("NO_TRACE") String unknownTrace
) {
}
