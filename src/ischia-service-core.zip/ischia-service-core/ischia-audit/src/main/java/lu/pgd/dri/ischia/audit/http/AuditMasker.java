package lu.pgd.dri.ischia.audit.http;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Getter;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Getter
public class AuditMasker {

    private static final String MASK = "***";

    private final ObjectMapper objectMapper;
    private final Set<String> maskedHeaders;
    private final Set<String> maskedFields;
    private final Pattern fallbackPattern;

    public AuditMasker(ObjectMapper objectMapper, Set<String> maskedHeaders, Set<String> maskedFields) {
        this.objectMapper = objectMapper;
        this.maskedHeaders = lowerCase(maskedHeaders);
        this.maskedFields = lowerCase(maskedFields);
        this.fallbackPattern = buildFallbackPattern(this.maskedFields);
    }

    private static Set<String> lowerCase(Set<String> values) {
        return values.stream().map(String::toLowerCase).collect(Collectors.toUnmodifiableSet());
    }

    private static Pattern buildFallbackPattern(Set<String> fields) {
        if (fields.isEmpty()) {
            return null;
        }
        String alternatives = fields.stream().map(Pattern::quote).collect(Collectors.joining("|"));
        return Pattern.compile("(\"(?:" + alternatives + ")\"\\s*:\\s*)(\"[^\"]*\"?|[^,}\\]]*)",
                Pattern.CASE_INSENSITIVE);
    }

    public String formatHeaders(Map<String, List<String>> headers) {
        return headers.entrySet().stream()
                .map(header -> header.getKey() + ":" + headerValue(header.getKey(), header.getValue()))
                .collect(Collectors.joining(";"));
    }

    private String headerValue(String name, List<String> values) {
        return maskedHeaders.contains(name.toLowerCase()) ? MASK : String.join(",", values);
    }

    public String maskBody(byte[] body) {
        if (body == null || body.length == 0) {
            return null;
        }
        String text = new String(body, StandardCharsets.UTF_8);
        try {
            JsonNode root = objectMapper.readTree(text);
            maskNode(root);
            return objectMapper.writeValueAsString(root);
        } catch (JsonProcessingException _) {
            return maskWithRegex(text);
        }
    }

    private void maskNode(JsonNode node) {
        if (node instanceof ObjectNode object) {
            List<String> fieldNames = object.properties().stream().map(Map.Entry::getKey).toList();
            for (String fieldName : fieldNames) {
                if (isMaskedField(fieldName)) {
                    object.put(fieldName, MASK);
                } else {
                    maskNode(object.get(fieldName));
                }
            }
        } else if (node != null && node.isArray()) {
            node.forEach(this::maskNode);
        }
    }

    private String maskWithRegex(String text) {
        if (fallbackPattern == null) {
            return text;
        }
        return fallbackPattern.matcher(text).replaceAll("$1\"" + MASK + "\"");
    }

    private boolean isMaskedField(String fieldName) {
        return maskedFields.contains(fieldName.toLowerCase());
    }
}
