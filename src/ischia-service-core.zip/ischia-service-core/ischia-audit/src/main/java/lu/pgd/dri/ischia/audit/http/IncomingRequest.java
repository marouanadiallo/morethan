package lu.pgd.dri.ischia.audit.http;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Copy of an INCOMING request, destined for the AUDIT_ENTRY table.
 *<br>
 * Why a copy: Undertow reuses request/response objects as soon as the response has been sent.
 * The writing thread therefore reads this record, never the request itself.
 */
public record IncomingRequest(
        String traceId,
        String method,
        String url,
        Map<String, List<String>> headers,
        byte[] jsonBody,
        int status,
        String userId,
        String originApp,
        Instant start,
        Instant end) {
}