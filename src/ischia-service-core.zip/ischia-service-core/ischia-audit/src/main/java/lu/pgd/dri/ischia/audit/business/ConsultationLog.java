package lu.pgd.dri.ischia.audit.business;

import java.lang.annotation.*;

/**
 * Marker: successful (2xx) calls are written to IS_CONSULTATION_LOG_CL.
 * <ul>
 *   <li><b>On a method</b>: the method is logged as a consultation, whatever its HTTP verb
 *       (e.g. {@code POST /search}).</li>
 *   <li><b>On a class</b> (or an abstract parent class): every {@code GET} handler of the class is logged
 *       as a consultation. Other verbs are not affected.</li>
 * </ul>
 * A method carrying its own {@code @ConsultationLog} / {@code @DeletionLog} ignores the class-level annotations.
 * Use {@link NoBusinessLog} to exclude a method. Full rules: {@link BusinessLogResolver}.
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface ConsultationLog {
}
