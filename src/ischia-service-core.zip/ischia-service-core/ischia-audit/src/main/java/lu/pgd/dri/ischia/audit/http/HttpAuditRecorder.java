package lu.pgd.dri.ischia.audit.http;

import lombok.extern.slf4j.Slf4j;
import lu.pgd.dri.ischia.audit.config.ValidationConstraints;
import lu.pgd.dri.ischia.domain.persistence.entity.AuditEntryEntity;
import lu.pgd.dri.ischia.domain.persistence.entity.AuditOutgoingEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.AuditEntryRepository;
import lu.pgd.dri.ischia.domain.persistence.repository.AuditOutgoingRepository;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import static lu.pgd.dri.ischia.audit.config.Truncator.truncate;

/**
 * Writes the HTTP audit to the database in the background:
 *  AUDIT_ENTRY for incoming traffic
 *  AUDIT_OUTGOING for outgoing traffic.
 *
 * <br>
 *  Operation: A Spring `ThreadPoolTaskExecutor` dedicated to auditing (intentionally not defined as a bean, to avoid overriding the application's `@Async` executor),
 *  featuring:
 *  - A fixed number of threads (configured via `audit.writer-threads`, defaulting to 2) — meaning at most N connections are drawn from the pool;
 *  - A bounded queue (configured via `audit.queue-capacity`) — ensuring memory usage cannot spiral out of control;
 *  - A mechanism where, if the queue is full, the event is discarded and a warning is logged — ensuring the request NEVER has to wait.
 */
@Slf4j
public class HttpAuditRecorder implements DisposableBean {

    private final AuditEntryRepository auditEntryRepository;
    private final AuditOutgoingRepository auditOutgoingRepository;
    private final AuditMasker masker;

    private final ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();

    public HttpAuditRecorder(AuditEntryRepository auditEntryRepository,
                             AuditOutgoingRepository auditOutgoingRepository,
                             AuditMasker masker, int threads, int queueCapacity) {

        this.auditEntryRepository = auditEntryRepository;
        this.auditOutgoingRepository = auditOutgoingRepository;
        this.masker = masker;

        executor.setThreadNamePrefix("audit-writer-");
        executor.setCorePoolSize(threads);
        executor.setMaxPoolSize(threads);
        executor.setQueueCapacity(queueCapacity);
        executor.setRejectedExecutionHandler(
                (_, _) ->log.warn("Audit queue full: an audit event is ignored")
        );
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(10);
        executor.initialize();
    }

    public void recordIncoming(IncomingRequest request) {
        executor.execute(() -> save(request.url(), () -> auditEntryRepository.save(toAuditEntry(request))));
    }

    public void recordOutgoing(OutgoingCall call) {
        executor.execute(() -> save(call.url(), () -> auditOutgoingRepository.save(toAuditOutgoing(call))));
    }

    private void save(String url, Runnable insert) {
        try {
            insert.run();
        } catch (Exception e) {
            // An audit must never break the application: log the event and carry on.
            log.warn("Unrecorded audit for [{}] : {}", url, e.getMessage());
        }
    }
    /**
     * Start/end dates come from the request itself (captured in the filter),
     * never from Instant.now(): the write happens later, in the background.
     */
    private AuditEntryEntity toAuditEntry(IncomingRequest r) {
        AuditEntryEntity newAuditEntry = AuditEntryEntity.of(
                truncate(r.traceId(), ValidationConstraints.TRACE_ID_MAX_SIZE),
                truncate(r.userId(), ValidationConstraints.DEFAULT_VARCHAR_MAX_SIZE),
                truncate(r.method(), ValidationConstraints.ACTION_MAX_SIZE),
                r.start());
        newAuditEntry.setEndDate(r.end());
        newAuditEntry.setOriginApp(truncate(r.originApp(), ValidationConstraints.DEFAULT_VARCHAR_MAX_SIZE));
        newAuditEntry.setStatus(truncate(String.valueOf(r.status()), ValidationConstraints.STATUS_MAX_SIZE));
        newAuditEntry.setHeaders(truncate(masker.formatHeaders(r.headers()), ValidationConstraints.HEADERS_MAX_SIZE));
        newAuditEntry.setUrl(truncate(r.url(), ValidationConstraints.URL_MAX_SIZE));
        newAuditEntry.setRequestBody(truncate(masker.maskBody(r.jsonBody()), ValidationConstraints.REQUEST_BODY_MAX_SIZE));
        return newAuditEntry;
    }

    private AuditOutgoingEntity toAuditOutgoing(OutgoingCall c) {
        String response = c.error() != null ? c.error() : masker.maskBody(c.responseBody());
        AuditOutgoingEntity newAuditOutgoing = AuditOutgoingEntity.of(
                truncate(c.traceId(), ValidationConstraints.DEFAULT_VARCHAR_MAX_SIZE),
                truncate(c.method(), ValidationConstraints.ACTION_MAX_SIZE),
                truncate(c.status(), ValidationConstraints.STATUS_MAX_SIZE),
                c.start()
        );
        newAuditOutgoing.setEndDate(c.end());
        newAuditOutgoing.setUrl(truncate(c.url(), ValidationConstraints.URL_MAX_SIZE));
        newAuditOutgoing.setResponseBody(truncate(response, ValidationConstraints.REQUEST_BODY_MAX_SIZE));
        newAuditOutgoing.setRequestBody(truncate(masker.maskBody(c.requestBody()), ValidationConstraints.REQUEST_BODY_MAX_SIZE));

        return newAuditOutgoing;
    }

    /**
     * Application shutdown: no new requests are accepted, and the existing queue is processed (10 seconds maximum).
     * Spring invokes `destroy()` after the web server has shut down but before JPA shuts down,
     * ensuring that the final requests are successfully written.
     */
    @Override
    public void destroy() {
        executor.shutdown();
    }
}
