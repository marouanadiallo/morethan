package lu.pgd.dri.ischia.audit.http;

import java.time.Instant;

/**
 * Copy of an OUTGOING Feign call, intended for the AUDIT_OUTGOING table.
 *<br>
 * @param status HTTP code as text; "0" when the server did not respond (timeout, connection refused)
 * @param error  network exception message, or null otherwise
 */
public record OutgoingCall(
        String traceId,
        String method,
        String url,
        byte[] requestBody,
        byte[] responseBody,
        String status,
        String error,
        Instant start,
        Instant end
) {
}
