package lu.pgd.dri.ischia.audit.feign;

import feign.Capability;
import feign.Client;
import lombok.RequiredArgsConstructor;
import lu.pgd.dri.ischia.audit.http.HttpAuditRecorder;
import lu.pgd.dri.ischia.audit.trace.CurrentTrace;

/**
 * Enable auditing on ALL @FeignClient interfaces
 *
 * <br>
 * Why a Capability instead of a @Primary Client (formerly FeignAuditConfig):
 * The @Primary Client replaced the Spring Cloud client with a bare-bones Client.Default
 * (no load balancer, no connection pool, no SSL configuration).
 *  A Capability WRAPS the already-configured client: it adds auditing without removing anything.
 * This is the same mechanism that Micrometer uses to trace Feign.
 */
@RequiredArgsConstructor
public class FeignAuditCapability implements Capability {

    private final HttpAuditRecorder recorder;
    private final CurrentTrace currentTrace;

    @Override
    public Client enrich(Client client) {
        return new FeignAuditClient(client, recorder, currentTrace);
    }
}
