package lu.pgd.dri.ischia.audit.business;

enum BusinessLogType {
    CONSULTATION,
    DELETION
}
