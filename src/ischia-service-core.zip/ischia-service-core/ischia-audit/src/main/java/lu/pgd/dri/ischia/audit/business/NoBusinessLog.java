package lu.pgd.dri.ischia.audit.business;

import java.lang.annotation.*;

/**
 * Excludes a handler method from the consultation / deletion logs,
 * even when its class carries {@link ConsultationLog} or {@link DeletionLog}.
 * <br>
 * Takes priority over every other business-log annotation on the same method.
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface NoBusinessLog {
}
