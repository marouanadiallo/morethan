package lu.pgd.dri.ischia.audit.feign;

import feign.Client;
import feign.Request;
import feign.Response;
import lombok.RequiredArgsConstructor;
import lu.pgd.dri.ischia.audit.config.ValidationConstraints;
import lu.pgd.dri.ischia.audit.http.HttpAuditRecorder;
import lu.pgd.dri.ischia.audit.http.OutgoingCall;
import lu.pgd.dri.ischia.audit.trace.CurrentTrace;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.SequenceInputStream;
import java.time.Instant;
import java.util.Arrays;
import java.util.Objects;

/**
 * Audit of OUTGOING calls, to AUDIT_OUTGOING
 * Wraps the actual client (see FeignAuditCapability).
 *
 * <br>
 * Three cases, three paths:
 * 1. the called server does not respond (timeout, connection refused) => status "0" + error message;
 * 2. response without a body (204, HEAD) => status only;
 * 3. Response with a body => we read the beginning for auditing purposes, then return the body intact to Feign.
 */
@RequiredArgsConstructor
class FeignAuditClient implements Client {

    private static final int MAX_BODY = ValidationConstraints.REQUEST_BODY_MAX_SIZE;

    private final Client delegate;
    private final HttpAuditRecorder recorder;
    private final CurrentTrace currentTrace;


    @Override
    public Response execute(Request request, Request.Options options) throws IOException {
        Instant start = Instant.now();

        Response response;
        try {
            response = delegate.execute(request, options);
        } catch (IOException e) {
            recordIt(request, "0", null, e.getClass().getSimpleName() + ": " + e.getMessage(), start);
            throw e;
        }

        if (Objects.isNull(response.body())) {
            recordIt(request, String.valueOf(response.status()), null, null, start);
            return response;
        }

        // The body is a stream that can be read only ONCE.
        // We read the beginning for the audit, then return "the already-read beginning + the remainder of the stream" to Feign.
        // Without this, the Feign decoder would receive an empty body.
        InputStream body = response.body().asInputStream();
        byte[] head = body.readNBytes(MAX_BODY);
        recordIt(request, String.valueOf(response.status()), head, null, start);

        return response.toBuilder()
                .body(new SequenceInputStream(new ByteArrayInputStream(head), body), response.body().length())
                .build();
    }

    private void recordIt(Request request, String status, byte[] responseBody, String error, Instant start) {
        try {
            byte[] requestBody = Objects.isNull(request.body()) ? null :
                    Arrays.copyOf(request.body(), Math.min(request.body().length, MAX_BODY));

            recorder.recordOutgoing(new OutgoingCall(
                    currentTrace.auditTraceId(),
                    request.httpMethod().name(),
                    request.url(),
                    requestBody,
                    responseBody,
                    status,
                    error,
                    start,
                    Instant.now()));

        } catch (RuntimeException _) {
            // The audit never breaks the Feign call.
        }
    }
}
