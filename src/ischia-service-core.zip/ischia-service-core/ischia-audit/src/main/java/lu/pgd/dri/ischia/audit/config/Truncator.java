package lu.pgd.dri.ischia.audit.config;

public final class Truncator {

    private static final String TRUNCATION_MARKER = "...[truncated]";

    private Truncator() {
    }

    /**
     * Cuts the value to {@code maxLength} characters, ending with a visible marker when there is room for it.
     * A null value stays null.
     */
    public static String truncate(String value, int maxLength) {
        if (value == null || value.length() <= maxLength) {
            return value;
        }
        if (maxLength <= TRUNCATION_MARKER.length()) {
            return value.substring(0, maxLength);
        }
        return value.substring(0, maxLength - TRUNCATION_MARKER.length()) + TRUNCATION_MARKER;
    }
}
