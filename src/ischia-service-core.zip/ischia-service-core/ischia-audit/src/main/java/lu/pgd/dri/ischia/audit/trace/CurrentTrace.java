package lu.pgd.dri.ischia.audit.trace;

import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import lombok.RequiredArgsConstructor;

import java.util.Objects;


@RequiredArgsConstructor
public class CurrentTrace {

    private final Tracer tracer;

    /** Value stored in the audit tables when no span is active (NOOP tracer, thread without context...). */
    private final String unknownTrace;

    /**
     * @return the current traceId, or null when no span is active
     */
    public String traceId() {
        Span span = tracer.currentSpan();
        return Objects.isNull(span) ? null : span.context().traceId();
    }

    /**
     * TRACE_ID columns are NOT NULL: a null value would make the INSERT fail and the audit line be lost.
     *
     * @return the current traceId, or the configured fallback (never null)
     */
    public String auditTraceId() {
        return Objects.requireNonNullElse(traceId(), unknownTrace);
    }
}
