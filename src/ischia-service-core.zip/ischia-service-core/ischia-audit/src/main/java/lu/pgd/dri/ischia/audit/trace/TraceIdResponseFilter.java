package lu.pgd.dri.ischia.audit.trace;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.jspecify.annotations.NonNull;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@RequiredArgsConstructor
public class TraceIdResponseFilter extends OncePerRequestFilter {

    private final CurrentTrace currentTrace;
    private final  String headerName;

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain) throws ServletException, IOException {

        String traceId = currentTrace.traceId();
        if (traceId != null) {
            // before the response is sent
            response.setHeader(headerName, traceId);
        }
        filterChain.doFilter(request, response);

    }
}
