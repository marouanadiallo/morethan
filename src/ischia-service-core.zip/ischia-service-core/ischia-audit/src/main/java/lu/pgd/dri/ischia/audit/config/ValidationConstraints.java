package lu.pgd.dri.ischia.audit.config;

/**
 * Column sizes of the audit tables. Every value written by the audit module
 * must be truncated to these limits (see {@link Truncator}), otherwise the INSERT fails
 * and the audit line is lost.
 */
public final class ValidationConstraints {
    public static final int STATUS_MAX_SIZE = 3;
    public static final int ACTION_MAX_SIZE = 10;
    public static final int TRACE_ID_MAX_SIZE = 64;
    public static final int URL_MAX_SIZE = 2000;
    public static final int QUERY_PARAMETERS_MAX_SIZE = 2000;
    public static final int HEADERS_MAX_SIZE = 4000;
    public static final int MOTIVE_MAX_SIZE = 300;
    /** Columns declared without length => JPA default (255). */
    public static final int DEFAULT_VARCHAR_MAX_SIZE = 255;
    public static final int REQUEST_BODY_MAX_SIZE = 1_000_000;

    private ValidationConstraints() {
    }
}
