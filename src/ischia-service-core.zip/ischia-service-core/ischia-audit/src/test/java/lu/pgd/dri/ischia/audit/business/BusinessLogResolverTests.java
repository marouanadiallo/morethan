package lu.pgd.dri.ischia.audit.business;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.web.method.HandlerMethod;

import static lu.pgd.dri.ischia.audit.business.BusinessLogType.CONSULTATION;
import static lu.pgd.dri.ischia.audit.business.BusinessLogType.DELETION;
import static org.assertj.core.api.Assertions.assertThat;

class BusinessLogResolverTests {

    private final BusinessLogResolver resolver = new BusinessLogResolver();

    // ---------------------------------------------------------------- fake controllers

    @ConsultationLog
    @DeletionLog
    static class ClassAnnotatedController {
        public void get() { }
        public void delete() { }
        public void create() { }
        @ConsultationLog public void search() { }
        @DeletionLog public void purge() { }
        @NoBusinessLog public void count() { }
        @NoBusinessLog @ConsultationLog public void contradictory() { }
    }

    static class NotAnnotatedController {
        public void get() { }
        @ConsultationLog public void search() { }
        @DeletionLog public void delete() { }
    }

    @ConsultationLog
    abstract static class AbstractParentController {
        public void get() { }
    }

    static class ChildController extends AbstractParentController { }

    static class OtherChildController extends NotAnnotatedParent { }

    static class NotAnnotatedParent {
        public void get() { }
    }

    private static HandlerMethod handler(Object controller, Class<?> declaringClass, String methodName) {
        try {
            return new HandlerMethod(controller, declaringClass.getMethod(methodName));
        } catch (NoSuchMethodException e) {
            throw new IllegalStateException(e);
        }
    }

    private static HandlerMethod handler(Object controller, String methodName) {
        return handler(controller, controller.getClass(), methodName);
    }

    // ---------------------------------------------------------------- tests

    @Nested
    class ClassLevel {

        private final ClassAnnotatedController controller = new ClassAnnotatedController();

        @Test
        void getIsLoggedAsConsultation() {
            assertThat(resolver.resolve(handler(controller, "get"), "GET")).containsExactly(CONSULTATION);
        }

        @Test
        void deleteIsLoggedAsDeletion() {
            assertThat(resolver.resolve(handler(controller, "delete"), "DELETE")).containsExactly(DELETION);
        }

        @Test
        void postAndPutAreNotLogged() {
            assertThat(resolver.resolve(handler(controller, "create"), "POST")).isEmpty();
            assertThat(resolver.resolve(handler(controller, "create"), "PUT")).isEmpty();
            assertThat(resolver.resolve(handler(controller, "create"), "PATCH")).isEmpty();
        }

        @Test
        void headIsNotLogged() {
            assertThat(resolver.resolve(handler(controller, "get"), "HEAD")).isEmpty();
        }

        @Test
        void inheritedFromAbstractParent() {
            HandlerMethod inherited = handler(new ChildController(), AbstractParentController.class, "get");
            assertThat(resolver.resolve(inherited, "GET")).containsExactly(CONSULTATION);
        }

        @Test
        void sameInheritedMethodDependsOnTheConcreteController() {
            // cache key = (controller class, method): a non-annotated parent gives nothing
            HandlerMethod inherited = handler(new OtherChildController(), NotAnnotatedParent.class, "get");
            assertThat(resolver.resolve(inherited, "GET")).isEmpty();
        }
    }

    @Nested
    class MethodLevel {

        @Test
        void consultationOnPostIsLogged() {
            assertThat(resolver.resolve(handler(new NotAnnotatedController(), "search"), "POST"))
                    .containsExactly(CONSULTATION);
        }

        @Test
        void deletionOnMethodIsLogged() {
            assertThat(resolver.resolve(handler(new NotAnnotatedController(), "delete"), "DELETE"))
                    .containsExactly(DELETION);
        }

        @Test
        void methodAnnotationReplacesClassAnnotations() {
            ClassAnnotatedController controller = new ClassAnnotatedController();
            // explicit @DeletionLog on a GET: the class-level @ConsultationLog is ignored
            assertThat(resolver.resolve(handler(controller, "purge"), "GET")).containsExactly(DELETION);
            // explicit @ConsultationLog on a POST
            assertThat(resolver.resolve(handler(controller, "search"), "POST")).containsExactly(CONSULTATION);
        }

        @Test
        void noAnnotationAnywhereIsNotLogged() {
            assertThat(resolver.resolve(handler(new NotAnnotatedController(), "get"), "GET")).isEmpty();
        }
    }

    @Nested
    class Exclusion {

        @Test
        void noBusinessLogExcludesFromClassRule() {
            assertThat(resolver.resolve(handler(new ClassAnnotatedController(), "count"), "GET")).isEmpty();
        }

        @Test
        void noBusinessLogWinsOverMethodAnnotation() {
            assertThat(resolver.resolve(handler(new ClassAnnotatedController(), "contradictory"), "GET")).isEmpty();
        }
    }

    @Test
    void resultIsStableAcrossCalls() {
        HandlerMethod get = handler(new ClassAnnotatedController(), "get");
        assertThat(resolver.resolve(get, "GET")).containsExactly(CONSULTATION);
        assertThat(resolver.resolve(get, "GET")).containsExactly(CONSULTATION);
        // same cached rule, other verb
        assertThat(resolver.resolve(get, "POST")).isEmpty();
    }
}
