package lu.pgd.dri.ischia.domainapi.response;

import java.time.LocalDate;

public record ReferentialUserUnitResponse(
        Long id,
        Long organizationId,
        String code,
        String labelFr,
        String labelEn,
        String labelDe,
        LocalDate validityFrom,
        LocalDate validityTo
) { }