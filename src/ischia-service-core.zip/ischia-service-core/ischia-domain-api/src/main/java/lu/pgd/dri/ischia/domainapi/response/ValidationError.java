package lu.pgd.dri.ischia.domainapi.response;

/**
 * One invalid input, returned in the {@code errors} array of a 400 ProblemDetail (RFC 9457).
 *
 * <pre>
 * {
 *   "status": 400,
 *   "title": "Invalid request",
 *   "detail": "The request contains invalid fields.",
 *   "errors": [
 *     { "field": "subject",             "code": "NotBlank", "message": "must not be blank" },
 *     { "field": "recipients[1].email", "code": "Email",    "message": "must be a well-formed email address" },
 *     { "field": "observers[0]",        "code": "NotBlank", "message": "must not be blank" },
 *     { "field": null,                  "code": "ValidPeriod", "message": "..." }
 *   ]
 * }
 * </pre>
 *
 * @param field   path of the invalid value, as in the request JSON ({@code a.b[2].c}); for a query / path parameter,
 *                its name; {@code null} for an error on the whole object (class-level constraint without property node)
 * @param code    stable, language-independent code to branch on in the front: the constraint name
 *                ({@code NotBlank}, {@code Size}, custom {@code ValidPeriod}...) or {@code InvalidFormat}
 * @param message message translated in the request language (Accept-Language), ready to display
 */
public record ValidationError(String field, String code, String message) {
}
