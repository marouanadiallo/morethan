package lu.pgd.dri.ischia.domainapi.response;

import java.time.LocalDate;

public record ChannelReferentialResponse(
        Long id,
        Long channelId,
        String code,
        String labelFr,
        String labelEn,
        String labelDe,
        LocalDate validityFrom,
        LocalDate validityTo
) {
}
