package lu.pgd.dri.ischia.domainapi.request;

public record MessageRequest() {
}
