package lu.pgd.dri.ischia.domainapi.response;

import java.time.LocalDate;

public record ReferentialCountryResponse(
        Long id,
        String alphaCode2,
        String alphaCode3,
        String labelFr,
        String labelEn,
        String labelDe,
        LocalDate validityFrom,
        LocalDate validityTo
) {
}
