package lu.pgd.dri.ischia.domainapi.response;

import java.time.LocalDate;

public record ReferentialResponse(
        Long id,
        String code,
        String labelFr,
        String labelEn,
        String labelDe,
        LocalDate validityFrom,
        LocalDate validityTo
) { }
