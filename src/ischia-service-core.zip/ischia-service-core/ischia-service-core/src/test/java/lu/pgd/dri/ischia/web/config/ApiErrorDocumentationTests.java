package lu.pgd.dri.ischia.web.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.responses.ApiResponses;
import lu.pgd.dri.ischia.web.controller.AbstractChannelReferentialController;
import lu.pgd.dri.ischia.web.controller.AbstractReferentialController;
import lu.pgd.dri.ischia.web.controller.referential.MessagePriorityController;
import lu.pgd.dri.ischia.web.controller.referential.MessageTypeController;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.method.HandlerMethod;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class ApiErrorDocumentationTests {

    private final ApiErrorDocumentation documentation = new ApiErrorDocumentation();

    private ApiResponses responsesOf(Object controller, String methodName, Class<?>... parameterTypes) throws Exception {
        HandlerMethod handlerMethod = new HandlerMethod(controller, controller.getClass().getMethod(methodName, parameterTypes));
        return documentation.customize(new Operation(), handlerMethod).getResponses();
    }

    // ---------------------------------------------------------------- fake endpoints (not @RestController: never scanned)

    static class FakeController {
        @GetMapping public void list() { }
        @GetMapping("/{id}") public void getById(@PathVariable Long id) { }
        @GetMapping("/search") public void search(@RequestParam String q) { }
        @PostMapping public void create(@RequestBody Object body) { }
        @PutMapping("/{id}") public void update(@PathVariable Long id, @RequestBody Object body) { }
        @DeleteMapping("/{id}") public void delete(@PathVariable Long id) { }
        @PreAuthorize("hasRole('ADMIN')") @GetMapping("/admin") public void admin() { }
    }

    @PreAuthorize("hasRole('ADMIN')")
    static class SecuredController {
        @GetMapping public void list() { }
    }

    // ---------------------------------------------------------------- rules

    @Nested
    class Rules {

        @Test
        void endpointWithoutInputOnlyHasAuthenticationAndServerErrors() throws Exception {
            assertThat(responsesOf(new FakeController(), "list")).containsOnlyKeys("401", "500");
        }

        @Test
        void pathVariableAddsBadRequestAndNotFound() throws Exception {
            assertThat(responsesOf(new FakeController(), "getById", Long.class))
                    .containsOnlyKeys("400", "401", "404", "500");
        }

        @Test
        void queryParameterAddsBadRequestOnly() throws Exception {
            assertThat(responsesOf(new FakeController(), "search", String.class))
                    .containsOnlyKeys("400", "401", "500");
        }

        @Test
        void creationAddsBadRequestAndConflict() throws Exception {
            assertThat(responsesOf(new FakeController(), "create", Object.class))
                    .containsOnlyKeys("400", "401", "409", "500");
        }

        @Test
        void updateHasEveryApplicableError() throws Exception {
            assertThat(responsesOf(new FakeController(), "update", Long.class, Object.class))
                    .containsOnlyKeys("400", "401", "404", "409", "500");
        }

        @Test
        void deletionAddsNotFoundAndConflict() throws Exception {
            assertThat(responsesOf(new FakeController(), "delete", Long.class))
                    .containsOnlyKeys("400", "401", "404", "409", "500");
        }

        @Test
        void roleOnMethodAddsForbidden() throws Exception {
            assertThat(responsesOf(new FakeController(), "admin")).containsOnlyKeys("401", "403", "500");
        }

        @Test
        void roleOnClassAddsForbidden() throws Exception {
            assertThat(responsesOf(new SecuredController(), "list")).containsKey("403");
        }

        @Test
        void explicitResponseOnTheEndpointIsNeverOverwritten() throws Exception {
            ApiResponse custom = new ApiResponse().description("Message not found or archived");
            Operation operation = new Operation().responses(new ApiResponses()
                    .addApiResponse("200", new ApiResponse().description("OK"))
                    .addApiResponse("404", custom));
            HandlerMethod getById = new HandlerMethod(new FakeController(),
                    FakeController.class.getMethod("getById", Long.class));

            ApiResponses responses = documentation.customize(operation, getById).getResponses();

            assertThat(responses.get("404")).isSameAs(custom);
            assertThat(responses).containsKeys("200", "400", "401", "500");
        }

        @Test
        void operationsReferenceSharedComponents() throws Exception {
            ApiResponses responses = responsesOf(new FakeController(), "update", Long.class, Object.class);

            assertThat(responses.get("400").get$ref()).isEqualTo("#/components/responses/BadRequest");
            assertThat(responses.get("404").get$ref()).isEqualTo("#/components/responses/NotFound");
            assertThat(responses.get("409").get$ref()).isEqualTo("#/components/responses/Conflict");
        }
    }

    // ---------------------------------------------------------------- real endpoints

    @Nested
    class RealReferentialEndpoints {

        @Test
        void genericReferentialList() throws Exception {
            HandlerMethod getAll = new HandlerMethod(new MessageTypeController(null),
                    AbstractReferentialController.class.getMethod("getAll"));
            assertThat(documentation.customize(new Operation(), getAll).getResponses())
                    .containsOnlyKeys("401", "500");
        }

        @Test
        void genericReferentialById() throws Exception {
            HandlerMethod getById = new HandlerMethod(new MessageTypeController(null),
                    AbstractReferentialController.class.getMethod("getById", Long.class));
            assertThat(documentation.customize(new Operation(), getById).getResponses())
                    .containsOnlyKeys("400", "401", "404", "500");
        }

        @Test
        void channelReferentialListWithOptionalChannelFilter() throws Exception {
            HandlerMethod getAll = new HandlerMethod(new MessagePriorityController(null),
                    AbstractChannelReferentialController.class.getMethod("getAll", Long.class));
            // ?channelId=abc → 400
            assertThat(documentation.customize(new Operation(), getAll).getResponses())
                    .containsOnlyKeys("400", "401", "500");
        }
    }

    // ---------------------------------------------------------------- components

    @Nested
    class SharedComponents {

        @Test
        void everyReferencedResponseAndSchemaIsDeclared() {
            OpenAPI openApi = new OpenAPI();
            documentation.addComponents(openApi);

            assertThat(openApi.getComponents().getResponses()).containsOnlyKeys(
                    "BadRequest", "Unauthorized", "Forbidden", "NotFound", "Conflict", "InternalError");
            assertThat(openApi.getComponents().getSchemas()).containsKeys(
                    "ProblemDetail", "ValidationProblemDetail", "ValidationError");
        }

        @Test
        void badRequestDocumentsTheErrorsArrayWithAnExample() {
            OpenAPI openApi = new OpenAPI();
            documentation.addComponents(openApi);

            ApiResponse badRequest = openApi.getComponents().getResponses().get("BadRequest");
            var mediaType = badRequest.getContent().get("application/problem+json");
            assertThat(mediaType.getSchema().get$ref()).isEqualTo("#/components/schemas/ValidationProblemDetail");
            assertThat((Map<?, ?>) mediaType.getExample()).containsKey("errors");

            assertThat(openApi.getComponents().getSchemas().get("ValidationProblemDetail").getProperties())
                    .containsKeys("type", "title", "status", "detail", "instance", "timestamp", "errors");
            assertThat(openApi.getComponents().getSchemas().get("ValidationError").getProperties())
                    .containsOnlyKeys("field", "code", "message");
        }

        @Test
        void unauthorizedHasNoBodyButDocumentsTheHeader() {
            OpenAPI openApi = new OpenAPI();
            documentation.addComponents(openApi);

            ApiResponse unauthorized = openApi.getComponents().getResponses().get("Unauthorized");
            assertThat(unauthorized.getContent()).isNull();
            assertThat(unauthorized.getHeaders()).containsKey("WWW-Authenticate");
        }

        @Test
        void keepsExistingComponents() {
            OpenAPI openApi = new OpenAPI().components(new io.swagger.v3.oas.models.Components()
                    .addSchemas("MessageResponse", new io.swagger.v3.oas.models.media.ObjectSchema()));
            documentation.addComponents(openApi);

            assertThat(openApi.getComponents().getSchemas()).containsKey("MessageResponse");
        }
    }
}
