package lu.pgd.dri.ischia.web.controller;

import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.domain.application.service.referential.MessageTypeService;
import lu.pgd.dri.ischia.domainapi.response.ReferentialResponse;
import lu.pgd.dri.ischia.web.controller.advice.MessagesProvider;
import lu.pgd.dri.ischia.web.controller.referential.MessageTypeController;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.BDDMockito.given;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Web layer of a generic reference type (AbstractReferentialController), tested through MessageTypeController.
 * The service is mocked.
 */
@WebMvcTest(controllers = MessageTypeController.class)
@ActiveProfiles("test")
@Import(MessagesProvider.class)
class MessageTypeControllerTests {

    private static final String URL = "/api/v1/referential/message-types";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private MessagesProvider messagesProvider;

    @MockitoBean
    private MessageTypeService service;

    @Test
    void getAll_shouldReturn200WithList() throws Exception {
        given(service.getAll()).willReturn(List.of(response(1L, "MAIL"), response(2L, "FAX")));

        mockMvc.perform(authenticated(get(URL)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].code").value("MAIL"))
                .andExpect(jsonPath("$[0].labelFr").value("MAIL fr"));
    }

    @Test
    void getAll_shouldReturnEmptyList() throws Exception {
        given(service.getAll()).willReturn(List.of());

        mockMvc.perform(authenticated(get(URL)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(0)));
    }

    @Test
    void getById_shouldReturn200() throws Exception {
        given(service.getById(1L)).willReturn(response(1L, "MAIL"));

        mockMvc.perform(authenticated(get(URL + "/{id}", 1)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.code").value("MAIL"));
    }

    @Test
    void getByCode_shouldReturn200() throws Exception {
        given(service.getByCode("mail")).willReturn(response(1L, "MAIL"));

        mockMvc.perform(authenticated(get(URL + "/code/{code}", "mail")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("MAIL"));
    }

    @Test
    void getById_withNonNumericId_shouldReturn400() throws Exception {
        mockMvc.perform(authenticated(get(URL + "/{id}", "abc")))
                .andExpect(status().isBadRequest());
    }

    @Test
    void getById_shouldReturn404ProblemDetailWhenNotFound() throws Exception {
        given(service.getById(99L)).willThrow(new ResourceNotFoundException("referential.notfound.byId", 99L));

        mockMvc.perform(authenticated(get(URL + "/{id}", 99)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.detail").value(messagesProvider.get("referential.notfound.byId", 99L)))
                .andExpect(jsonPath("$.timestamp").exists());
    }

    @Test
    void getByCode_shouldReturn404WhenNotFound() throws Exception {
        given(service.getByCode("NOPE")).willThrow(new ResourceNotFoundException("referential.notfound.byCode", "NOPE"));

        mockMvc.perform(authenticated(get(URL + "/code/{code}", "NOPE")))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.detail").value(messagesProvider.get("referential.notfound.byCode", "NOPE")));
    }

    private static ReferentialResponse response(Long id, String code) {
        return new ReferentialResponse(id, code, code + " fr", code + " en", code + " de", null, null);
    }

    private static RequestBuilder authenticated(MockHttpServletRequestBuilder request) {
        return request
                .contentType(MediaType.APPLICATION_JSON)
                .with(jwt().jwt(jwt -> jwt.subject("xac7865").claim("preferred_username", "xac7865")));
    }
}
