package lu.pgd.dri.ischia.errorcontract;

import jakarta.validation.Constraint;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Payload;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.web.controller.advice.ApiExceptionHandler;
import lu.pgd.dri.ischia.web.controller.advice.MessagesProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.annotation.Validated;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.validation.beanvalidation.MethodValidationInterceptor;
import org.springframework.web.bind.annotation.*;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Error contract of the API, tested without Spring context (standalone MockMvc):
 * real Bean Validation, real message bundles (messages*, ValidationMessages* from ischia-domain), real Jackson.
 * A test-only controller produces each kind of error.
 * <br>
 * Package OUTSIDE lu.pgd.dri.ischia.web on purpose: the test controller must not be picked up
 * by the component scan of the @SpringBootTest tests (ReferentialIT...).
 */
public class ApiExceptionHandlerTests {

    private MockMvc mockMvc;
    private MessagesProvider messagesProvider;

    @BeforeEach
    void setUp() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
        messageSource.setBasenames("messages", "ValidationMessages");   // same as spring.messages.basename
        messageSource.setDefaultEncoding("UTF-8");
        messageSource.setFallbackToSystemLocale(false);

        LocalValidatorFactoryBean validator = new LocalValidatorFactoryBean();
        validator.setValidationMessageSource(messageSource);
        validator.afterPropertiesSet();

        messagesProvider = new MessagesProvider(messageSource);
        ApiExceptionHandler handler = new ApiExceptionHandler(messagesProvider);
        handler.setMessageSource(messageSource);

        // Same mechanism as Spring Boot's MethodValidationPostProcessor for @Validated beans:
        // an AOP proxy that validates arguments / return value and throws ConstraintViolationException.
        ProxyFactory proxyFactory = new ProxyFactory(new ValidatedTestService());
        proxyFactory.setProxyTargetClass(true);
        proxyFactory.addAdvice(new MethodValidationInterceptor(validator));
        ValidatedTestService validatedService = (ValidatedTestService) proxyFactory.getProxy();

        mockMvc = MockMvcBuilders.standaloneSetup(new ValidationTestController(validatedService))
                .setControllerAdvice(handler)
                .setValidator(validator)
                .build();
    }

    private ResultActions postJson(String json, String language) throws Exception {
        return mockMvc.perform(post("/test/messages")
                .contentType(MediaType.APPLICATION_JSON)
                .header("Accept-Language", language)
                .content(json));
    }

    private static final String VALID_BODY = """
            {"subject": "Subject", "reference": "REF", "recipients": [{"email": "a@police.lu"}],
             "observers": ["A"], "start": "2026-01-01", "end": "2026-02-01"}
            """;

    // ================================================================ @Valid @RequestBody

    @Nested
    class JsonBody {

        private static final String INVALID_BODY = """
                {"subject": "", "reference": "TOO-LONG",
                 "recipients": [{"email": "a@police.lu"}, {"email": "not-an-email"}],
                 "observers": ["A", ""],
                 "start": "2026-02-01", "end": "2026-01-01"}
                """;

        @Test
        void validBodyShouldPass() throws Exception {
            postJson(VALID_BODY, "en").andExpect(status().isOk());
        }

        @Test
        void shouldReturnOneErrorPerInvalidValueWithJsonPath() throws Exception {
            postJson(INVALID_BODY, "en")
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.status").value(400))
                    .andExpect(jsonPath("$.title").value("Invalid request"))
                    .andExpect(jsonPath("$.detail").value("The request contains invalid fields."))
                    .andExpect(jsonPath("$.timestamp").exists())
                    .andExpect(jsonPath("$.errors", hasSize(5)))
                    // simple field
                    .andExpect(jsonPath("$.errors[?(@.field == 'subject')].code").value("NotBlank"))
                    .andExpect(jsonPath("$.errors[?(@.field == 'subject')].message").value("must not be blank"))
                    // constraint attributes in the message
                    .andExpect(jsonPath("$.errors[?(@.field == 'reference')].code").value("Size"))
                    .andExpect(jsonPath("$.errors[?(@.field == 'reference')].message").value("size must be between 0 and 5"))
                    // field of an object inside a list
                    .andExpect(jsonPath("$.errors[?(@.field == 'recipients[1].email')].code").value("Email"))
                    // element of a list of strings
                    .andExpect(jsonPath("$.errors[?(@.field == 'observers[1]')].code").value("NotBlank"))
                    // class-level constraint attached to a field (recommended pattern, see ValidPeriod)
                    .andExpect(jsonPath("$.errors[?(@.field == 'end')].code").value("ValidPeriod"))
                    .andExpect(jsonPath("$.errors[?(@.field == 'end')].message").value("end must be after start"));
        }

        @Test
        void messagesShouldFollowAcceptLanguage() throws Exception {
            postJson(INVALID_BODY, "fr")
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.detail").value("La requête contient des champs invalides."))
                    .andExpect(jsonPath("$.errors[?(@.field == 'subject')].message").value("ne doit pas être vide"));

            postJson(INVALID_BODY, "de")
                    .andExpect(jsonPath("$.errors[?(@.field == 'subject')].message").value("darf nicht leer sein"));
        }

        @Test
        void unsupportedLanguageShouldFallBackToEnglish() throws Exception {
            postJson(INVALID_BODY, "it")
                    .andExpect(jsonPath("$.errors[?(@.field == 'subject')].message").value("must not be blank"));
        }

        @Test
        void classLevelErrorWithoutPropertyNodeShouldHaveNullField() throws Exception {
            String body = VALID_BODY.replace("\"Subject\"", "\"FORBIDDEN\"");

            postJson(body, "en")
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.errors", hasSize(1)))
                    .andExpect(jsonPath("$.errors[0].field").value(nullValue()))
                    .andExpect(jsonPath("$.errors[0].code").value("NoForbiddenSubject"));
        }
    }

    // ================================================================ unreadable body

    @Nested
    class UnreadableBody {

        @Test
        void wrongTypeShouldReturnTheFieldAsInvalidFormat() throws Exception {
            String body = VALID_BODY.replace("\"2026-01-01\"", "\"not-a-date\"");

            postJson(body, "en")
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.errors", hasSize(1)))
                    .andExpect(jsonPath("$.errors[0].field").value("start"))
                    .andExpect(jsonPath("$.errors[0].code").value("InvalidFormat"))
                    .andExpect(jsonPath("$.errors[0].message").value("Invalid format."));
        }

        @Test
        void wrongTypeInsideAListShouldReturnIndexedPath() throws Exception {
            String body = VALID_BODY.replace("[{\"email\": \"a@police.lu\"}]", "[{\"email\": \"a@police.lu\"}, 5]");

            postJson(body, "en")
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.errors[0].field").value("recipients[1]"));
        }

        @Test
        void malformedJsonShouldReturn400WithoutErrors() throws Exception {
            postJson("{\"subject\": ", "en")
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.detail").value("The request body is missing or malformed."))
                    .andExpect(jsonPath("$.errors").doesNotExist());
        }
    }

    // ================================================================ constraints on parameters

    @Nested
    class Parameters {

        @Test
        void requestParamsShouldUseTheirClientName() throws Exception {
            mockMvc.perform(get("/test/search").param("page", "0").param("q", "ABCDE").header("Accept-Language", "en"))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.detail").value("Some parameters are invalid."))
                    .andExpect(jsonPath("$.errors", hasSize(2)))
                    .andExpect(jsonPath("$.errors[?(@.field == 'page')].code").value("Min"))
                    .andExpect(jsonPath("$.errors[?(@.field == 'page')].message").value("must be greater than or equal to 1"))
                    // Java parameter is "query", the client sends "q"
                    .andExpect(jsonPath("$.errors[?(@.field == 'q')].code").value("Size"));
        }

        @Test
        void pathVariableShouldBeReported() throws Exception {
            mockMvc.perform(get("/test/items/{id}", 0).header("Accept-Language", "en"))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.errors[0].field").value("id"))
                    .andExpect(jsonPath("$.errors[0].code").value("Min"));
        }

        @Test
        void wrongTypeShouldStayA400() throws Exception {
            mockMvc.perform(get("/test/items/{id}", "abc")).andExpect(status().isBadRequest());
        }
    }

    // ================================================================ @Validated service

    @Nested
    class ValidatedService {

        private static final String INVALID_BODY = """
                {"subject": "", "reference": "TOO-LONG",
                 "recipients": [{"email": "a@police.lu"}, {"email": "not-an-email"}],
                 "observers": ["A", ""],
                 "start": "2026-02-01", "end": "2026-01-01"}
                """;

        private ResultActions postToService(String json, String language) throws Exception {
            return mockMvc.perform(post("/test/service-messages")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("Accept-Language", language)
                    .content(json));
        }

        @Test
        void validInputShouldPass() throws Exception {
            postToService(VALID_BODY, "en").andExpect(status().isOk());
        }

        @Test
        void invalidBeanParameterShouldGiveSameFormatAsControllerValidation() throws Exception {
            postToService(INVALID_BODY, "en")
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.title").value("Invalid request"))
                    .andExpect(jsonPath("$.detail").value("The request contains invalid fields."))
                    .andExpect(jsonPath("$.errors", hasSize(5)))
                    // method and parameter names are dropped: same paths as with @Valid @RequestBody
                    .andExpect(jsonPath("$.errors[?(@.field == 'subject')].code").value("NotBlank"))
                    .andExpect(jsonPath("$.errors[?(@.field == 'reference')].message").value("size must be between 0 and 5"))
                    .andExpect(jsonPath("$.errors[?(@.field == 'recipients[1].email')].code").value("Email"))
                    .andExpect(jsonPath("$.errors[?(@.field == 'observers[1]')].code").value("NotBlank"))
                    .andExpect(jsonPath("$.errors[?(@.field == 'end')].code").value("ValidPeriod"));
        }

        @Test
        void errorsShouldBeSortedByField() throws Exception {
            postToService(INVALID_BODY, "en")
                    .andExpect(jsonPath("$.errors[*].field",
                            contains("end", "observers[1]", "recipients[1].email", "reference", "subject")));
        }

        @Test
        void messagesShouldFollowAcceptLanguage() throws Exception {
            postToService(INVALID_BODY, "fr")
                    .andExpect(jsonPath("$.detail").value("La requête contient des champs invalides."))
                    .andExpect(jsonPath("$.errors[?(@.field == 'subject')].message").value("ne doit pas être vide"));
        }

        @Test
        void simpleParameterShouldUseItsName() throws Exception {
            mockMvc.perform(get("/test/service-items/{id}", 0).header("Accept-Language", "en"))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.errors", hasSize(1)))
                    .andExpect(jsonPath("$.errors[0].field").value("id"))
                    .andExpect(jsonPath("$.errors[0].code").value("Min"))
                    .andExpect(jsonPath("$.errors[0].message").value("must be greater than or equal to 1"));
        }

        @Test
        void invalidReturnValueIsAServerBugSo500() throws Exception {
            mockMvc.perform(get("/test/service-broken").header("Accept-Language", "en"))
                    .andExpect(status().isInternalServerError())
                    .andExpect(jsonPath("$.errors").doesNotExist());
        }
    }

    // ================================================================ other errors

    @Nested
    class OtherErrors {

        @Test
        void accessDeniedShouldBe403NotA500() throws Exception {
            mockMvc.perform(get("/test/forbidden").header("Accept-Language", "en"))
                    .andExpect(status().isForbidden())
                    .andExpect(jsonPath("$.detail").value("You are not allowed to perform this action."));
        }

        @Test
        void resourceNotFoundShouldBe404() throws Exception {
            mockMvc.perform(get("/test/not-found").header("Accept-Language", "fr"))
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.detail").value("Type de référentiel introuvable avec l'identifiant 9001"));
        }

        @Test
        void unexpectedErrorShouldBe500WithoutTechnicalDetail() throws Exception {
            mockMvc.perform(get("/test/boom").header("Accept-Language", "en"))
                    .andExpect(status().isInternalServerError())
                    .andExpect(jsonPath("$.detail").value("An unexpected error occurred. Please try again later."))
                    .andExpect(jsonPath("$.detail", not(containsString("secret"))));
        }
    }

    @Nested
    class MessagesProviderFallback {

        @Test
        void unknownResolvableShouldReturnItsLeastSpecificCode() {
            var resolvable = new DefaultMessageSourceResolvable(new String[]{"Unknown.request.field", "Unknown"});

            assertThat(messagesProvider.get(resolvable)).isEqualTo("Unknown");
        }

        @Test
        void unknownKeyShouldReturnTheKey() {
            assertThat(messagesProvider.get("unknown.key")).isEqualTo("unknown.key");
        }
    }

    // ================================================================ test-only controller and DTOs

    /**
     * Validated by the AOP proxy built in setUp (like a @Validated @Service in the application).
     */
    @Validated
    public static class ValidatedTestService {

        public void create(@Valid TestMessageRequest request) {
            // validation only
        }

        public void find(@Min(1) Long id) {
            // validation only
        }

        @NotNull
        public String broken() {
            return null;
        }
    }

    @RestController
    @RequestMapping("/test")
    static class ValidationTestController {

        private final ValidatedTestService service;

        ValidationTestController(ValidatedTestService service) {
            this.service = service;
        }

        /** No @Valid here: the validation is done by the service. */
        @PostMapping("/service-messages")
        void createThroughService(@RequestBody TestMessageRequest request) {
            service.create(request);
        }

        @GetMapping("/service-items/{id}")
        void findThroughService(@PathVariable Long id) {
            service.find(id);
        }

        @GetMapping("/service-broken")
        String brokenThroughService() {
            return service.broken();
        }

        @PostMapping("/messages")
        void create(@Valid @RequestBody TestMessageRequest request) {
            // validation only
        }

        @GetMapping("/search")
        void search(@RequestParam @Min(1) Integer page, @RequestParam("q") @Size(max = 3) String query) {
            // validation only
        }

        @GetMapping("/items/{id}")
        void item(@PathVariable @Min(1) Long id) {
            // validation only
        }

        @GetMapping("/forbidden")
        void forbidden() {
            throw new AccessDeniedException("no role");
        }

        @GetMapping("/not-found")
        void notFound() {
            throw new ResourceNotFoundException("referential.notfound.byId", 9001L);
        }

        @GetMapping("/boom")
        void boom() {
            throw new IllegalStateException("secret technical detail");
        }
    }

    @ValidPeriod
    @NoForbiddenSubject
    public record TestMessageRequest(
            @NotBlank String subject,
            @Size(max = 5) String reference,
            List<@Valid TestRecipient> recipients,
            List<@NotBlank String> observers,
            LocalDate start,
            LocalDate end) {
    }

    public record TestRecipient(@NotBlank @Email String email) {
    }

    /**
     * Recommended pattern for a cross-field rule: attach the error to the field the user must fix
     * (addPropertyNode), so the front can display it next to that field.
     */
    @Target(TYPE)
    @Retention(RUNTIME)
    @Constraint(validatedBy = ValidPeriodValidator.class)
    public @interface ValidPeriod {
        String message() default "end must be after start";
        Class<?>[] groups() default {};
        Class<? extends Payload>[] payload() default {};
    }

    public static class ValidPeriodValidator implements ConstraintValidator<ValidPeriod, TestMessageRequest> {
        @Override
        public boolean isValid(TestMessageRequest request, ConstraintValidatorContext context) {
            if (request.start() == null || request.end() == null || request.end().isAfter(request.start())) {
                return true;
            }
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(context.getDefaultConstraintMessageTemplate())
                    .addPropertyNode("end")
                    .addConstraintViolation();
            return false;
        }
    }

    /**
     * Class-level rule WITHOUT property node: reported with field = null.
     */
    @Target(TYPE)
    @Retention(RUNTIME)
    @Constraint(validatedBy = NoForbiddenSubjectValidator.class)
    public @interface NoForbiddenSubject {
        String message() default "this subject is forbidden";
        Class<?>[] groups() default {};
        Class<? extends Payload>[] payload() default {};
    }

    public static class NoForbiddenSubjectValidator implements ConstraintValidator<NoForbiddenSubject, TestMessageRequest> {
        @Override
        public boolean isValid(TestMessageRequest request, ConstraintValidatorContext context) {
            return !Objects.equals(request.subject(), "FORBIDDEN");
        }
    }
}
