package lu.pgd.dri.ischia.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
class IschiaServiceCoreApplicationTest {

    @Test
    void contextLoads() {
        // Check if the application context loads correctly.
    }
}
