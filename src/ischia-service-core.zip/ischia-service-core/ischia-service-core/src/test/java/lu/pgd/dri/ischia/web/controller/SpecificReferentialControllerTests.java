package lu.pgd.dri.ischia.web.controller;

import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.domain.application.service.referential.CountryService;
import lu.pgd.dri.ischia.domain.application.service.referential.UserUnitService;
import lu.pgd.dri.ischia.domainapi.response.ReferentialCountryResponse;
import lu.pgd.dri.ischia.domainapi.response.ReferentialUserUnitResponse;
import lu.pgd.dri.ischia.web.controller.advice.MessagesProvider;
import lu.pgd.dri.ischia.web.controller.referential.CountryController;
import lu.pgd.dri.ischia.web.controller.referential.UserUnitController;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.BDDMockito.given;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Reference types with their own controller and response (Country, UserUnit). Services are mocked.
 */
@WebMvcTest(controllers = {CountryController.class, UserUnitController.class})
@ActiveProfiles("test")
@Import(MessagesProvider.class)
class SpecificReferentialControllerTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private MessagesProvider messagesProvider;

    @MockitoBean
    private CountryService countryService;

    @MockitoBean
    private UserUnitService userUnitService;

    private static RequestBuilder authenticated(MockHttpServletRequestBuilder request) {
        return request
                .contentType(MediaType.APPLICATION_JSON)
                .with(jwt().jwt(jwt -> jwt.subject("xac7865").claim("preferred_username", "xac7865")));
    }

    @Nested
    class Country {

        private static final String URL = "/api/v1/referential/country-types";

        private final ReferentialCountryResponse luxembourg =
                new ReferentialCountryResponse(1L, "LU", "LUX", "Luxembourg", "Luxembourg", "Luxemburg", null, null);

        @Test
        void getAll_shouldReturn200WithAlphaCodes() throws Exception {
            given(countryService.getAll()).willReturn(List.of(luxembourg));

            mockMvc.perform(authenticated(get(URL)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$", hasSize(1)))
                    .andExpect(jsonPath("$[0].alphaCode2").value("LU"))
                    .andExpect(jsonPath("$[0].alphaCode3").value("LUX"));
        }

        @Test
        void getById_shouldReturn200() throws Exception {
            given(countryService.getById(1L)).willReturn(luxembourg);

            mockMvc.perform(authenticated(get(URL + "/{id}", 1)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(1));
        }

        @Test
        void getByCode_shouldAcceptAlpha2AndAlpha3() throws Exception {
            given(countryService.getByCode("LU")).willReturn(luxembourg);
            given(countryService.getByCode("LUX")).willReturn(luxembourg);

            mockMvc.perform(authenticated(get(URL + "/code/{code}", "LU")))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.alphaCode3").value("LUX"));
            mockMvc.perform(authenticated(get(URL + "/code/{code}", "LUX")))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.alphaCode2").value("LU"));
        }

        @Test
        void getByCode_shouldReturn404WhenNotFound() throws Exception {
            given(countryService.getByCode("XX")).willThrow(new ResourceNotFoundException("referential.notfound.byCode", "XX"));

            mockMvc.perform(authenticated(get(URL + "/code/{code}", "XX")))
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.detail").value(messagesProvider.get("referential.notfound.byCode", "XX")));
        }
    }

    @Nested
    class UserUnit {

        private static final String URL = "/api/v1/referential/user-unit-types";

        private final ReferentialUserUnitResponse unit =
                new ReferentialUserUnitResponse(5L, 9L, "UNIT", "Unité", "Unit", "Einheit", null, null);

        @Test
        void getAll_shouldReturn200WithOrganizationId() throws Exception {
            given(userUnitService.getAll()).willReturn(List.of(unit));

            mockMvc.perform(authenticated(get(URL)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$", hasSize(1)))
                    .andExpect(jsonPath("$[0].organizationId").value(9));
        }

        @Test
        void getByCode_shouldReturn200() throws Exception {
            given(userUnitService.getByCode("UNIT")).willReturn(unit);

            mockMvc.perform(authenticated(get(URL + "/code/{code}", "UNIT")))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.code").value("UNIT"));
        }

        @Test
        void getById_shouldReturn404WhenNotFound() throws Exception {
            given(userUnitService.getById(99L)).willThrow(new ResourceNotFoundException("referential.notfound.byId", 99L));

            mockMvc.perform(authenticated(get(URL + "/{id}", 99)))
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.detail").value(messagesProvider.get("referential.notfound.byId", 99L)));
        }
    }
}
