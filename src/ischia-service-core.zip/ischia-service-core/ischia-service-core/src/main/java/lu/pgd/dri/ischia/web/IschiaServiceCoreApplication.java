package lu.pgd.dri.ischia.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IschiaServiceCoreApplication {
    static void main(String[] args) {
        SpringApplication.run(IschiaServiceCoreApplication.class, args);
    }
}
