package lu.pgd.dri.ischia.web.controller.referential;

import lombok.RequiredArgsConstructor;
import lu.pgd.dri.ischia.domain.application.service.AbstractChannelReferentialService;
import lu.pgd.dri.ischia.domain.application.service.referential.MessageReliabilityService;
import lu.pgd.dri.ischia.web.controller.AbstractChannelReferentialController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/referential/message-reliability-types")
public class MessageReliabilityController extends AbstractChannelReferentialController {

    private final MessageReliabilityService service;

    @Override
    protected AbstractChannelReferentialService<?> service() {
        return this.service;
    }
}
