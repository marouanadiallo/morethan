package lu.pgd.dri.ischia.web.controller.referential;

import lombok.RequiredArgsConstructor;
import lu.pgd.dri.ischia.domain.application.service.AbstractChannelReferentialService;
import lu.pgd.dri.ischia.domain.application.service.referential.MessageConfidentialityService;
import lu.pgd.dri.ischia.web.controller.AbstractChannelReferentialController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/referential/message-confidentiality-types")
public class MessageConfidentialityController extends AbstractChannelReferentialController {

    private final MessageConfidentialityService service;

    @Override
    protected AbstractChannelReferentialService<?> service() {
        return this.service;
    }
}
