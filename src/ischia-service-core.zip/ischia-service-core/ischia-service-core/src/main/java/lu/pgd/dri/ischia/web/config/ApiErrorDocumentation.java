package lu.pgd.dri.ischia.web.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.headers.Header;
import io.swagger.v3.oas.models.media.*;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.responses.ApiResponses;
import org.springdoc.core.customizers.OperationCustomizer;
import org.springframework.core.MethodParameter;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.method.HandlerMethod;

import java.lang.annotation.Annotation;
import java.util.*;

/**
 * Documents in OpenAPI the error responses of every endpoint, automatically, from what the endpoint really does:
 * nothing to annotate, nothing to forget (same idea as @ConsultationLog on a class).
 *
 * <table>
 *   <tr><th>Code</th><th>Added when</th><th>Produced by</th></tr>
 *   <tr><td>400</td><td>the endpoint receives input (body, query / path parameter, header)</td>
 *       <td>validation, wrong type, unreadable JSON, DomainException</td></tr>
 *   <tr><td>401</td><td>always (every endpoint requires a bearer token)</td><td>Spring Security (empty body)</td></tr>
 *   <tr><td>403</td><td>@PreAuthorize / @PostAuthorize / @Secured on the method or the class</td><td>AccessDeniedException</td></tr>
 *   <tr><td>404</td><td>the path has a variable ({id}, {code}...)</td><td>ResourceNotFoundException</td></tr>
 *   <tr><td>409</td><td>POST / PUT / PATCH / DELETE</td><td>DataIntegrityViolationException</td></tr>
 *   <tr><td>500</td><td>always</td><td>unexpected error</td></tr>
 * </table>
 *
 * A response declared explicitly on the endpoint ({@code @ApiResponse(responseCode = "404", ...)}) is never overwritten.
 * <br>
 * Responses and schemas are declared once in {@code components} ({@link #addComponents(OpenAPI)}) and referenced
 * by each operation: register both on every GroupedOpenApi (see ApiDocumentationConfigurer).
 */
public class ApiErrorDocumentation implements OperationCustomizer {

    static final String BAD_REQUEST = "BadRequest";
    static final String UNAUTHORIZED = "Unauthorized";
    static final String FORBIDDEN = "Forbidden";
    static final String NOT_FOUND = "NotFound";
    static final String CONFLICT = "Conflict";
    static final String INTERNAL_ERROR = "InternalError";

    static final String PROBLEM_DETAIL_SCHEMA = "ProblemDetail";
    static final String VALIDATION_PROBLEM_DETAIL_SCHEMA = "ValidationProblemDetail";
    static final String VALIDATION_ERROR_SCHEMA = "ValidationError";

    private static final List<Class<? extends Annotation>> INPUT_ANNOTATIONS = List.of(
            RequestBody.class, RequestParam.class, PathVariable.class, RequestHeader.class,
            RequestPart.class, ModelAttribute.class);

    private static final List<Class<? extends Annotation>> SECURITY_ANNOTATIONS = List.of(
            PreAuthorize.class, PostAuthorize.class, Secured.class);

    private static final Set<RequestMethod> WRITE_METHODS = EnumSet.of(
            RequestMethod.POST, RequestMethod.PUT, RequestMethod.PATCH, RequestMethod.DELETE);

    // ================================================================ per operation

    @Override
    public Operation customize(Operation operation, HandlerMethod handlerMethod) {
        if (operation.getResponses() == null) {
            operation.setResponses(new ApiResponses());
        }
        ApiResponses responses = operation.getResponses();

        if (receivesInput(handlerMethod)) {
            addIfAbsent(responses, "400", BAD_REQUEST);
        }
        addIfAbsent(responses, "401", UNAUTHORIZED);
        if (isSecuredByRole(handlerMethod)) {
            addIfAbsent(responses, "403", FORBIDDEN);
        }
        if (hasPathVariable(handlerMethod)) {
            addIfAbsent(responses, "404", NOT_FOUND);
        }
        if (isWrite(handlerMethod)) {
            addIfAbsent(responses, "409", CONFLICT);
        }
        addIfAbsent(responses, "500", INTERNAL_ERROR);
        return operation;
    }

    private static void addIfAbsent(ApiResponses responses, String status, String componentName) {
        // An explicit @ApiResponse on the endpoint always wins
        responses.putIfAbsent(status, new ApiResponse().$ref(componentName));
    }

    static boolean receivesInput(HandlerMethod handlerMethod) {
        return Arrays.stream(handlerMethod.getMethodParameters())
                .anyMatch(parameter -> INPUT_ANNOTATIONS.stream().anyMatch(parameter::hasParameterAnnotation));
    }

    static boolean hasPathVariable(HandlerMethod handlerMethod) {
        return Arrays.stream(handlerMethod.getMethodParameters())
                .anyMatch((MethodParameter parameter) -> parameter.hasParameterAnnotation(PathVariable.class));
    }

    static boolean isSecuredByRole(HandlerMethod handlerMethod) {
        return SECURITY_ANNOTATIONS.stream().anyMatch(annotation ->
                handlerMethod.hasMethodAnnotation(annotation)
                        || AnnotatedElementUtils.hasAnnotation(handlerMethod.getBeanType(), annotation));
    }

    static boolean isWrite(HandlerMethod handlerMethod) {
        // @GetMapping, @PostMapping... are meta-annotated with @RequestMapping(method = ...)
        RequestMapping mapping = AnnotatedElementUtils.findMergedAnnotation(handlerMethod.getMethod(), RequestMapping.class);
        return mapping != null && Arrays.stream(mapping.method()).anyMatch(WRITE_METHODS::contains);
    }

    // ================================================================ shared components

    /**
     * Declares the reusable schemas and responses referenced by {@link #customize}.
     */
    public void addComponents(OpenAPI openApi) {
        if (openApi.getComponents() == null) {
            openApi.setComponents(new Components());
        }
        Components components = openApi.getComponents();

        components.addSchemas(VALIDATION_ERROR_SCHEMA, validationErrorSchema());
        components.addSchemas(PROBLEM_DETAIL_SCHEMA, problemDetailSchema(false));
        components.addSchemas(VALIDATION_PROBLEM_DETAIL_SCHEMA, problemDetailSchema(true));

        components.addResponses(BAD_REQUEST, problemResponse(
                "Invalid input: validation error, value of the wrong type, unreadable JSON or business rule. "
                        + "`errors` lists each invalid value (absent for malformed JSON or a business rule).",
                VALIDATION_PROBLEM_DETAIL_SCHEMA,
                example(400, "Invalid request", "The request contains invalid fields.", List.of(
                        error("subject", "NotBlank", "must not be blank"),
                        error("recipients[1].email", "Email", "must be a well-formed email address"),
                        error("start", "InvalidFormat", "Invalid format.")))));

        components.addResponses(UNAUTHORIZED, new ApiResponse()
                .description("Missing, invalid or expired bearer token. Empty body; see the WWW-Authenticate header.")
                .addHeaderObject("WWW-Authenticate", new Header()
                        .description("Bearer error=\"invalid_token\", error_description=\"...\"")
                        .schema(new StringSchema())));

        components.addResponses(FORBIDDEN, problemResponse(
                "The user is authenticated but does not have the required role.",
                PROBLEM_DETAIL_SCHEMA,
                example(403, "Forbidden", "You are not allowed to perform this action.", null)));

        components.addResponses(NOT_FOUND, problemResponse(
                "No resource matches the identifier or code of the path.",
                PROBLEM_DETAIL_SCHEMA,
                example(404, "Not Found", "Referential with id (42) not found", null)));

        components.addResponses(CONFLICT, problemResponse(
                "The change conflicts with existing data (unique constraint, referenced data...).",
                PROBLEM_DETAIL_SCHEMA,
                example(409, "Conflict", "A resource with the same data already exists.", null)));

        components.addResponses(INTERNAL_ERROR, problemResponse(
                "Unexpected server error. The detail never contains technical information: "
                        + "give the x-b3-trace-id response header to the support team.",
                PROBLEM_DETAIL_SCHEMA,
                example(500, "Internal Server Error", "An unexpected error occurred. Please try again later.", null)));
    }

    private static ApiResponse problemResponse(String description, String schemaName, Map<String, Object> example) {
        return new ApiResponse()
                .description(description + " Messages are translated according to Accept-Language (fr, de, en).")
                .content(new Content().addMediaType(MediaType.APPLICATION_PROBLEM_JSON_VALUE,
                        new io.swagger.v3.oas.models.media.MediaType()
                                .schema(new Schema<>().$ref(schemaName))
                                .example(example)));
    }

    @SuppressWarnings("rawtypes")
    private static Schema problemDetailSchema(boolean withErrors) {
        ObjectSchema schema = new ObjectSchema();
        schema.description(withErrors
                ? "RFC 9457 problem detail, with the list of invalid values"
                : "RFC 9457 problem detail");
        schema.addProperty("type", new StringSchema().example("about:blank"));
        schema.addProperty("title", new StringSchema().description("Short summary, translated"));
        schema.addProperty("status", new IntegerSchema().description("HTTP status code"));
        schema.addProperty("detail", new StringSchema().description("Explanation for the user, translated"));
        schema.addProperty("instance", new StringSchema().description("Path of the request"));
        schema.addProperty("timestamp", new DateTimeSchema());
        if (withErrors) {
            schema.addProperty("errors", new ArraySchema()
                    .items(new Schema<>().$ref(VALIDATION_ERROR_SCHEMA))
                    .description("One entry per invalid value, sorted by field"));
        }
        return schema;
    }

    @SuppressWarnings("rawtypes")
    private static Schema validationErrorSchema() {
        ObjectSchema schema = new ObjectSchema();
        schema.description("One invalid value");
        schema.addProperty("field", new StringSchema()
                .nullable(true)
                .description("Path as in the request JSON (a.b[2].c), or name of the query / path parameter; "
                        + "null for a rule on the whole object")
                .example("recipients[1].email"));
        schema.addProperty("code", new StringSchema()
                .description("Language-independent code: constraint name (NotBlank, Size, Email...) or InvalidFormat")
                .example("Email"));
        schema.addProperty("message", new StringSchema()
                .description("Message translated according to Accept-Language")
                .example("must be a well-formed email address"));
        return schema;
    }

    private static Map<String, Object> example(int status, String title, String detail, List<Map<String, Object>> errors) {
        Map<String, Object> example = new LinkedHashMap<>();
        example.put("type", "about:blank");
        example.put("title", title);
        example.put("status", status);
        example.put("detail", detail);
        example.put("instance", "/ischia-service/api/v1/...");
        example.put("timestamp", "2026-11-25T10:15:30Z");
        if (errors != null) {
            example.put("errors", errors);
        }
        return example;
    }

    private static Map<String, Object> error(String field, String code, String message) {
        Map<String, Object> error = new LinkedHashMap<>();
        error.put("field", field);
        error.put("code", code);
        error.put("message", message);
        return error;
    }
}
