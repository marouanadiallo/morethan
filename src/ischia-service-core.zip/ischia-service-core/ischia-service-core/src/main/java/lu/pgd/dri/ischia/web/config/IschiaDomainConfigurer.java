package lu.pgd.dri.ischia.web.config;

import lu.pgd.dri.ischia.domain.config.IschiaDomainConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Import(IschiaDomainConfiguration.class)
@Configuration
class IschiaDomainConfigurer {
}
