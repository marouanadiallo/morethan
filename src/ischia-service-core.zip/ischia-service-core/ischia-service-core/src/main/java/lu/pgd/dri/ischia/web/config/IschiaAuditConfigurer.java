package lu.pgd.dri.ischia.web.config;

import lu.pgd.dri.ischia.audit.config.AuditConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Import(AuditConfiguration.class)
@Configuration(proxyBeanMethods = false)
class IschiaAuditConfigurer {
}
