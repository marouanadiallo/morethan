package lu.pgd.dri.ischia.web.controller.referential;

import lombok.RequiredArgsConstructor;
import lu.pgd.dri.ischia.domain.application.service.AbstractChannelReferentialService;
import lu.pgd.dri.ischia.domain.application.service.referential.MessagePriorityService;
import lu.pgd.dri.ischia.web.controller.AbstractChannelReferentialController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/referential/message-priority-types")
public class MessagePriorityController extends AbstractChannelReferentialController {

    private final MessagePriorityService service;

    @Override
    protected AbstractChannelReferentialService<?> service() {
        return this.service;
    }
}
