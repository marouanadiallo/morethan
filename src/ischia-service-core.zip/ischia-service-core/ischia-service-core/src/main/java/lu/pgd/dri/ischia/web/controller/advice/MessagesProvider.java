package lu.pgd.dri.ischia.web.controller.advice;

import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Component;

/**
 * Messages in the language of the current request (LocaleContextHolder, filled from Accept-Language).
 * Never throws: an i18n gap can never turn a 4xx into a 500.
 */
@Component
public class MessagesProvider {
    private final MessageSourceAccessor accessor;

    public MessagesProvider(MessageSource messageSource) {
        this.accessor = new MessageSourceAccessor(messageSource);
    }

    /**
     * @return the message, or the key itself when it is missing
     */
    public String get(String messageKey, Object... args) {
        return accessor.getMessage(messageKey, args, messageKey);
    }

    /**
     * Resolves a validation error: tries its codes from the most specific
     * ({@code NotBlank.messageRequest.subject}, {@code NotBlank.subject}, ..., {@code NotBlank}),
     * then falls back to the message already interpolated by Bean Validation.
     * <br>
     * So any message can be overridden in messages*.properties without touching the DTO, e.g.
     * {@code NotBlank.subject=The subject is mandatory}.
     */
    public String get(MessageSourceResolvable resolvable) {
        try {
            return accessor.getMessage(resolvable);
        } catch (NoSuchMessageException _) {
            String[] codes = resolvable.getCodes();
            return codes == null || codes.length == 0 ? null : codes[codes.length - 1];
        }
    }
}
