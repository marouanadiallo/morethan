package lu.pgd.dri.ischia.web.controller.referential;

import lombok.RequiredArgsConstructor;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domain.application.service.referential.MessageStatusService;
import lu.pgd.dri.ischia.web.controller.AbstractReferentialController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/referential/message-status-types")
public class MessageStatusController extends AbstractReferentialController {

    private final MessageStatusService service;

    @Override
    protected AbstractReferentialService<?> service() {
        return this.service;
    }
}
