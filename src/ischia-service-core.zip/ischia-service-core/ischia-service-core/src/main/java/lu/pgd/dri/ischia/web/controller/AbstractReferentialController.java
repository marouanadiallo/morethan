package lu.pgd.dri.ischia.web.controller;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lu.pgd.dri.ischia.audit.business.ConsultationLog;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domainapi.response.ReferentialResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/**
 * Every GET of the referential controllers is logged as a consultation (class-level rule, see BusinessLogResolver).
 * New GET endpoints added here or in a subclass are covered automatically.
 */
@ConsultationLog
public abstract class AbstractReferentialController {

    protected abstract AbstractReferentialService<?> service();

    @GetMapping
    @Tag(name = "Referential - List")
    @Operation(
            description = "Provides the list of data for the reference type",
            responses = {@ApiResponse(responseCode = "200", description = "Successful operation")}
    )
    public ResponseEntity<List<ReferentialResponse>> getAll() {
        return ResponseEntity.ok(this.service().getAll());
    }

    @GetMapping("/{id}")
    @Tag(name = "Referential - by ID")
    @Operation(
            description = "Reference type determined by its identifier",
            responses = {@ApiResponse(responseCode = "200", description = "Successful operation")}
    )
    public ResponseEntity<ReferentialResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(this.service().getById(id));
    }

    @GetMapping("/code/{code}")
    @Tag(name = "Referential - by code")
    @Operation(
            description = "Reference type determined by its code",
            responses = {@ApiResponse(responseCode = "200", description = "Successful operation")}
    )
    public ResponseEntity<ReferentialResponse> getByCode(@PathVariable String code) {
        return ResponseEntity.ok(this.service().getByCode(code));
    }
}
