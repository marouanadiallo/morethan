package lu.pgd.dri.ischia.web.controller.advice;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.ElementKind;
import jakarta.validation.Path;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lu.pgd.dri.ischia.domain.application.exception.DomainException;
import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.domainapi.response.ValidationError;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.core.MethodParameter;
import org.springframework.core.annotation.MergedAnnotation;
import org.springframework.core.annotation.MergedAnnotations;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.*;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.validation.method.ParameterValidationResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.HandlerMethodValidationException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.net.SocketException;
import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * Every error is returned as a ProblemDetail (RFC 9457), translated in the request language.
 * <p>
 * Invalid input (400) always has the same shape, whatever its origin, with an {@code errors} array of
 * {@link ValidationError} ({@code field}, {@code code}, {@code message}):
 * <ul>
 *   <li>{@code @Valid @RequestBody} → {@link MethodArgumentNotValidException}</li>
 *   <li>constraints on {@code @RequestParam} / {@code @PathVariable} / {@code @RequestHeader}
 *       → {@link HandlerMethodValidationException}</li>
 *   <li>JSON value of the wrong type (text for a number, bad date...) → {@link HttpMessageNotReadableException}</li>
 *   <li>{@code @Validated} service / controller → {@link ConstraintViolationException}</li>
 * </ul>
 * Errors are sorted by field. The possible errors of each endpoint are documented in OpenAPI by ApiErrorDocumentation.
 */
@Slf4j
@RestControllerAdvice
@RequiredArgsConstructor
public class ApiExceptionHandler extends ResponseEntityExceptionHandler {

    static final String ERRORS = "errors";
    static final String INVALID_FORMAT = "InvalidFormat";

    private final MessagesProvider messages;

    // ---------------------------------------------------------------- 400 - invalid input

    /**
     * {@code @Valid @RequestBody}: one error per invalid field, plus class-level errors (field = null).
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            @NonNull MethodArgumentNotValidException ex,
            @NonNull HttpHeaders headers,
            @NonNull HttpStatusCode status,
            @NonNull WebRequest request) {

        List<ValidationError> errors = sorted(ex.getBindingResult().getAllErrors().stream()
                .map(error -> toValidationError(error, null))
                .toList());
        ex.getBody().setProperty(ERRORS, errors);
        return handleExceptionInternal(ex, null, headers, status, request);
    }

    /**
     * Constraints on method parameters, e.g. {@code @RequestParam @Min(1) Integer page}.
     * Raised by Spring MVC built-in method validation (no {@code @Validated} needed on the controller).
     */
    @Override
    protected ResponseEntity<Object> handleHandlerMethodValidationException(
            @NonNull HandlerMethodValidationException ex,
            @NonNull HttpHeaders headers,
            @NonNull HttpStatusCode status,
            @NonNull WebRequest request) {

        List<ValidationError> errors = sorted(ex.getParameterValidationResults().stream()
                .flatMap(result -> result.getResolvableErrors().stream()
                        .map(error -> toValidationError(error, parameterPath(result))))
                .toList());
        ex.getBody().setProperty(ERRORS, errors);
        return handleExceptionInternal(ex, null, headers, status, request);
    }

    /**
     * Unreadable body. When Jackson knows which value is wrong (type mismatch, bad date...),
     * the response tells the front which field, like a validation error.
     * Malformed JSON (syntax error) has no field: no {@code errors} array.
     */
    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(
            @NonNull HttpMessageNotReadableException ex,
            @NonNull HttpHeaders headers,
            @NonNull HttpStatusCode status,
            @NonNull WebRequest request) {

        ProblemDetail body = createProblemDetail(ex, status, "Failed to read request", null, null, request);
        if (ex.getCause() instanceof MismatchedInputException mismatch && !mismatch.getPath().isEmpty()) {
            body.setProperty(ERRORS, List.of(new ValidationError(
                    jsonPath(mismatch.getPath()), INVALID_FORMAT, messages.get("validation.invalidFormat"))));
        }
        return handleExceptionInternal(ex, body, headers, status, request);
    }

    /**
     * {@code @Validated} bean (service, or controller annotated {@code @Validated}): Spring AOP throws
     * {@link ConstraintViolationException}, outside Spring MVC binding.
     * <ul>
     *   <li>violation on a parameter → client input → 400, same {@code errors} format as above;</li>
     *   <li>violation on a return value → the server produced invalid data → 500.</li>
     * </ul>
     */
    @ExceptionHandler(ConstraintViolationException.class)
    ResponseEntity<Object> handleConstraintViolation(ConstraintViolationException ex, WebRequest request) {
        Set<ConstraintViolation<?>> violations = ex.getConstraintViolations();
        if (violations.stream().anyMatch(ApiExceptionHandler::isOnReturnValue)) {
            return handleUnexpected(ex, request);
        }
        List<ValidationError> errors = sorted(violations.stream()
                .map(violation -> new ValidationError(
                        violationPath(violation),
                        violation.getConstraintDescriptor().getAnnotation().annotationType().getSimpleName(),
                        violation.getMessage()))   // already interpolated in the request language
                .toList());

        ProblemDetail body = createProblemDetail(ex, HttpStatus.BAD_REQUEST, "Invalid request content.", null, null, request);
        body.setProperty(ERRORS, errors);
        return handleExceptionInternal(ex, body, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
    }

    private static boolean isOnReturnValue(ConstraintViolation<?> violation) {
        for (Path.Node node : violation.getPropertyPath()) {
            if (node.getKind() == ElementKind.RETURN_VALUE) {
                return true;
            }
        }
        return false;
    }

    /**
     * Bean Validation path ("create.request.recipients[1].email") → same notation as the other errors:
     * the method name is dropped, and the parameter name too when the error is inside the parameter object
     * ("recipients[1].email"); for a simple parameter ({@code find(@Min(1) Long id)}) → "id";
     * cross-parameter constraint → null.
     */
    private static String violationPath(ConstraintViolation<?> violation) {
        String parameter = null;
        StringBuilder path = new StringBuilder();
        for (Path.Node node : violation.getPropertyPath()) {
            switch (node.getKind()) {
                case PARAMETER -> parameter = node.getName();
                case PROPERTY, CONTAINER_ELEMENT, BEAN -> {
                    if (node.isInIterable()) {
                        Object position = node.getIndex() != null ? node.getIndex() : node.getKey();
                        path.append('[').append(position == null ? "" : position).append(']');
                    }
                    if (node.getKind() == ElementKind.PROPERTY) {
                        if (!path.isEmpty()) {
                            path.append('.');
                        }
                        path.append(node.getName());
                    }
                }
                default -> {
                    // METHOD, CONSTRUCTOR, CROSS_PARAMETER: not part of the client-side path
                }
            }
        }
        return path.isEmpty() ? parameter : path.toString();
    }

    /**
     * Bean Validation returns violations in a Set (random order): sort by field for a stable response.
     */
    private static List<ValidationError> sorted(List<ValidationError> errors) {
        return errors.stream()
                .sorted(Comparator.comparing(ValidationError::field, Comparator.nullsFirst(Comparator.naturalOrder())))
                .toList();
    }

    /**
     * Same conversion for every source of validation error.
     *
     * @param parameterPath name of the method parameter, used when the error is on the parameter itself
     */
    private ValidationError toValidationError(MessageSourceResolvable error, @Nullable String parameterPath) {
        String field = switch (error) {
            case FieldError fieldError -> fieldError.getField();   // "recipients[1].email"
            case ObjectError _ -> null;                             // class-level constraint, without property node
            default -> parameterPath;                               // constraint on a @RequestParam / @PathVariable...
        };
        return new ValidationError(field, code(error), messages.get(error));
    }

    /**
     * The least specific code is the constraint name: "NotBlank", "Size", "ValidPeriod"...
     * (Spring lists them from the most specific: NotBlank.messageRequest.subject, NotBlank.subject, ..., NotBlank).
     */
    private static String code(MessageSourceResolvable error) {
        String[] codes = error.getCodes();
        return codes == null || codes.length == 0 ? null : codes[codes.length - 1];
    }

    /**
     * Name seen by the client (the one in @RequestParam("q") if any, else the Java name),
     * with the index / key for a constraint on a container element ({@code List<@NotBlank String> ids} → "ids[2]").
     */
    private static String parameterPath(ParameterValidationResult result) {
        String name = clientName(result.getMethodParameter());
        if (result.getContainerIndex() != null) {
            return name + "[" + result.getContainerIndex() + "]";
        }
        if (result.getContainerKey() != null) {
            return name + "[" + result.getContainerKey() + "]";
        }
        return name;
    }

    private static String clientName(MethodParameter parameter) {
        MergedAnnotations annotations = MergedAnnotations.from(parameter.getParameterAnnotations());
        for (Class<? extends Annotation> type : List.of(RequestParam.class, PathVariable.class, RequestHeader.class)) {
            MergedAnnotation<? extends Annotation> annotation = annotations.get(type);
            if (annotation.isPresent() && !annotation.getString("name").isEmpty()) {
                return annotation.getString("name");   // @AliasFor: also filled when written @RequestParam("q")
            }
        }
        return parameter.getParameterName();
    }

    /**
     * Jackson path → same notation as validation errors: "recipients[1].email".
     */
    private static String jsonPath(List<JsonMappingException.Reference> references) {
        StringBuilder path = new StringBuilder();
        for (JsonMappingException.Reference reference : references) {
            if (reference.getIndex() >= 0) {
                path.append('[').append(reference.getIndex()).append(']');
            } else {
                if (!path.isEmpty()) {
                    path.append('.');
                }
                path.append(reference.getFieldName());
            }
        }
        return path.toString();
    }

    // ---------------------------------------------------------------- business / security

    @ExceptionHandler({DomainException.class})
    ResponseEntity<Object> handleDomainException(DomainException ex, WebRequest request) {
        log.warn("Domain exception : {}", ex.getMessage());
        HttpStatus status = switch (ex) {
            case ResourceNotFoundException _ -> HttpStatus.NOT_FOUND;
            // handle other exception type here
            default -> HttpStatus.BAD_REQUEST;
        };
        ProblemDetail body = createProblemDetail(ex, status, ex.getMessage(),
                ex.getMessageKey(), ex.getMessageArgs(), request);
        return handleExceptionInternal(ex, body, new HttpHeaders(), status, request);
    }

    /**
     * Method security ({@code @PreAuthorize}...) throws inside the controller: without this handler,
     * the catch-all below would turn a 403 into a 500.
     */
    @ExceptionHandler(AccessDeniedException.class)
    ResponseEntity<Object> handleAccessDenied(AccessDeniedException ex, WebRequest request) {
        log.warn("Access denied: {}", ex.getMessage());
        ProblemDetail body = createProblemDetail(ex, HttpStatus.FORBIDDEN, "Access denied",
                "access.denied", null, request);
        return handleExceptionInternal(ex, body, new HttpHeaders(), HttpStatus.FORBIDDEN, request);
    }

    // ---------------------------------------------------------------- data

    @ExceptionHandler(DataIntegrityViolationException.class)
    ResponseEntity<Object> handleDataIntegrityViolation(DataIntegrityViolationException ex, WebRequest request) {
        log.warn("Data integrity violation: {}", ex.getMessage());
        ProblemDetail body = createProblemDetail(ex, HttpStatus.CONFLICT, "Data integrity violation",
                "data.integrity.violation", null, request);
        return handleExceptionInternal(ex, body, new HttpHeaders(), HttpStatus.CONFLICT, request);
    }

    @ExceptionHandler(DataAccessException.class)
    ResponseEntity<Object> handleDataAccessException(DataAccessException ex, WebRequest request) {
        log.error("Data access error: {}", ex.getMessage());
        ProblemDetail body = createProblemDetail(ex, HttpStatus.INTERNAL_SERVER_ERROR, "Unable to access the data",
                "data.access.error", null, request);
        return handleExceptionInternal(ex, body, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    // ---------------------------------------------------------------- technical

    @ExceptionHandler(IOException.class)
    ResponseEntity<Object> handleIOException(IOException ex, WebRequest request) {
        // Client disconnected
        if (ex.getClass().getName().contains("ClientAbortException") || ex instanceof SocketException) {
            log.debug("Client disconnected: {}", ex.getMessage());
            return null; // Ignore and just log
        }

        // Other errors during file processing
        log.error("IO error during file processing", ex);
        ProblemDetail body = createProblemDetail(ex, HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while processing the file.",
                "file.processing.error", null, request);
        return handleExceptionInternal(ex, body, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    @ExceptionHandler(Exception.class)
    ResponseEntity<Object> handleUnexpected(Exception ex, WebRequest request) {
        log.error("Unexpected error", ex);

        ProblemDetail body = createProblemDetail(ex, HttpStatus.INTERNAL_SERVER_ERROR,
                "An unexpected error occurred. Please try again later.",
                "internal.server.error", null, request);
        return handleExceptionInternal(ex, body, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    @Override
    @NonNull
    protected ResponseEntity<Object> createResponseEntity(
            @Nullable Object body,
            @NonNull HttpHeaders headers,
            @NonNull HttpStatusCode statusCode,
            @NonNull WebRequest request) {

        if (body instanceof ProblemDetail problemDetail) {
            problemDetail.setProperty("timestamp", Instant.now());
        }
        return super.createResponseEntity(body, headers, statusCode, request);
    }
}
