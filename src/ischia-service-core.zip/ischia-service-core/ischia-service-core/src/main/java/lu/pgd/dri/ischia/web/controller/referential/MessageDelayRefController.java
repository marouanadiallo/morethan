package lu.pgd.dri.ischia.web.controller.referential;

import lombok.RequiredArgsConstructor;
import lu.pgd.dri.ischia.domain.application.service.AbstractReferentialService;
import lu.pgd.dri.ischia.domain.application.service.referential.MessageDelayRefService;
import lu.pgd.dri.ischia.web.controller.AbstractReferentialController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/referential/message-delay-types")
public class MessageDelayRefController extends AbstractReferentialController {

    private final MessageDelayRefService service;

    @Override
    protected AbstractReferentialService<?> service() {
        return this.service;
    }
}
