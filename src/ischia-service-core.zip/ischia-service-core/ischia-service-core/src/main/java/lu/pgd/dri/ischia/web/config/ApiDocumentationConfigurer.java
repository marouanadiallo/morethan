package lu.pgd.dri.ischia.web.config;

import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.regex.Pattern;

@Configuration
class ApiDocumentationConfigurer {

    private final Pattern referentialPattern = Pattern.compile("/api/v\\d+/referential.*");

    /**
     * Not a bean on purpose: springdoc would also apply it as a global customizer.
     * It is added explicitly to each group below (customizer + shared components).
     */
    private final ApiErrorDocumentation errorDocumentation = new ApiErrorDocumentation();

    @Bean
    GroupedOpenApi referencesApi() {
        return GroupedOpenApi.builder()
                .group("API - Reference types")
                .addOperationCustomizer(errorDocumentation)
                .addOpenApiCustomizer(openApi -> openApi.getPaths().entrySet().removeIf(
                        e -> !referentialPattern.matcher(e.getKey()).matches()
                ))
                .addOpenApiCustomizer(errorDocumentation::addComponents)
                .build();
    }

    @Bean
    GroupedOpenApi defaultApi() {
        return GroupedOpenApi.builder()
                .group("API - Main")
                .addOperationCustomizer(errorDocumentation)
                .addOpenApiCustomizer(openApi -> openApi.getPaths().entrySet().removeIf(
                        e -> referentialPattern.matcher(e.getKey()).matches()
                ))
                .addOpenApiCustomizer(errorDocumentation::addComponents)
                .build();
    }
}
