# 004 — Refonte de la gestion des erreurs de validation (ApiExceptionHandler)

- **Date** : 2026-11-25
- **Statut** : à vérifier — **non compilé, non testé** (voir fiche 001)
- **Modules touchés** : `ischia-domain-api`, `ischia-domain`, `ischia-service-core`
- **Impact front** : aucun aujourd'hui (aucun endpoint n'utilise encore `@Valid`) → c'est le bon moment pour fixer le contrat.

---

## Pourquoi

L'ancien `handleMethodArgumentNotValid` + `ValidationErrorFactory` :

| Problème | Conséquence |
|---|---|
| Prenait le **message par défaut** de la contrainte (« must not be blank ») comme **clé** i18n, puis le re-traduisait | Double traduction incohérente ; avant la fiche 001, `NoSuchMessageException` → **500** |
| Reconstruisait une **structure imbriquée** qui imite le JSON de la requête (listes remplies de `null`, objet *ou* tableau selon le nombre d'erreurs), via une regex sur le chemin du champ | ~200 lignes, forme de réponse variable, difficile à consommer côté front |
| `parseFieldFromCode` devinait le champ d'une erreur de classe en découpant le texte du message | Fragile, dépend de la rédaction des messages |
| Ne traitait que `@Valid @RequestBody` | Une contrainte sur `@RequestParam` / `@PathVariable` (`HandlerMethodValidationException`) renvoyait un 400 **sans** liste d'erreurs ; un mauvais type JSON (date invalide) idem |
| Le catch-all `Exception` attrapait aussi `AccessDeniedException` (`@PreAuthorize`) | **403 transformé en 500** |

## Le nouveau contrat (RFC 9457 + tableau `errors` plat)

```json
{
  "type": "about:blank",
  "title": "Invalid request",
  "status": 400,
  "detail": "The request contains invalid fields.",
  "instance": "/ischia-service/api/v1/messages",
  "timestamp": "2026-11-25T10:15:30Z",
  "errors": [
    { "field": "subject",             "code": "NotBlank",      "message": "must not be blank" },
    { "field": "reference",           "code": "Size",          "message": "size must be between 0 and 5" },
    { "field": "recipients[1].email", "code": "Email",         "message": "must be a well-formed email address" },
    { "field": "observers[1]",        "code": "NotBlank",      "message": "must not be blank" },
    { "field": "end",                 "code": "ValidPeriod",   "message": "end must be after start" },
    { "field": null,                  "code": "SomeGlobalRule","message": "..." }
  ]
}
```

| Attribut | Contenu |
|---|---|
| `field` | Chemin de la valeur comme dans le JSON envoyé (`a.b[2].c`) ; nom du paramètre pour `@RequestParam` / `@PathVariable` / `@RequestHeader` (le nom vu par le client : `@RequestParam("q")` → `q`) ; `null` pour une règle sur l'objet entier |
| `code` | Nom de la contrainte (`NotBlank`, `Size`, `Email`, contrainte maison `ValidPeriod`...) ou `InvalidFormat` : **stable, indépendant de la langue**, c'est sur lui que le front branche sa logique |
| `message` | Déjà traduit dans la langue `Accept-Language` (FR / DE / EN), prêt à afficher |

**Même forme pour les 3 sources d'erreur de saisie** :

| Source | Exemple | `detail` |
|---|---|---|
| `@Valid @RequestBody` → `MethodArgumentNotValidException` | `@NotBlank String subject` | « The request contains invalid fields. » |
| Contraintes sur paramètres → `HandlerMethodValidationException` | `@RequestParam @Min(1) Integer page` | « Some parameters are invalid. » |
| Mauvais type dans le JSON → `HttpMessageNotReadableException` | `"start": "pas-une-date"` | « The request body is missing or malformed. » + `errors: [{field: "start", code: "InvalidFormat"}]` |

JSON syntaxiquement invalide (`{"subject": `) : 400 sans tableau `errors` (aucun champ identifiable).

`rejectedValue` n'est **plus renvoyé** : le front connaît déjà la valeur saisie, et ça évite de renvoyer des données
sensibles ou le `toString()` d'objets complexes. Facile à rajouter si besoin.

## Règles pour écrire les DTO (à partager avec l'équipe)

1. **Contraintes standard** (`@NotBlank`, `@Size`, `@Email`...) : rien à faire, messages traduits fournis par `ValidationMessages*.properties`.
2. **Personnaliser un message** sans toucher au DTO : ajouter dans `messages*.properties` une clé du plus précis au plus général,
   p. ex. `NotBlank.subject=Le sujet est obligatoire` ou `NotBlank=Ce champ est obligatoire`.
3. **Règle sur plusieurs champs** (contrainte de classe) : rattacher l'erreur au champ à corriger :
   ```java
   context.disableDefaultConstraintViolation();
   context.buildConstraintViolationWithTemplate(context.getDefaultConstraintMessageTemplate())
          .addPropertyNode("end")
          .addConstraintViolation();
   ```
   → `field: "end"`, que le front peut afficher sous le bon champ. Sans `addPropertyNode`, `field` vaut `null`.
4. Garder **noms Java = noms JSON** (éviter `@JsonProperty("autre_nom")`) : `field` est le chemin Java.
5. Contraintes sur `@RequestParam` / `@PathVariable` : **pas besoin de `@Validated`** sur le contrôleur
   (validation native de Spring MVC 6.1+). Avec `@Validated` sur la classe, Spring AOP lève une `ConstraintViolationException` : gérée depuis la fiche [005](005-validated-et-documentation-erreurs.md), même format.

## Fichiers

| Fichier | Changement |
|---|---|
| `ischia-domain-api/.../response/ValidationError.java` | **Nouveau** — `record ValidationError(field, code, message)`, réutilisable par un client Feign |
| `ischia-service-core/.../advice/ApiExceptionHandler.java` | `handleMethodArgumentNotValid` réécrit (≈10 lignes) ; **nouveaux** : `handleHandlerMethodValidationException`, `handleHttpMessageNotReadable`, `handleAccessDenied` (403) ; une seule méthode de conversion `toValidationError` pour toutes les sources |
| `ischia-service-core/.../advice/MessagesProvider.java` | Nouvelle méthode `get(MessageSourceResolvable)` (codes du plus précis au plus général, puis message Bean Validation, jamais d'exception) ; constructeur `public` (pour le test hors package) |
| `ischia-domain/.../application/validation/ValidationErrorFactory.java` | **Supprimé** (et le package `validation`) — c'était une préoccupation web logée dans le domain |
| `ischia-domain/src/main/resources/messages*.properties` | + titre / détail de `MethodArgumentNotValidException`, `validation.invalidFormat`, `access.denied` (EN / FR / DE) |
| `ischia-domain/src/main/resources/config-domain.yml` | `fallback-to-system-locale: false` : une langue non gérée (`en`, `it`) retombe sur `messages.properties` (anglais) et **non sur la langue de l'OS du serveur** |
| `ischia-service-core/src/test/.../errorcontract/ApiExceptionHandlerTests.java` | **Nouveau** — voir ci-dessous |

## Tests — `ApiExceptionHandlerTests`

MockMvc **standalone** (pas de contexte Spring, rapide) avec la vraie Bean Validation, les vrais fichiers de messages et le vrai Jackson.
Un contrôleur de test produit chaque type d'erreur. Package `lu.pgd.dri.ischia.errorcontract` **hors de** `lu.pgd.dri.ischia.web`
exprès : sinon ce contrôleur de test serait enregistré par le scan des tests `@SpringBootTest`.

| Groupe | Cas |
|---|---|
| Corps JSON (`@Valid`) | corps valide → 200 ; 5 erreurs (champ simple, attributs dans le message, objet dans une liste, élément de liste de chaînes, règle de classe rattachée à un champ) ; FR / DE selon `Accept-Language` ; langue non gérée → anglais ; règle de classe sans champ → `field: null` |
| Corps illisible | date invalide → `field: "start"`, `InvalidFormat` ; mauvais type dans une liste → `recipients[1]` ; JSON mal formé → pas d'`errors` |
| Paramètres | `@RequestParam` (+ nom client `q` ≠ nom Java `query`), `@PathVariable`, mauvais type → 400 |
| Autres | `AccessDeniedException` → **403** ; `ResourceNotFoundException` → 404 traduit (FR, apostrophe, id sans séparateur) ; exception inattendue → 500 sans détail technique |
| `MessagesProvider` | code inconnu → dernier code ; clé inconnue → la clé |

---

## Comment vérifier

- [ ] `mvn -pl ischia-service-core test -Dtest=ApiExceptionHandlerTests`
- [ ] Le projet compile avec `-parameters` (nécessaire pour `field` = nom Java d'un `@RequestParam` sans nom explicite ; déjà nécessaire pour les `@PathVariable Long id` existants)
- [ ] Valider le contrat JSON avec le front **avant** le premier endpoint `@Valid` (Message)
- [x] ~~Vérifier qu'aucun contrôleur n'a `@Validated` au niveau classe~~ → plus nécessaire (fiche 005)

## Reste à faire / pistes

- [x] ~~`ConstraintViolationException` → 500~~ → traité dans la fiche [005](005-validated-et-documentation-erreurs.md)
- [ ] `handleIOException` renvoie `null` sur déconnexion client : acceptable, mais à revoir si on ajoute du téléchargement de fichiers.
