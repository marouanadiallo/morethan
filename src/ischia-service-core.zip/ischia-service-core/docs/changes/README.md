# Journal des modifications

Une fiche par lot de modifications, à relire et vérifier avant commit.
Chaque fiche contient : le contexte, les fichiers touchés, comment vérifier, et ce qui reste à faire.

| Date | Fiche | Sujet | Statut |
|---|---|---|---|
| 2026-11-25 | [001-correctifs-config-et-audit.md](001-correctifs-config-et-audit.md) | Config Hibernate, messages i18n, dates et pertes d'audit, suppression entityName/entityId | À vérifier (non compilé) |
| 2026-11-25 | [002-annotations-audit-niveau-classe.md](002-annotations-audit-niveau-classe.md) | `@ConsultationLog` / `@DeletionLog` sur classe ou méthode, `@NoBusinessLog` | À vérifier (non compilé) |
| 2026-11-25 | [003-coherence-entites-et-referentiels.md](003-coherence-entites-et-referentiels.md) | Erreurs de mapping bloquantes, bugs du mapper, référentiels par canal, API Channel, tests unitaires + intégration | À vérifier (non compilé) |
| 2026-11-25 | [004-exception-handler-validation.md](004-exception-handler-validation.md) | Erreurs de validation : contrat `errors` plat (field/code/message), paramètres, JSON illisible, 403 | À vérifier (non compilé) |
| 2026-11-25 | [005-validated-et-documentation-erreurs.md](005-validated-et-documentation-erreurs.md) | `@Validated` → 400 même format ; erreurs triées ; documentation OpenAPI automatique des erreurs par endpoint | À vérifier (non compilé) |
