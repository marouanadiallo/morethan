# 002 — @ConsultationLog / @DeletionLog au niveau de la classe

- **Date** : 2026-11-25
- **Statut** : à vérifier — **non compilé, non testé** (voir fiche 001)
- **Modules touchés** : `ischia-audit`, `ischia-service-core`
- **Dépend de** : [001](001-correctifs-config-et-audit.md) (annotations devenues des marqueurs)

---

## Contexte

Les collègues trouvent qu'annoter chaque méthode est source d'oubli : un nouvel endpoint ajouté sans annotation
n'est pas journalisé. On veut pouvoir annoter **une classe** (tout le contrôleur) ou **une méthode précise**.

**Décision** : au niveau classe, le filtrage se fait **par verbe HTTP**, pour qu'un `POST` / `PUT` ne soit jamais
journalisé par erreur comme consultation.

## Règles (dans l'ordre)

| # | Situation | Résultat |
|---|---|---|
| 1 | `@NoBusinessLog` sur la méthode | Rien n'est journalisé (prioritaire sur tout le reste) |
| 2 | `@ConsultationLog` et/ou `@DeletionLog` sur la méthode | Exactement ceux-là, **quel que soit le verbe** ; les annotations de classe sont ignorées pour cette méthode |
| 3 | `@ConsultationLog` sur la classe (ou une classe parente) | Tous les handlers **`GET`** → consultation |
| 4 | `@DeletionLog` sur la classe (ou une classe parente) | Tous les handlers **`DELETE`** → suppression |
| — | `HEAD`, `POST`, `PUT`, `PATCH` sans annotation de méthode | Rien |

Toujours : seuls les appels **réussis (2xx)** sont journalisés (inchangé).

### Exemple

```java
@ConsultationLog
@DeletionLog
@RestController
class MessageController {

    @GetMapping("/{id}")        // → consultation (règle classe)
    MessageResponse get(...)

    @DeleteMapping("/{id}")     // → suppression (règle classe)
    void delete(...)

    @PostMapping                // → rien
    MessageResponse create(...)

    @ConsultationLog            // → consultation (explicite, verbe POST)
    @PostMapping("/search")
    Page<MessageResponse> search(...)

    @NoBusinessLog              // → exclu
    @GetMapping("/count")
    long count(...)
}
```

## Fichiers modifiés

| Fichier | Changement |
|---|---|
| `ischia-audit/.../business/ConsultationLog.java` | `@Target({TYPE, METHOD})`, `@Inherited`, Javadoc des règles |
| `ischia-audit/.../business/DeletionLog.java` | idem |
| `ischia-audit/.../business/NoBusinessLog.java` | **Nouveau** — exclusion d'une méthode |
| `ischia-audit/.../business/BusinessLogType.java` | **Nouveau** — enum `CONSULTATION`, `DELETION` (package-private) |
| `ischia-audit/.../business/BusinessLogResolver.java` | **Nouveau** — applique les règles ; cache par (classe du contrôleur, méthode) pour ne pas relire les annotations à chaque requête |
| `ischia-audit/.../business/BusinessLogInterceptor.java` | Utilise `BusinessLogResolver` au lieu de `hasMethodAnnotation` |
| `ischia-service-core/.../controller/AbstractReferentialController.java` | `@ConsultationLog` déplacé des 3 méthodes vers la classe (comportement identique : ce sont 3 `GET`) |
| `ischia-audit/pom.xml` | Ajout `spring-boot-starter-test` (scope test) — le module n'en avait pas |
| `ischia-audit/src/test/.../business/BusinessLogResolverTests.java` | **Nouveau** — 13 tests des règles |
| `ischia-audit/src/test/.../TodoTest.java` | **Supprimé** (classe vide) |

### Points techniques à relire

- **Recherche sur la classe** : `AnnotatedElementUtils.hasAnnotation(beanType, ...)` parcourt toute la hiérarchie
  (classes parentes abstraites, interfaces). `@Inherited` est ajouté pour la cohérence mais n'est pas indispensable.
- **Clé du cache = (classe du contrôleur, méthode)** et non la méthode seule : une méthode héritée
  (ex. `AbstractReferentialController.getAll`) est le même objet `Method` pour toutes les sous-classes,
  qui peuvent porter des annotations de classe différentes.
- `HandlerMethod.getBeanType()` renvoie la classe réelle (sans proxy CGLIB).
- `HEAD` n'est pas journalisé par la règle de classe (aucune donnée renvoyée), même si Spring l'aiguille vers les handlers `GET`.

---

## Comment vérifier

- [ ] `mvn -pl ischia-audit test` → `BusinessLogResolverTests` vert (13 tests)
- [ ] Vérifier que `spring-boot-starter-test` est bien géré par le parent (pas de version dans le POM du module)
- [ ] Démarrer l'appli, appeler `GET /ischia-service/api/v1/referential/message-types` → 1 ligne dans `IS_CONSULTATION_LOG_CL` (comme avant)
- [ ] Appeler `HEAD` sur la même URL → **aucune** ligne
- [ ] Relire les règles du tableau ci-dessus avec l'équipe et confirmer qu'elles conviennent

## Reste à faire / questions ouvertes

- [ ] `CountryController` et `UserUnitController` n'héritent pas de `AbstractReferentialController` et n'ont **aucune**
      annotation → leurs `GET` ne sont pas journalisés. À aligner (annoter la classe) **si** la lecture des référentiels doit être tracée.
- [ ] Question métier : faut-il vraiment journaliser la lecture des référentiels (volume important, peu de valeur légale) ?
- [ ] Option possible plus tard : un test d'architecture qui échoue si un `@RestController` métier n'a aucune annotation d'audit
      (garde-fou contre l'oubli d'annoter la classe elle-même).
