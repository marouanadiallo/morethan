# 003 — Cohérence des entités + tables de référence (services, API, tests)

- **Date** : 2026-11-25
- **Statut** : à vérifier — **non compilé, non testé** (voir fiche 001)
- **Modules touchés** : `ischia-domain`, `ischia-service-core`
- **Décisions prises avec toi** :
  - `IS_REF_MESSAGE_RELIABILITY_RMR` **a** une colonne `RCH_ID` ; `IS_REF_MESSAGE_DELAY_RMD` **n'en a pas**.
  - Parmi les référentiels sans API (Category, Channel, ConsultationScopeType, Zone), on expose seulement **Channel**.

---

## Partie A — Cohérence des entités

Réponse courte : **non, elles n'étaient pas cohérentes**. Plusieurs erreurs de mapping empêchaient très probablement
le contexte Spring de démarrer, et donc tout test `@SpringBootTest`.

### A.1 Corrigé — bloquant au démarrage

| Entité | Problème | Correction |
|---|---|---|
| Toutes les tables de référence, `AppUserEntity`, `LegalDocumentEntity`, `MessageEntity` | `@UniqueConstraint(columnNames = {"code"})` utilisait le **nom de l'attribut Java**. Hibernate attend le **nom de colonne** (`RCAT_CODE`...) → `AnnotationException ... database column 'code' not found` | Noms physiques : `RCAT_CODE`, `RCH_CODE`, …, `US_LOGIN`, `LD_DOCUMENT_NUMBER`, `MSG_REFENCE_ID` |
| `MessageReliabilityEntity` | `channel` joint sur `RMR_ID` = **sa propre clé primaire** (colonne mappée deux fois) | `@JoinColumn(name = "RCH_ID")` (cohérent avec le nom de FK `C_FK_RMR_RCH_ID`) |
| `PhysicalPersonAliasEntity` | `physicalPerson` joint sur `PPA_ID` = **sa propre clé primaire** | `@JoinColumn(name = "PP_ID")` (cohérent avec la FK `C_FK_PPA_PP_ID`) — ⚠️ à confirmer dans Flyway |
| `SagaComponentEntity` | **`@Entity` manquant** alors que `LegalDispositionEntity` a un `@ManyToOne` vers elle | Ajout de `@Entity` |
| `MessageAssignedUserEntity` | `@Enumerated(EnumType.STRING)` sur un `String` | Type `MessageAssignmentRole` (l'enum existait déjà) — constructeur adapté |
| `SagaFolderEntity` | Générateur nommé `seq_physical_person_gen` = **même nom** que celui de `PhysicalPersonEntity`, avec une autre séquence (les noms de générateur sont globaux) | Renommé `seq_saga_folder_gen`. ⚠️ La séquence reste `IS_CEG_S` (celle de CecimaIdentityGroup, sûrement un copier-coller) : **à vérifier** si `IS_SGF_S` existe dans Flyway |

### A.2 Corrigé — bugs fonctionnels sur les référentiels

| Où | Problème | Correction |
|---|---|---|
| `ReferentialMapper.toReferenceResponse` | `AbstractReferenceEntity` n'avait pas de `getId()` → MapStruct ne pouvait pas le lire → **`"id": null` dans toutes les réponses des référentiels génériques** | `public abstract Long getId()` dans `AbstractReferenceEntity` (implémenté par le `@Getter` Lombok de chaque sous-classe) |
| `ReferentialMapper.toReferentialCountry` | `alphacode2` ≠ `alphaCode2` (MapStruct est sensible à la casse) → **`alphaCode2` / `alphaCode3` toujours null** | `@Mapping` explicites |
| `ReferentialMapper` | Méthode `toChannelReferentialResponse(MessageDelayRefEntity)` lisant `channel.id` alors que l'entité n'a pas de `channel` → **erreur de compilation MapStruct** | Méthode supprimée ; ajout des méthodes pour `CrimeAreaEntity` et `MessageReliabilityEntity` |
| `AbstractReferenceEntity.equals/hashCode`, `CountryEntity` | NPE si `code` null ; `getClass()` faux avec un **proxy Hibernate** (références chargées en LAZY) ; lecture des champs (vides sur un proxy) | Comparaison de la classe réelle (sans initialiser le proxy), lecture par getters, null-safe |
| `messages_fr.properties`, `messages_de.properties` | `{}` au lieu de `{0}` → `IllegalArgumentException` de MessageFormat → **les 404 devenaient des 500 en FR/DE** ; `l'identifiant` : l'apostrophe simple est un caractère d'échappement MessageFormat | `{0}`, `l''identifiant` |
| `messages*.properties` (`referential.notfound.byId`) | MessageFormat formate un nombre avec séparateurs : « id 9,001 » / « 9 001 » | `{0,number,#}` |

### A.3 Non corrigé — à traiter plus tard (non bloquant)

- [ ] `equals/hashCode` qui lèvent une **NPE** si le champ est null : `MessageEntity` (`referenceID`), `AppUserEntity` (`email`), `MailAddressEntity` (`email`), `CecimaIdentityGroupEntity` (`cecimaGroupId`). Même problème de proxy que ci-dessus. → à traiter avec le point 5 (MessageEntity).
- [ ] `MessageEntity` : faute de frappe `REFENCE` dans les noms de colonne/contrainte (à aligner avec Flyway si on corrige) ; `MSG_VERSION` est un `Long` sans `@Version` (verrouillage optimiste voulu ?) ; tous les `@Comment("")` vides.
- [ ] `IdentityCecimaEntity`, `PhysicalPersonMatchEntity` : associations déclarées `final` — risque avec l'enhancement bytecode Hibernate (`hibernate-enhance-maven-plugin`) : à vérifier au démarrage.
- [ ] `VehicleEntity` : `@AllArgsConstructor` expose un constructeur qui inclut l'`id`.
- [ ] `PhysicalPersonAliasEntity` : constructeur sans argument `public` (les autres sont `protected`).
- [ ] Dates « jour » stockées en `Instant` (`deliveryDate`, `expirationDate`, `firstRegistrationDate`) : `LocalDate` serait plus juste.
- [ ] Nommage : `IS_ZONE_ZNE` (sans `REF_`), `IS_MAP_MESSAGE_ASSIGNMENT_MMAUS` vs `IS_MESSAGE_ASSIGNED_UNIT_MMAUN`, FK `C_FK_MR_*` dans `MailAddressEntity` (devrait être `MAD`), contraintes `C_U_RMC_ID` / `C_U_RDC_ID` / `C_U_RNT_ID` sur la colonne CODE.
- [ ] 🔐 `ischia-service-core/src/test/resources/bootstrap-test.yml` contient un **secret client Keycloak en clair** (realm DEV) : à sortir du dépôt (variable d'environnement) et à faire régénérer.

---

## Partie B — Tables de référence

### B.1 Vue d'ensemble de l'API (préfixe `/ischia-service/api/v1/referential/`)

Tous les endpoints sont en lecture (`GET`), journalisés en consultation (`@ConsultationLog` sur la classe).

| Endpoint | Table | Type | Réponse |
|---|---|---|---|
| `channel-types` | RCH | générique — **nouveau** | `ReferentialResponse` |
| `document-category-types` | RDC | générique | `ReferentialResponse` |
| `message-delay-types` | RMD | générique | `ReferentialResponse` |
| `message-status-types` | RMS | générique | `ReferentialResponse` |
| `message-types` | RMT | générique | `ReferentialResponse` |
| `nationality-types` | RNT | générique | `ReferentialResponse` |
| `organization-types` | RO | générique | `ReferentialResponse` |
| `unit-organization-types` | RUO | générique | `ReferentialResponse` |
| `crime-area-types` | RCA | **par canal** — modifié | `ChannelReferentialResponse` (+ `channelId`) |
| `message-confidentiality-types` | RMC | **par canal** — modifié | idem |
| `message-handling-code-types` | RMHC | **par canal** — modifié | idem |
| `message-priority-types` | RMP | **par canal** — modifié | idem |
| `message-reliability-types` | RMR | **par canal** — modifié | idem |
| `country-types` | RCTY | spécifique | `ReferentialCountryResponse` |
| `user-unit-types` | RUUT | spécifique | `ReferentialUserUnitResponse` (+ `organizationId`) |

Pour chaque endpoint : `GET /` (liste des valeurs **valides aujourd'hui**), `GET /{id}`, `GET /code/{code}` (insensible à la casse ;
pour un pays : alpha-2 **ou** alpha-3). Les recherches par id / code **ignorent la validité** (un message ancien doit pouvoir
afficher une valeur expirée). Les référentiels par canal acceptent en plus `GET /?channelId=…`.

> ⚠️ **Changement de contrat** pour les 5 référentiels par canal : la réponse gagne un champ `channelId` (ajout, non cassant pour le front).

### B.2 Fichiers — domain

| Fichier | Changement |
|---|---|
| `persistence/repository/reference/ChannelReferenceBaseRepository.java` | **Nouveau** — `findValidateReferencesByChannelId(channelId)` |
| `CrimeAreaRepository`, `MessageConfidentialityRepository`, `MessageHandlingCodeRepository`, `MessagePriorityRepository`, `MessageReliabilityRepository` | étendent `ChannelReferenceBaseRepository` |
| `application/service/AbstractChannelReferentialService.java` | Était une classe vide → implémentée : `getAll(channelId?)`, `getById`, `getByCode`, réponse `ChannelReferentialResponse` |
| `CrimeAreaService`, `MessageConfidentialityService`, `MessageHandlingCodeService`, `MessagePriorityService`, `MessageReliabilityService` | étendent `AbstractChannelReferentialService` (passent `referentialMapper::toChannelReferentialResponse`) |
| `application/service/referential/ChannelService.java` | **Nouveau** |
| `application/mapper/ReferentialMapper.java` | voir A.2 |
| `persistence/entity/reference/AbstractReferenceEntity.java`, `CountryEntity.java` | voir A.2 |

### B.3 Fichiers — web

| Fichier | Changement |
|---|---|
| `controller/AbstractChannelReferentialController.java` | **Nouveau** — `@ConsultationLog` sur la classe, `?channelId=` optionnel |
| `controller/AbstractReferentialController.java` | `getByCode` passe de `protected` à `public` (cohérence) |
| `CrimeArea/MessageConfidentiality/MessageHandlingCode/MessagePriority/MessageReliability Controller` | étendent `AbstractChannelReferentialController` |
| `controller/referential/ChannelController.java` | **Nouveau** — `/v1/referential/channel-types` |
| `CountryController`, `UserUnitController` | `@ConsultationLog` sur la classe (avant : **aucune** trace de consultation, incohérent avec les autres) |

### B.4 Tests

| Test | Type | Couvre |
|---|---|---|
| `domain/.../mapper/ReferentialMapperTests` | unitaire, **nouveau** | Code MapStruct généré sur de vraies entités : `id`, `channelId` (×5), `organizationId`, `alphaCode2/3` — aurait détecté les 3 bugs de A.2 |
| `domain/.../entity/reference/ReferenceEntityEqualityTests` | unitaire, **nouveau** | equals/hashCode : même code, codes différents, types différents, code null, HashSet, Country |
| `domain/.../service/AbstractChannelReferentialServiceTests` | unitaire, **nouveau** | getAll avec / sans canal, getById, getByCode, clés d'erreur |
| `domain/.../referential/ChannelReferentialServiceWiringTests` | unitaire, **nouveau** | Chaque service par canal utilise son repository (avec / sans filtre) |
| `domain/.../service/AbstractReferentialServiceTests` | unitaire, **modifié** | Utilise `MessageTypeService` (MessageConfidentiality est devenu « par canal ») |
| `domain/.../referential/ReferentialServiceWiringTests` | unitaire, **modifié** | Retrait des 5 services par canal, ajout de `ChannelService` |
| `domain/testsupport/TestEntities` | utilitaire, **nouveau** | Instancie de vraies entités (constructeur protégé, id final) par réflexion |
| `web/.../MessageTypeControllerTests` | `@WebMvcTest`, **nouveau** | Contrôleur générique : 200, liste vide, 400 (id non numérique), 404 ProblemDetail (+ `timestamp`) |
| `web/.../MessageReliabilityControllerTests` | `@WebMvcTest`, **réécrit** | Contrôleur par canal : `channelId` dans la réponse, filtre, 400 sur `channelId=abc`, 404 |
| `web/.../SpecificReferentialControllerTests` | `@WebMvcTest`, **nouveau** | Country (alpha-2 / alpha-3) et UserUnit (`organizationId`) |
| `web/.../ReferentialIT` | intégration H2 + Flyway, **réécrit** | **Les 15 endpoints** de bout en bout : filtrage par validité, id, code insensible à la casse, valeur expirée accessible par code, 404, 400, filtre par canal, Country, UserUnit, **écriture de la trace de consultation** (et absence de trace sur un 404) |
| `web/src/test/resources/sql/referential-data.sql` | données, **nouveau** | Pour chaque table : `IT_VALID`, `IT_EXPIRED`, `IT_FUTURE` (ids ≥ 9001) ; 2 canaux (9001, 9004) |
| `web/src/test/resources/sql/message-reliability.sql` | **supprimé** | Remplacé par `referential-data.sql` |

Choix techniques de `ReferentialIT` :
- `MockMvc` en environnement `MOCK` (plus `RANDOM_PORT`) : la requête tourne dans le thread du test, donc **dans la transaction du test** → tout est annulé (rollback), y compris les traces de consultation.
- Les assertions ne regardent que les lignes `IT_*` : si Flyway insère des données de référence, les tests restent verts.
- Ce test vérifie aussi que **le mapping JPA correspond au schéma Flyway** (noms de tables / colonnes, `RCH_ID`...) : s'il échoue sur un INSERT du fichier SQL, c'est le signe d'un écart entité ↔ Flyway.

---

## Comment vérifier

- [ ] `mvn -pl ischia-domain test` (MapStruct doit générer `ReferentialMapperImpl` **sans warning "Unmapped target property"**)
- [ ] `mvn -pl ischia-service-core verify` (lance aussi `ReferentialIT` via failsafe)
- [ ] Si `ReferentialIT` échoue **au chargement du SQL** : comparer le nom de la table / colonne en erreur avec les scripts `ischia-flyway` (c'est là que se verront les écarts restants : `RCH_ID` sur RMR, `PP_ID` sur PPA, colonnes `*_CREATED_*`...)
- [ ] Démarrer l'appli en local et vérifier dans Swagger le groupe « API - Reference types » (15 endpoints, `channelId` en paramètre pour les 5 référentiels par canal)
- [ ] Prévenir le front : nouveau champ `channelId`, nouveau endpoint `channel-types`, `id` désormais renseigné (il était `null` !), `alphaCode2/3` désormais renseignés

## Reste à faire

- [ ] Vérifier dans Flyway : séquence de `IS_SAGA_FOLDER_SGF` (`IS_SGF_S` ?), colonne `PP_ID` dans `IS_PHYSICAL_PERSON_ALIAS_PPA`, `RCH_ID` dans `IS_REF_MESSAGE_RELIABILITY_RMR` (NOT NULL ?)
- [ ] Points A.3
- [ ] `ConsultationScopeType` n'est pas exposé : le front devra connaître les ids pour envoyer `scopeId` lors des consultations (à rediscuter quand on fera les messages)
