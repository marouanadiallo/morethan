# 005 — Validation `@Validated` + documentation OpenAPI des erreurs

- **Date** : 2026-11-25
- **Statut** : à vérifier — **non compilé, non testé** (voir fiche 001)
- **Module touché** : `ischia-service-core` (+ messages dans `ischia-domain`)
- **Dépend de** : [004](004-exception-handler-validation.md) (contrat `errors`)

---

## Partie A — `@Validated` (services et contrôleurs)

### Problème

Un bean annoté `@Validated` (typiquement un service : `create(@Valid MessageRequest request)`, `find(@Min(1) Long id)`) est validé
par un proxy AOP de Spring, **en dehors** du binding Spring MVC. Il lève `jakarta.validation.ConstraintViolationException`,
qui tombait dans le catch-all → **500** au lieu de 400.

### Solution — `ApiExceptionHandler.handleConstraintViolation`

| Violation sur… | Signification | Réponse |
|---|---|---|
| un paramètre de méthode | donnée envoyée par le client | **400**, **même format** `errors` que `@Valid @RequestBody` |
| la valeur de retour (`@NotNull` sur la méthode...) | le serveur a produit une donnée invalide = bug | **500** (via le catch-all, sans détail technique) |

Conversion du chemin Bean Validation vers la notation du contrat :

| Chemin Bean Validation | `field` renvoyé |
|---|---|
| `create.request.subject` | `subject` |
| `create.request.recipients[1].email` | `recipients[1].email` |
| `create.request.observers[1].<list element>` | `observers[1]` |
| `find.id` (paramètre simple) | `id` |
| contrainte cross-parameter | `null` |

Le nom de méthode est retiré, ainsi que le nom du paramètre quand l'erreur est **dans** l'objet :
on obtient exactement les mêmes chemins qu'avec `@Valid @RequestBody` dans le contrôleur.
Le message est celui de Bean Validation, déjà traduit selon `Accept-Language`.

Différences (assumées) avec la validation dans le contrôleur :
- les surcharges de message par code (`NotBlank.subject=...` dans `messages.properties`) ne s'appliquent pas ici
  (pas de codes Spring sur une `ConstraintViolation`) ; seuls les messages Bean Validation / `{clé}` des contraintes ;
- une contrainte de classe **sans** `addPropertyNode` renvoie le nom du paramètre (`request`) au lieu de `null`.

### Tri des erreurs

Bean Validation renvoie les violations dans un `Set` (ordre aléatoire) : les `errors` sont maintenant **triés par `field`**
(les `null` en premier) pour les 4 sources (corps, paramètres, JSON illisible, `@Validated`). Réponse stable → tests et
snapshots front stables.

### Fichiers

| Fichier | Changement |
|---|---|
| `ischia-service-core/.../advice/ApiExceptionHandler.java` | + `handleConstraintViolation`, `violationPath`, `isOnReturnValue`, `sorted` ; tri appliqué aux autres handlers |
| `ischia-domain/src/main/resources/messages*.properties` | + titre / détail de `jakarta.validation.ConstraintViolationException` (EN / FR / DE) |
| `ischia-service-core/src/test/.../errorcontract/ApiExceptionHandlerTests.java` | + groupe `ValidatedService` (6 tests) : service validé par un **vrai proxy** `MethodValidationInterceptor` (même mécanisme que le `MethodValidationPostProcessor` de Spring Boot) |

Tests ajoutés : entrée valide → 200 ; 5 erreurs avec les mêmes chemins que la validation contrôleur ; tri par champ ;
traduction FR ; paramètre simple → `id` ; valeur de retour invalide → 500 sans `errors`.

---

## Partie B — Documentation OpenAPI des erreurs de chaque endpoint

### Problème

Swagger ne documentait que le `200`. Le front ne savait pas quelles erreurs attendre ni leur format.
Annoter chaque endpoint (`@ApiResponse(responseCode = "404", content = ...)`) serait verbeux et **oublié** sur les nouveaux endpoints.

### Solution — `ApiErrorDocumentation` (automatique, déduit du code de l'endpoint)

| Code | Ajouté quand | Contenu documenté |
|---|---|---|
| 400 | l'endpoint reçoit une entrée (`@RequestBody`, `@RequestParam`, `@PathVariable`, `@RequestHeader`, `@RequestPart`, `@ModelAttribute`) | `ValidationProblemDetail` (ProblemDetail + `errors[]`) + exemple |
| 401 | toujours (jeton obligatoire) | **pas de corps** (c'est Spring Security qui répond) + en-tête `WWW-Authenticate` |
| 403 | `@PreAuthorize` / `@PostAuthorize` / `@Secured` sur la méthode ou la classe | `ProblemDetail` + exemple |
| 404 | le chemin contient une variable (`{id}`, `{code}`) | `ProblemDetail` + exemple |
| 409 | `POST` / `PUT` / `PATCH` / `DELETE` | `ProblemDetail` + exemple |
| 500 | toujours | `ProblemDetail` + exemple (+ rappel : donner l'en-tête `x-b3-trace-id` au support) |

- Les réponses et schémas sont déclarés **une seule fois** dans `components` (`responses` : `BadRequest`, `Unauthorized`,
  `Forbidden`, `NotFound`, `Conflict`, `InternalError` ; `schemas` : `ProblemDetail`, `ValidationProblemDetail`, `ValidationError`)
  et **référencés** (`$ref`) par chaque opération → spec compacte.
- Une réponse déclarée explicitement sur un endpoint (`@ApiResponse(responseCode = "404", description = "...")`)
  **n'est jamais écrasée** : on peut toujours préciser un cas métier.
- Appliqué aux 2 groupes Swagger (« API - Reference types » et « API - Main »).

Résultat sur les référentiels existants :

| Endpoint | Erreurs documentées |
|---|---|
| `GET /…-types` (générique, Country, UserUnit) | 401, 500 |
| `GET /…-types?channelId=` (par canal) | 400, 401, 500 |
| `GET /…-types/{id}`, `GET /…-types/code/{code}` | 400, 401, 404, 500 |

### Fichiers

| Fichier | Changement |
|---|---|
| `ischia-service-core/.../config/ApiErrorDocumentation.java` | **Nouveau** — `OperationCustomizer` (règles ci-dessus) + `addComponents(OpenAPI)` |
| `ischia-service-core/.../config/ApiDocumentationConfigurer.java` | Ajoute le customizer et les components aux 2 `GroupedOpenApi` (volontairement pas un bean : sinon springdoc l'appliquerait aussi globalement) |
| `ischia-service-core/src/main/resources/application.yml` | `springdoc.override-with-generic-response: false` : springdoc ne devine plus de réponses à partir du `@RestControllerAdvice` (sinon doublons / schémas `ResponseEntity<Object>` vides) |
| `ischia-service-core/src/test/.../config/ApiErrorDocumentationTests.java` | **Nouveau** — 17 tests |

Tests : chaque règle (sans entrée, variable de chemin, paramètre de requête, POST, PUT, DELETE, rôle sur méthode / classe),
réponse explicite jamais écrasée, `$ref` corrects, **vrais endpoints** des référentiels (générique, par canal),
components complets (schémas, exemple avec `errors`, 401 sans corps avec en-tête), components existants conservés.

---

## Comment vérifier

- [ ] `mvn -pl ischia-service-core test -Dtest='ApiExceptionHandlerTests,ApiErrorDocumentationTests'`
- [ ] Démarrer l'appli en local, ouvrir Swagger UI : sur `GET /api/v1/referential/message-types/{id}`, les réponses 400 / 401 / 404 / 500 apparaissent avec leur exemple ; « Schemas » contient `ProblemDetail`, `ValidationProblemDetail`, `ValidationError`
- [ ] Vérifier que la version de springdoc fournit bien `GroupedOpenApi.Builder.addOperationCustomizer` (springdoc 2.x : oui)
- [ ] Les tests de profil `test` désactivent `springdoc.api-docs` : la spec générée n'est vérifiée qu'en unitaire

## Reste à faire / pistes

- [ ] Si des règles d'accès sont faites au niveau des URL (dans la config Spring Security) plutôt qu'avec `@PreAuthorize`,
      le 403 ne sera pas détecté automatiquement : le déclarer avec `@ApiResponse(responseCode = "403", ref = "Forbidden")`.
- [ ] Exemples de la documentation en anglais uniquement (les vraies réponses, elles, suivent `Accept-Language`).
