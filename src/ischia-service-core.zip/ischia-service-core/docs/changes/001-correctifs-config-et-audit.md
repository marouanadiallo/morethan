# 001 — Correctifs config Hibernate, messages i18n et audit

- **Date** : 2026-11-25
- **Statut** : à vérifier — **non compilé, non testé** (parent POM `ischia-service` et libs `lu.pgd.dri:*` absents en local)
- **Modules touchés** : `ischia-domain`, `ischia-audit`, `ischia-service-core`

---

## 1. Propriétés Hibernate ignorées

**Problème** : dans `config-domain.yml`, les réglages Hibernate étaient sous `spring.jpa.hibernate.*`.
Spring Boot n'y lit que `ddl-auto` et `naming` : tout le reste était **silencieusement ignoré**.
De plus les noms étaient faux (`order_insert`, `order_update`, `batch_size`) et `order_insert: true,` avait une virgule parasite.

**Correction** — `ischia-domain/src/main/resources/config-domain.yml` :

| Avant (ignoré) | Après |
|---|---|
| `spring.jpa.hibernate.id.optimizer.pooled.preferred` | `spring.jpa.properties.hibernate.id.optimizer.pooled.preferred` |
| `spring.jpa.hibernate.connection.provider_disables_autocommit` | `spring.jpa.properties.hibernate.connection.provider_disables_autocommit` |
| `spring.jpa.hibernate.query.fail_on_pagination_over_collection_fetch` | `spring.jpa.properties.hibernate.query.fail_on_pagination_over_collection_fetch` |
| `spring.jpa.hibernate.query.in_clause_parameter_padding` | `spring.jpa.properties.hibernate.query.in_clause_parameter_padding` |
| `spring.jpa.hibernate.query.order_insert: true,` | `spring.jpa.properties.hibernate.order_inserts: true` |
| `spring.jpa.hibernate.query.order_update` | `spring.jpa.properties.hibernate.order_updates` |
| `spring.jpa.hibernate.query.batch_size` | `spring.jpa.properties.hibernate.jdbc.batch_size` |

`ddl-auto: validate` reste sous `spring.jpa.hibernate`.

> ⚠️ **Effet de bord** : `pooled-lo` devient réellement actif (avant, Hibernate utilisait `pooled`).
> Le calcul des IDs à partir des séquences change. Sans risque sur une base neuve ou à l'arrêt complet ;
> **risque de doublons d'ID** si une ancienne et une nouvelle instance tournent en même temps (déploiement progressif).
> Les séquences doivent avoir `INCREMENT BY 20` (= `allocationSize`).

## 2. Messages i18n : casse du basename et 500 sur erreur de validation

**Problème** :
- `basename: messages, validationMessages` alors que le fichier est `ValidationMessages.properties`.
  OK sous Windows, **introuvable dans un JAR sous Linux** (sensible à la casse).
- `ApiExceptionHandler` passe le message par défaut de la contrainte (ex. « must not be null ») à `MessagesProvider.get()`,
  qui levait `NoSuchMessageException` si la clé n'existe pas → **une erreur 400 devenait une 500**.

**Correction** :
- `config-domain.yml` : `basename: messages,ValidationMessages`
- `ischia-service-core/.../controller/advice/MessagesProvider.java` : `get()` renvoie la clé elle-même si elle est introuvable (ne lève plus jamais d'exception).

## 3. Dates de l'audit HTTP faussées

**Problème** : `HttpAuditRecorder` remplissait `startDate`/`endDate` avec `Instant.now()` **au moment de l'écriture asynchrone**,
en ignorant les `start`/`end` capturés par le filtre / le client Feign. La durée réelle des requêtes était perdue.

**Correction** — `ischia-audit/.../http/HttpAuditRecorder.java` : utilise `r.start()`/`r.end()` (entrant) et `c.start()`/`c.end()` (sortant).

## 4. Lignes d'audit perdues silencieusement

**Problème** : l'INSERT échouait (simple WARN/ERROR dans les logs) quand :
- le traceId était `null` (tracer NOOP, thread sans span) alors que les colonnes `*_TRACE_ID` / `AOG_CORRELATION_ID` sont `NOT NULL` ;
- une valeur dépassait la taille de sa colonne : headers (4000), URL et query string dans l'intercepteur (2000), motif (300), origin-app / userId (255).

**Correction** :

| Fichier | Changement |
|---|---|
| `ischia-audit/.../config/Truncator.java` | **Nouveau** — `truncate(value, max)` partagé (déplacé depuis `HttpAuditRecorder`) |
| `ischia-audit/.../config/ValidationConstraints.java` | Nouvelles constantes : `TRACE_ID_MAX_SIZE`, `QUERY_PARAMETERS_MAX_SIZE`, `HEADERS_MAX_SIZE`, `MOTIVE_MAX_SIZE`, `DEFAULT_VARCHAR_MAX_SIZE` |
| `ischia-audit/.../config/AuditProperties.java` | Nouvelle propriété `api.audit.unknown-trace` (défaut `NO_TRACE`) |
| `ischia-audit/.../config/AuditConfiguration.java` | `CurrentTrace` reçoit `unknownTrace` |
| `ischia-audit/.../trace/CurrentTrace.java` | Nouvelle méthode `auditTraceId()` : traceId ou valeur de repli, jamais null. `traceId()` inchangé (peut renvoyer null, utilisé par `TraceIdResponseFilter`) |
| `ischia-audit/.../http/HttpAuditFilter.java` | `auditTraceId()` |
| `ischia-audit/.../feign/FeignAuditClient.java` | `auditTraceId()` |
| `ischia-audit/.../http/HttpAuditRecorder.java` | Troncature de tous les champs à la taille de leur colonne |
| `ischia-audit/.../business/BusinessLogInterceptor.java` | Troncature URL, query string, motif, userId, traceId, body |

## 5. Suppression de entityName / entityId (consultation & suppression)

**Décision** : on ne stocke plus `entityName` ni `entityId` dans `IS_CONSULTATION_LOG_CL` et `IS_DELETION_LOG_DL`.

| Fichier | Changement |
|---|---|
| `ConsultationLogEntryEntity`, `DeletionLogEntryEntity` | Champs retirés (fait par toi) |
| `DeletionLogEntryEntity.of(...)` | Signature `of(traceId, url, userId)` (le paramètre `entityName` ne compilait plus) |
| `ConsultationLog`, `DeletionLog` | Deviennent des **annotations marqueurs** sans attribut (`entity`, `idVariable` supprimés) |
| `BusinessLogInterceptor` | `hasMethodAnnotation(...)` ; suppression de `pathVariable()` et du remplissage entity* |
| `AbstractReferentialController` | `@ConsultationLog()` → `@ConsultationLog` |

**Pourquoi garder les annotations** : elles désignent les endpoints à journaliser. Déduire depuis le verbe HTTP serait faux
(un `POST /search` est une consultation, un `GET` de référentiel n'en est peut-être pas une).

---

## Comment vérifier

- [ ] `mvn verify` sur les 4 modules
- [ ] Démarrage en local : pas d'erreur de binding sur `api.audit.*` ni sur les propriétés Hibernate
- [ ] Logs Hibernate au démarrage (`logging.level.org.hibernate.cfg=DEBUG` ou équivalent) : `hibernate.jdbc.batch_size=50`, `hibernate.order_inserts=true` sont bien pris en compte
- [ ] Appeler un endpoint avec un body invalide (`@Valid`) → **400** avec le bloc `errors`, pas 500
- [ ] Appeler un référentiel → ligne dans `IS_AUDIT_ENTRY_AE` avec `AE_START_DATE` < `AE_END_DATE` (durée réelle)
- [ ] Ligne dans `IS_CONSULTATION_LOG_CL` sans colonnes entity
- [ ] Appel avec une très longue query string (> 2000 car.) → la ligne d'audit est écrite, URL terminée par `...[truncated]`

## Reste à faire

- [ ] **Migration Flyway** (`ischia-flyway`, hors de ce workspace) : supprimer `CL_ENTITY_NAME`, `CL_ENTITY_ID`, `DL_ENTITY_NAME`, `DL_ENTITY_ID`.
      Tant que `DL_ENTITY_NAME` (probablement `NOT NULL`) existe, **chaque log de suppression échouera**.
- [ ] Décider du mode de déploiement vu le passage à `pooled-lo` (voir §1).
- [ ] Tests unitaires du module audit (`TodoTest` est vide).
