-- Date : 11-27-2026
-- DDL of IS_DELETION_LOG_DL table (DeletionLogEntryEntity)

-- Create table
CREATE TABLE IS_DELETION_LOG_DL (
    DL_ID       NUMBER(19),
    DL_TRACE_ID VARCHAR2(64 CHAR) CONSTRAINT C_DL_TRACE_ID_REQUIRED NOT NULL,
    DL_URL      VARCHAR2(2000 CHAR) CONSTRAINT C_DL_URL_REQUIRED NOT NULL,
    DL_MOTIVE   VARCHAR2(300 CHAR),
    DL_TIME     TIMESTAMP CONSTRAINT C_DL_TIME_REQUIRED NOT NULL,
    DL_USER_ID  VARCHAR2(255 CHAR) CONSTRAINT C_DL_USER_ID_REQUIRED NOT NULL,
    CONSTRAINT C_PK_DL_ID PRIMARY KEY (DL_ID)
) ${tablespace_data}; -- flyway placeholder

-- Create sequence (INCREMENT BY = allocationSize of the entity)
CREATE SEQUENCE IS_DL_S START WITH 1 INCREMENT BY 20 CACHE 20;

-- Comments
COMMENT ON TABLE IS_DELETION_LOG_DL IS 'Stores deletion traces for ISCHIA entities';
COMMENT ON COLUMN IS_DELETION_LOG_DL.DL_ID IS 'Technical identifier of the deletion log entry';
COMMENT ON COLUMN IS_DELETION_LOG_DL.DL_TRACE_ID IS 'Trace identifier propagated across the request flow';
COMMENT ON COLUMN IS_DELETION_LOG_DL.DL_URL IS 'Full URL of the deleted resource';
COMMENT ON COLUMN IS_DELETION_LOG_DL.DL_MOTIVE IS 'Optional motive provided for the deletion';
COMMENT ON COLUMN IS_DELETION_LOG_DL.DL_TIME IS 'Timestamp when the deletion was logged';
COMMENT ON COLUMN IS_DELETION_LOG_DL.DL_USER_ID IS 'Identifier of the authenticated user who performed the deletion';
