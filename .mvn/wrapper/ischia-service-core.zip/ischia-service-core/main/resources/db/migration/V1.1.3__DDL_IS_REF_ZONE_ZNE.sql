-- Date : 11-27-2026
-- DDL of IS_REF_ZONE_ZNE table (ZoneEntity)

-- Create table
CREATE TABLE IS_REF_ZONE_ZNE (
    ZNE_ID            NUMBER(19),
    ZNE_CODE          VARCHAR2(100 CHAR) CONSTRAINT C_ZNE_CODE_REQUIRED NOT NULL,
    ZNE_LABEL_DE      VARCHAR2(100 CHAR),
    ZNE_LABEL_EN      VARCHAR2(100 CHAR),
    ZNE_LABEL_FR      VARCHAR2(100 CHAR),
    ZNE_VALIDITY_FROM DATE,
    ZNE_VALIDITY_TO   DATE,
    ZNE_CREATED_AT    TIMESTAMP CONSTRAINT C_ZNE_CREATED_AT_REQUIRED NOT NULL,
    ZNE_CREATED_BY    VARCHAR2(50 CHAR) CONSTRAINT C_ZNE_CREATED_BY_REQUIRED NOT NULL,
    ZNE_UPDATED_AT    TIMESTAMP,
    ZNE_UPDATED_BY    VARCHAR2(50 CHAR),
    CONSTRAINT C_PK_ZNE_ID PRIMARY KEY (ZNE_ID),
    CONSTRAINT C_U_ZNE_CODE UNIQUE (ZNE_CODE)
) ${tablespace_data}; -- flyway placeholder

-- Create sequence (INCREMENT BY = allocationSize of the entity)
CREATE SEQUENCE IS_ZNE_S START WITH 1 INCREMENT BY 20 CACHE 20;

-- Comments
COMMENT ON TABLE IS_REF_ZONE_ZNE IS 'Reference table of geographic zones grouping countries';
COMMENT ON COLUMN IS_REF_ZONE_ZNE.ZNE_ID IS 'Technical identifier of the entry';
COMMENT ON COLUMN IS_REF_ZONE_ZNE.ZNE_CODE IS 'Unique code identifying the entry';
COMMENT ON COLUMN IS_REF_ZONE_ZNE.ZNE_LABEL_DE IS 'Label of the entry in German';
COMMENT ON COLUMN IS_REF_ZONE_ZNE.ZNE_LABEL_EN IS 'Label of the entry in English';
COMMENT ON COLUMN IS_REF_ZONE_ZNE.ZNE_LABEL_FR IS 'Label of the entry in French';
COMMENT ON COLUMN IS_REF_ZONE_ZNE.ZNE_VALIDITY_FROM IS 'Date from which the entry is valid (null = no lower bound)';
COMMENT ON COLUMN IS_REF_ZONE_ZNE.ZNE_VALIDITY_TO IS 'Date until which the entry is valid (null = no upper bound)';
COMMENT ON COLUMN IS_REF_ZONE_ZNE.ZNE_CREATED_AT IS 'Timestamp of the creation of the entry';
COMMENT ON COLUMN IS_REF_ZONE_ZNE.ZNE_CREATED_BY IS 'User who created the entry';
COMMENT ON COLUMN IS_REF_ZONE_ZNE.ZNE_UPDATED_AT IS 'Timestamp of the last change on the entry';
COMMENT ON COLUMN IS_REF_ZONE_ZNE.ZNE_UPDATED_BY IS 'User who applied the last change on the entry';
