-- Date : 11-27-2026
-- DDL of IS_EXTERNAL_REF_ER table (ExternalReferenceEntity)

-- Create table
CREATE TABLE IS_EXTERNAL_REF_ER (
    ER_ID                 NUMBER(19),
    ER_APPLICATION_SOURCE VARCHAR2(100 CHAR),
    ER_EXTERNAL_REF       VARCHAR2(100 CHAR),
    MSG_ID                NUMBER(19) CONSTRAINT C_FK_ER_MSG_ID_REQUIRED NOT NULL,
    ER_CREATED_AT         TIMESTAMP CONSTRAINT C_ER_CREATED_AT_REQUIRED NOT NULL,
    ER_CREATED_BY         VARCHAR2(50 CHAR) CONSTRAINT C_ER_CREATED_BY_REQUIRED NOT NULL,
    ER_UPDATED_AT         TIMESTAMP,
    ER_UPDATED_BY         VARCHAR2(50 CHAR),
    CONSTRAINT C_PK_ER_ID PRIMARY KEY (ER_ID),
    CONSTRAINT C_FK_ER_MSG_ID FOREIGN KEY (MSG_ID) REFERENCES IS_MESSAGE_MSG (MSG_ID)
) ${tablespace_data}; -- flyway placeholder

-- Create sequence (INCREMENT BY = allocationSize of the entity)
CREATE SEQUENCE IS_ER_S START WITH 1 INCREMENT BY 20 CACHE 20;

-- Index on foreign keys
CREATE INDEX I_ER_MSG_ID ON IS_EXTERNAL_REF_ER (MSG_ID) ${tablespace_index}; -- flyway placeholder

-- Comments
COMMENT ON TABLE IS_EXTERNAL_REF_ER IS 'References of a message in external applications';
COMMENT ON COLUMN IS_EXTERNAL_REF_ER.ER_ID IS 'Technical identifier of the external reference';
COMMENT ON COLUMN IS_EXTERNAL_REF_ER.ER_APPLICATION_SOURCE IS 'External application holding the reference';
COMMENT ON COLUMN IS_EXTERNAL_REF_ER.ER_EXTERNAL_REF IS 'Reference in the external application';
COMMENT ON COLUMN IS_EXTERNAL_REF_ER.MSG_ID IS 'Message (IS_MESSAGE_MSG)';
COMMENT ON COLUMN IS_EXTERNAL_REF_ER.ER_CREATED_AT IS 'Timestamp of the creation of the entry';
COMMENT ON COLUMN IS_EXTERNAL_REF_ER.ER_CREATED_BY IS 'User who created the entry';
COMMENT ON COLUMN IS_EXTERNAL_REF_ER.ER_UPDATED_AT IS 'Timestamp of the last change on the entry';
COMMENT ON COLUMN IS_EXTERNAL_REF_ER.ER_UPDATED_BY IS 'User who applied the last change on the entry';
