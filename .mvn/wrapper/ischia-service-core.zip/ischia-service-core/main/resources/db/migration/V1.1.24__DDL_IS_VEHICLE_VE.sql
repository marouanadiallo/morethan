-- Date : 11-27-2026
-- DDL of IS_VEHICLE_VE table (VehicleEntity)

-- Create table
CREATE TABLE IS_VEHICLE_VE (
    VE_ID                      NUMBER(19),
    VE_LICENCE_PLATE           VARCHAR2(50 CHAR),
    VE_HULL                    VARCHAR2(50 CHAR),
    VE_COUNTRY                 VARCHAR2(50 CHAR),
    VE_FIRST_REGISTRATION_DATE TIMESTAMP,
    VE_CATEGORY                VARCHAR2(50 CHAR),
    VE_COLOR                   VARCHAR2(50 CHAR),
    VE_BRAND                   VARCHAR2(50 CHAR),
    VE_MODEL                   VARCHAR2(50 CHAR),
    VE_REMARKS                 VARCHAR2(2000 CHAR),
    MSG_ID                     NUMBER(19) CONSTRAINT C_FK_VE_MSG_ID_REQUIRED NOT NULL,
    VE_CREATED_AT              TIMESTAMP CONSTRAINT C_VE_CREATED_AT_REQUIRED NOT NULL,
    VE_CREATED_BY              VARCHAR2(50 CHAR) CONSTRAINT C_VE_CREATED_BY_REQUIRED NOT NULL,
    VE_UPDATED_AT              TIMESTAMP,
    VE_UPDATED_BY              VARCHAR2(50 CHAR),
    CONSTRAINT C_PK_VE_ID PRIMARY KEY (VE_ID),
    CONSTRAINT C_FK_VE_MSG_ID FOREIGN KEY (MSG_ID) REFERENCES IS_MESSAGE_MSG (MSG_ID)
) ${tablespace_data}; -- flyway placeholder

-- Create sequence (INCREMENT BY = allocationSize of the entity)
CREATE SEQUENCE IS_VE_S START WITH 1 INCREMENT BY 20 CACHE 20;

-- Index on foreign keys
CREATE INDEX I_VE_MSG_ID ON IS_VEHICLE_VE (MSG_ID) ${tablespace_index}; -- flyway placeholder

-- Comments
COMMENT ON TABLE IS_VEHICLE_VE IS 'Vehicles mentioned in a message';
COMMENT ON COLUMN IS_VEHICLE_VE.VE_ID IS 'Technical identifier of the vehicle';
COMMENT ON COLUMN IS_VEHICLE_VE.VE_LICENCE_PLATE IS 'Licence plate of the vehicle';
COMMENT ON COLUMN IS_VEHICLE_VE.VE_HULL IS 'Hull (chassis) number of the vehicle';
COMMENT ON COLUMN IS_VEHICLE_VE.VE_COUNTRY IS 'Country of registration of the vehicle';
COMMENT ON COLUMN IS_VEHICLE_VE.VE_FIRST_REGISTRATION_DATE IS 'Date of first registration of the vehicle';
COMMENT ON COLUMN IS_VEHICLE_VE.VE_CATEGORY IS 'Category of the vehicle';
COMMENT ON COLUMN IS_VEHICLE_VE.VE_COLOR IS 'Color of the vehicle';
COMMENT ON COLUMN IS_VEHICLE_VE.VE_BRAND IS 'Brand of the vehicle';
COMMENT ON COLUMN IS_VEHICLE_VE.VE_MODEL IS 'Model of the vehicle';
COMMENT ON COLUMN IS_VEHICLE_VE.VE_REMARKS IS 'Free remarks about the vehicle';
COMMENT ON COLUMN IS_VEHICLE_VE.MSG_ID IS 'Message (IS_MESSAGE_MSG)';
COMMENT ON COLUMN IS_VEHICLE_VE.VE_CREATED_AT IS 'Timestamp of the creation of the entry';
COMMENT ON COLUMN IS_VEHICLE_VE.VE_CREATED_BY IS 'User who created the entry';
COMMENT ON COLUMN IS_VEHICLE_VE.VE_UPDATED_AT IS 'Timestamp of the last change on the entry';
COMMENT ON COLUMN IS_VEHICLE_VE.VE_UPDATED_BY IS 'User who applied the last change on the entry';
