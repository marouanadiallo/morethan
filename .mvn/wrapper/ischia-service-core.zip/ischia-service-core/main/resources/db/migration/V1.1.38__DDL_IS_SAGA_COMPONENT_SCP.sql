-- Date : 11-27-2026
-- DDL of IS_SAGA_COMPONENT_SCP table (SagaComponentEntity)

-- Create table
CREATE TABLE IS_SAGA_COMPONENT_SCP (
    SCP_ID                 NUMBER(19),
    SCP_COMPONENT_ID       NUMBER(19),
    SCP_COMPONENT_SELECTED NUMBER(1) DEFAULT 0 CONSTRAINT C_SCP_COMPONENT_SELECTED_REQUIRED NOT NULL,
    SGF_ID                 NUMBER(19) CONSTRAINT C_FK_SCP_SGF_ID_REQUIRED NOT NULL,
    SCP_CREATED_AT         TIMESTAMP CONSTRAINT C_SCP_CREATED_AT_REQUIRED NOT NULL,
    SCP_CREATED_BY         VARCHAR2(50 CHAR) CONSTRAINT C_SCP_CREATED_BY_REQUIRED NOT NULL,
    SCP_UPDATED_AT         TIMESTAMP,
    SCP_UPDATED_BY         VARCHAR2(50 CHAR),
    CONSTRAINT C_PK_SCP_ID PRIMARY KEY (SCP_ID),
    -- The same SAGA component appears only once in a folder.
    -- Its index starts with SGF_ID, so it also serves the foreign key below: no separate I_SCP_SGF_ID index.
    CONSTRAINT C_U_SCP_SGF_ID_COMPONENT_ID UNIQUE (SGF_ID, SCP_COMPONENT_ID),
    CONSTRAINT C_FK_SCP_SGF_ID FOREIGN KEY (SGF_ID) REFERENCES IS_SAGA_FOLDER_SGF (SGF_ID)
) ${tablespace_data}; -- flyway placeholder

-- Create sequence (INCREMENT BY = allocationSize of the entity)
CREATE SEQUENCE IS_SCP_S START WITH 1 INCREMENT BY 20 CACHE 20;

-- Comments
COMMENT ON TABLE IS_SAGA_COMPONENT_SCP IS 'SAGA components of a SAGA folder (a folder can have several components)';
COMMENT ON COLUMN IS_SAGA_COMPONENT_SCP.SCP_ID IS 'Technical identifier of the entry';
COMMENT ON COLUMN IS_SAGA_COMPONENT_SCP.SCP_COMPONENT_ID IS 'Identifier of the component in SAGA';
COMMENT ON COLUMN IS_SAGA_COMPONENT_SCP.SCP_COMPONENT_SELECTED IS 'Flag indicating whether the component is selected (1) or not (0)';
COMMENT ON COLUMN IS_SAGA_COMPONENT_SCP.SGF_ID IS 'SAGA folder owning the component (IS_SAGA_FOLDER_SGF)';
COMMENT ON COLUMN IS_SAGA_COMPONENT_SCP.SCP_CREATED_AT IS 'Timestamp of the creation of the entry';
COMMENT ON COLUMN IS_SAGA_COMPONENT_SCP.SCP_CREATED_BY IS 'User who created the entry';
COMMENT ON COLUMN IS_SAGA_COMPONENT_SCP.SCP_UPDATED_AT IS 'Timestamp of the last change on the entry';
COMMENT ON COLUMN IS_SAGA_COMPONENT_SCP.SCP_UPDATED_BY IS 'User who applied the last change on the entry';
