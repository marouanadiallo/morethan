-- Date : 11-27-2026
-- DDL of IS_REF_CRIME_AREA_RCA table (CrimeAreaEntity)

-- Create table
CREATE TABLE IS_REF_CRIME_AREA_RCA (
    RCA_ID            NUMBER(19),
    RCA_CODE          VARCHAR2(100 CHAR) CONSTRAINT C_RCA_CODE_REQUIRED NOT NULL,
    RCA_LABEL_DE      VARCHAR2(100 CHAR),
    RCA_LABEL_EN      VARCHAR2(100 CHAR),
    RCA_LABEL_FR      VARCHAR2(100 CHAR),
    RCA_VALIDITY_FROM DATE,
    RCA_VALIDITY_TO   DATE,
    RCH_ID            NUMBER(19) CONSTRAINT C_FK_RCA_RCH_ID_REQUIRED NOT NULL,
    RCA_CREATED_AT    TIMESTAMP CONSTRAINT C_RCA_CREATED_AT_REQUIRED NOT NULL,
    RCA_CREATED_BY    VARCHAR2(50 CHAR) CONSTRAINT C_RCA_CREATED_BY_REQUIRED NOT NULL,
    RCA_UPDATED_AT    TIMESTAMP,
    RCA_UPDATED_BY    VARCHAR2(50 CHAR),
    CONSTRAINT C_PK_RCA_ID PRIMARY KEY (RCA_ID),
    -- Code unique per channel (two channels may share a code, e.g. HIGH)
    CONSTRAINT C_U_RCA_RCH_ID_CODE UNIQUE (RCH_ID, RCA_CODE),
    -- Target of the composite foreign keys (RCA_ID, RCH_ID) of messages: a message only uses values of its own channel
    CONSTRAINT C_U_RCA_ID_RCH_ID UNIQUE (RCA_ID, RCH_ID),
    CONSTRAINT C_FK_RCA_RCH_ID FOREIGN KEY (RCH_ID) REFERENCES IS_REF_CHANNEL_RCH (RCH_ID)
) ${tablespace_data}; -- flyway placeholder

-- Create sequence (INCREMENT BY = allocationSize of the entity)
CREATE SEQUENCE IS_RCA_S START WITH 1 INCREMENT BY 20 CACHE 20;

-- Comments
COMMENT ON TABLE IS_REF_CRIME_AREA_RCA IS 'Reference table of crime areas, per channel';
COMMENT ON COLUMN IS_REF_CRIME_AREA_RCA.RCA_ID IS 'Technical identifier of the entry';
COMMENT ON COLUMN IS_REF_CRIME_AREA_RCA.RCA_CODE IS 'Code identifying the entry, unique per channel';
COMMENT ON COLUMN IS_REF_CRIME_AREA_RCA.RCA_LABEL_DE IS 'Label of the entry in German';
COMMENT ON COLUMN IS_REF_CRIME_AREA_RCA.RCA_LABEL_EN IS 'Label of the entry in English';
COMMENT ON COLUMN IS_REF_CRIME_AREA_RCA.RCA_LABEL_FR IS 'Label of the entry in French';
COMMENT ON COLUMN IS_REF_CRIME_AREA_RCA.RCA_VALIDITY_FROM IS 'Date from which the entry is valid (null = no lower bound)';
COMMENT ON COLUMN IS_REF_CRIME_AREA_RCA.RCA_VALIDITY_TO IS 'Date until which the entry is valid (null = no upper bound)';
COMMENT ON COLUMN IS_REF_CRIME_AREA_RCA.RCH_ID IS 'Channel to which the entry applies (IS_REF_CHANNEL_RCH)';
COMMENT ON COLUMN IS_REF_CRIME_AREA_RCA.RCA_CREATED_AT IS 'Timestamp of the creation of the entry';
COMMENT ON COLUMN IS_REF_CRIME_AREA_RCA.RCA_CREATED_BY IS 'User who created the entry';
COMMENT ON COLUMN IS_REF_CRIME_AREA_RCA.RCA_UPDATED_AT IS 'Timestamp of the last change on the entry';
COMMENT ON COLUMN IS_REF_CRIME_AREA_RCA.RCA_UPDATED_BY IS 'User who applied the last change on the entry';
