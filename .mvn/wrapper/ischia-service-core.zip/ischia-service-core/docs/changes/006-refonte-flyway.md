# 006 — Refonte complète des migrations Flyway

- **Date** : 2026-11-27
- **Statut** : à vérifier. Les scripts ont été **exécutés sur H2 2.3.232 en mode Oracle** : 46 tables, 46 séquences, et `referential-data.sql` (données de `ReferentialIT`) s'insère sans erreur. Ils n'ont **pas** été exécutés sur Oracle, et le contexte Spring (`ddl-auto: validate`) n'a pas été démarré.
- **Périmètre** : `main/resources/db/migration` (46 fichiers), `main/resources/db/oracle/R__01_GRANTS.sql`, quelques renommages dans `entity/`
- **Hypothèse** : base vide (clean). Aucun `ALTER` : chaque table est créée une seule fois, dans sa forme finale.
- **Sauvegarde des anciens scripts** : `backup/flyway-avant-refonte-2026-11-27/` (à supprimer quand tout est validé)

---

## 1. Pourquoi tout refaire

Les anciens scripts **ne passaient pas sur une base vide** :

| Problème | Effet |
|---|---|
| `V1.1.6` (MESSAGE) référence `IS_CASE_SC` (inexistante : la table s'appelle `IS_CASE_CS`) et `IS_REF_CHANNEL_RCH`, créées seulement en `V1.1.35` / `V1.1.38` | ORA-00942 dès la V1.1.6 |
| `C_FK_MSG_RMT_ID_REQUIRED` déclarée deux fois dans `IS_MESSAGE_MSG` | ORA-02264 |
| `IS_CASE_CS.RCAT_ID` en `VARCHAR2(100)` avec une FK vers un `NUMBER` | ORA-02267 |
| 9 tables mappées par des entités absentes : PPA, PPM, SGF, SCP, LEGD, CEG, IDC, MMAUN, MMAUS | `validate` échoue au démarrage |
| Colonnes manquantes : `RCH_ID` sur RMR/RMP/RMC/RMHC/RCA, `ZNE_ID` sur RCTY, `MAD_ID` sur MSG, `RCTY_ID`/`RO_ID` sur MAD | `validate` échoue |
| Colonnes mal nommées : `CS_CAS_NUMBER`, `MSG_REFENCE_ID`, `MSG_VERSION` / `MSG_VERSION_OPTLOCK` | `validate` échoue |
| `IS_PHYSICAL_PERSON_PP` contenait des colonnes (nom, naissance…) que l'entité n'a plus, dont `PP_CECIMA_IDENTITY_ID NOT NULL` | Chaque INSERT échoue |
| `IS_MESSAGE_RECIPIENT_MR` avait `RO_ID` / `RCTY_ID NOT NULL` que l'entité n'a plus (déplacés sur MAD) | Chaque INSERT échoue |

## 2. Conventions appliquées partout

- **Ordre des versions = ordre des dépendances** : une table n'est créée qu'après toutes celles qu'elle référence.
- Clé primaire `XX_ID NUMBER(19)`, contrainte `C_PK_XX_ID`.
- Clés étrangères `NUMBER(19)` (avant : un mélange de `NUMBER` et `NUMBER(19)`), contrainte `C_FK_<préfixe>_<colonne>`, **un index par FK** `I_<préfixe>_<colonne>`.
- NOT NULL nommés : `C_XX_COL_REQUIRED`, ou `C_FK_XX_COL_REQUIRED` pour une FK.
- `VARCHAR2(n CHAR)` partout : les colonnes en `BYTE` (`MSG_SUBJECT`, `VE_*`, `LD_REMARKS`, `ER_*`) débordaient avant `n` caractères dès qu'il y avait des accents ou des umlauts.
- Colonnes d'audit identiques partout : `XX_CREATED_AT TIMESTAMP NOT NULL`, `XX_CREATED_BY VARCHAR2(50 CHAR) NOT NULL`, `XX_UPDATED_AT`, `XX_UPDATED_BY`.
- Séquences `IS_XX_S START WITH 1 INCREMENT BY 20 CACHE 20` (= `allocationSize`, nécessaire avec `pooled-lo`, voir fiche 001).
- Booléens primitifs Java (`boolean`) : `NUMBER(1) DEFAULT x NOT NULL`, avec la même valeur par défaut que le code Java (`MA_DELETED`, `MC_DELETED`, `PPA_IS_KNOWN_IN_CECIMA`, `SCP_COMPONENT_SELECTED` → 0 ; `JA_IS_VALID` → 1).
- Enums (`EnumType.STRING`) : `VARCHAR2(20 CHAR)`.
- `COMMENT ON TABLE / COLUMN` sur toutes les tables (avant : seulement sur 5 tables).

## 3. Nouvelle numérotation

| Version | Table | Statut |
|---|---|---|
| V1.1.1 → V1.1.11 | RCH, RCAT, ZNE, RMT, RMS, RMD, RNT, RDC, RO, RUO, RCSTE | référentiels sans dépendance |
| V1.1.12 → V1.1.16 | RMR, RMP, RMC, RMHC, RCA | référentiels par canal : **+ `RCH_ID NOT NULL`** |
| V1.1.17 | RCTY | **+ `ZNE_ID NOT NULL`** |
| V1.1.18 | RUUT | |
| V1.1.19 | US | |
| V1.1.20 | MAD | **+ `RCTY_ID`, `RO_ID` NOT NULL** (déplacés depuis MR) |
| V1.1.21 | CS | `CS_CASE_NUMBER` + unique, `RCAT_ID NUMBER(19)` |
| V1.1.22 | MSG | **+ `MAD_ID NOT NULL`** (expéditeur), `MSG_REFERENCE_ID`, `MSG_PARENT_REFERENCE_ID`, `MSG_VERSION_OPTLOCK NOT NULL DEFAULT 0` |
| V1.1.23 | MR | **− `RO_ID`, `RCTY_ID`** |
| V1.1.24 → V1.1.26 | VE, LD, PP | PP réduit à `PP_ID` + `MSG_ID` + audit (les détails sont dans PPA) |
| V1.1.27 | PPA | **nouvelle** |
| V1.1.28 → V1.1.34 | MMHC, MMCA, MA, ER, MD, MC, JA | |
| V1.1.35 | MMAUN | **nouvelle** |
| V1.1.36 | MMAUS | **nouvelle** |
| V1.1.37 → V1.1.42 | SGF, SCP, LEGD, CEG, IDC, PPM | **nouvelles** — SCP rattaché à SGF (`SGF_ID NOT NULL`) |
| V1.1.43 → V1.1.46 | DL, CL, AE, AOG | voir §4 |

## 4. Corrections table par table (hors ajouts de colonnes ci-dessus)

| Table | Changement |
|---|---|
| RCSTE | `NUMBER(18)` → `NUMBER(19)` ; `RCSTE_CODE NOT NULL` + unique `C_U_RCSTE_CODE` (déclarée dans l'entité) ; libellés `150` → `100` (comme l'entité) ; audit NOT NULL |
| DL, CL | NOT NULL sur `TRACE_ID`, `URL`, `TIME`, `USER_ID` (comme l'entité ; le code ne met jamais `null` : `auditTraceId()` / `unknownUser()`). Ajout de l'index `I_CL_RCSTE_ID` |
| AE | NOT NULL sur `TRACE_ID`, `USER_ID`, `ACTION`, `URL`, `START_DATE` (comme l'entité) |
| AOG | Tailles alignées sur **ce que le code écrit vraiment** (`HttpAuditRecorder`) : `ACTION` = méthode HTTP → `10` (avant 100), `STATUS` = code HTTP → `3` (avant 50), `URL` → `2000` (avant 300 : chaque URL plus longue faisait échouer l'INSERT). Commentaires corrigés (ils décrivaient `CECIMA_CREATE_IDENTITY` / `SUCCESS`, ce n'est pas ce qui est stocké) |
| ER | Contrainte `..._RIQUIRED` → `..._REQUIRED` ; `VARCHAR2(100)` → `VARCHAR2(100 CHAR)` |
| MAD | `MAD_EMAIL` 100 → 255 (longueur JPA par défaut ; un email peut aller jusqu'à 254) |
| LD, PPA | `LD_REMARKS`, `PPA_NOTICE` en `2000 CHAR` (l'entité ne précise pas de longueur) |

## 5. Entités (`entity/`) : renommages effectués

Ces renommages n'ont aucun effet sur le comportement : les noms de contraintes ne servent qu'à la génération DDL, et la casse d'une colonne non quotée est ignorée par Oracle. Je les ai faits pour que le code et la base disent la même chose.

| Fichier | Avant | Après |
|---|---|---|
| `MessageEntity` | colonne `MSG_PARENT_REFENCE_ID` | `MSG_PARENT_REFERENCE_ID` ← **seul renommage qui change le mapping** |
| `MessageEntity` | `C_U_MSG_REFENCE_ID` | `C_U_MSG_REFERENCE_ID` |
| `MailAddressEntity` | `C_FK_MR_RCTY_ID`, `C_FK_MR_RO_ID` | `C_FK_MAD_RCTY_ID`, `C_FK_MAD_RO_ID` |
| `DocumentCategoryEntity`, `MessageConfidentialityEntity`, `NationalityEntity`, `ZoneEntity` | `C_U_xxx_ID` (sur la colonne CODE) | `C_U_xxx_CODE` |
| `PhysicalPersonAliasEntity` | `PPA_DATE_OF_Birth` | `PPA_DATE_OF_BIRTH` |

**Corrections faites ensuite (même jour)** :

| Fichier | Changement |
|---|---|
| `CountryEntity` | `equals/hashCode` proxy-safe (`PersistenceUtils.effectiveClass`, getters) et null-safe (régression corrigée) |
| `MessageEntity` | `equals` null-safe : un message sans référence n'est égal qu'à lui-même |
| `LegalDocumentEntity` + V1.1.25 | `LD_DOCUMENT_NUMBER` : `Long`/`NUMBER(19)` → `String`/`VARCHAR2(50 CHAR)`, contrainte `C_U_LD_DOCUMENT_NUMBER` supprimée (numéros alphanumériques ; un même document peut être cité dans plusieurs messages). `of(String documentNumber, ...)`. Index `I_LD_DOCUMENT_NUMBER` (recherche par numéro de document) |
| `MessageEntity` + V1.1.22 | Sender obligatoire : `@ManyToOne(optional = false)` + `MAD_ID NOT NULL` (`C_FK_MSG_MAD_ID_REQUIRED`) |
| `SagaComponentEntity` | `@ManyToOne(optional = false) sagaFolder` → colonne `SGF_ID` (un dossier a plusieurs composants). Constructeur : `SagaComponentEntity(SagaFolderEntity, Long, boolean)`. Flyway V1.1.38 : `SGF_ID NOT NULL` + FK `C_FK_SCP_SGF_ID` |
| `SagaComponentEntity` + V1.1.38 | Unique `C_U_SCP_SGF_ID_COMPONENT_ID (SGF_ID, SCP_COMPONENT_ID)` : un composant n'apparaît qu'une fois par dossier (le même composant reste possible dans deux dossiers). Son index commence par `SGF_ID` et sert donc aussi à la FK : pas d'index `I_SCP_SGF_ID` séparé |
| `PhysicalPersonAliasEntity` + V1.1.27 | **Q4** : `dateOfBirth` (`LocalDate`) → `birthDay` / `birthMonth` / `birthYear` (`Integer`, colonnes `PPA_BIRTH_DAY NUMBER(2)`, `PPA_BIRTH_MONTH NUMBER(2)`, `PPA_BIRTH_YEAR NUMBER(4)`), chacun facultatif pour garder une date partielle ; contrôles `C_PPA_BIRTH_DAY_RANGE` (1-31), `C_PPA_BIRTH_MONTH_RANGE` (1-12), `C_PPA_BIRTH_YEAR_RANGE` (1900-2999). `birthPlace` : FK pays `RCTY_BIRTH_PLACE_ID` → texte libre `PPA_BIRTH_PLACE VARCHAR2(255 CHAR)` (le pays reste dans `birthCountry`) |
| `ZoneEntity`, `MessageAssignedUnitEntity`, `MessageAssignedUserEntity` + V1.1.3, V1.1.17, V1.1.35, V1.1.36, grants, `referential-data.sql` | **Q5** : `IS_ZONE_ZNE` → `IS_REF_ZONE_ZNE` ; `IS_MESSAGE_ASSIGNED_UNIT_MMAUN` → `IS_MAP_MESSAGE_ASSIGNED_UNIT_MMAUN` ; `IS_MAP_MESSAGE_ASSIGNMENT_MMAUS` → `IS_MAP_MESSAGE_ASSIGNED_USER_MMAUS` (fichiers de migration renommés aussi) |
| `AppUserEntity`, `MailAddressEntity`, `CecimaIdentityGroupEntity` | `equals/hashCode` proxy-safe et null-safe. `AppUserEntity` : clé métier = `login` seul (unique, NOT NULL) ; l'email (facultatif, modifiable) n'en fait plus partie |
| `LegalDocumentEntity`, `MessageCommentEntity`, `UserUnitEntity` | `optional = false` sur les associations NOT NULL en base (`LD.message/nationality/documentCategory`, `MC.message/appUser`, `RUUT.organization`) |
| `AuditOutgoingEntity`, `HttpAuditRecorder` | `correlationId` : `length = 64` ; troncature avec `TRACE_ID_MAX_SIZE` au lieu de 255 |
| 5 référentiels par canal (RMR, RMP, RMC, RMHC, RCA) : entités + V1.1.12 → V1.1.16 | **Q2** : code unique **par canal** `C_U_xxx_RCH_ID_CODE (RCH_ID, CODE)` (remplace `C_U_xxx_CODE`). + `C_U_xxx_ID_RCH_ID (xxx_ID, RCH_ID)`, cible des FK composites. Index `I_xxx_RCH_ID` supprimé (couvert par la contrainte qui commence par `RCH_ID`) |
| `MessageEntity` + V1.1.22 | **Cohérence canal** : FK composites `C_FK_MSG_RMP_ID_RCH_ID`, `C_FK_MSG_RMR_ID_RCH_ID`, `C_FK_MSG_RMC_ID_RCH_ID` : `(RMx_ID, RCH_ID)` → référentiel `(RMx_ID, RCH_ID)`. Une priorité / fiabilité / confidentialité d'un autre canal que celui du message est rejetée par la base. + `C_U_MSG_ID_RCH_ID (MSG_ID, RCH_ID)` (cible des tables de liaison). Index FK recréés sur `(RMx_ID, RCH_ID)` |
| `MessageHandlingCodeMapEntity`, `MessageCrimeAreaMapEntity` + V1.1.28, V1.1.29 | **Cohérence canal** : nouvelle colonne `RCH_ID NOT NULL` (copie du canal du message, faite par `of(...)`) + 2 FK composites chacune : `(MSG_ID, RCH_ID)` → message, `(RMHC_ID / RCA_ID, RCH_ID)` → référentiel. Plus de setters : `of(...)` est le seul moyen de construire un lien |
| `ChannelReferenceBaseRepository`, `AbstractChannelReferentialService`, `AbstractChannelReferentialController`, `messages*.properties` | `findByChannelIdAndCodeIgnoreCase` ; `getByCode(channelId, code)` ; **`GET /{type}/code/{code}?channelId=` : `channelId` obligatoire** (400 sinon) ; nouveau message `referential.notfound.byChannelAndCode` (en / fr / de) |
| Tests | `AbstractChannelReferentialServiceTests`, `MessageReliabilityControllerTests` (400 sans canal / canal invalide, 404), `ReferentialIT` (lookup par code avec canal ; 400 sans canal ; même code `IT_SHARED` sur 2 canaux → valeur du canal demandé ; code d'un autre canal → 404) ; `referential-data.sql` : lignes `IT_SHARED` (ids 9005 / 9006) |

Contrôle automatique fait après les renommages : les 46 entités correspondent exactement aux 46 tables (chaque colonne mappée existe, aucune colonne en base n'est hors mapping, chaque séquence existe, chaque FK pointe vers une table créée avant elle, aucun nom de contrainte ou d'index en double).

## 6. Revue des entités : à corriger dans le code (non fait)

- [x] ~~🐞 **`CountryEntity.equals/hashCode` : régression.**~~ Corrigé. Le fichier de `entity/` est revenu à l'ancienne version (`getClass()`, `alphacode2.equals(...)`). On retrouve donc une NPE si un code est null et une comparaison fausse avec un proxy Hibernate. La version corrigée existe dans `ischia-domain` (fiche 003) : la reprendre, avec `PersistenceUtils.effectiveClass` comme dans `AbstractReferenceEntity`.
- [x] ~~🐞 `MessageEntity.equals` :~~ Corrigé. `getReferenceID().equals(...)` lève une NPE tant que la référence n'est pas renseignée (message en création, ajouté à un `Set`). Utiliser `getReferenceID() != null && getReferenceID().equals(...)`.
- [x] Corrigé — `AppUserEntity`, `MailAddressEntity`, `CecimaIdentityGroupEntity` : mêmes `equals` non null-safe et non proxy-safe (déjà listés en 003 A.3).
- [x] Sans objet (présent dans le projet du bureau) — `PersistenceUtils` est importé par `AbstractReferenceEntity` et `MessageEntity` mais n'est pas dans ce workspace : vérifier qu'il est bien commité.
- [x] Corrigé — `AuditOutgoingEntity.correlationId` n'a pas de longueur et `HttpAuditRecorder` le tronque à 255 (`DEFAULT_VARCHAR_MAX_SIZE`), alors que la colonne fait 64 comme les autres trace ids. Mettre `length = 64` et `TRACE_ID_MAX_SIZE`.
- [x] Corrigé — Nullabilité : la base est plus stricte que l'entité sur `LD.MSG_ID/RNT_ID/RDC_ID`, `MC.MSG_ID/US_ID` et `RUUT.RUO_ID` (NOT NULL en base, `@ManyToOne` sans `optional = false`). Ce n'est pas bloquant, mais il vaut mieux ajouter `optional = false` pour que l'erreur soit claire.

## 7. Questions ouvertes (décisions métier, à trancher avant de figer)

1. ~~**`LD_DOCUMENT_NUMBER`**~~ Tranché : `String`, sans contrainte unique.
2. ~~**Référentiels par canal**~~ Tranché : code unique par canal, et un message n'utilise que des valeurs de son canal (contrôlé par la base, voir §5).
3. ~~**`SagaComponentEntity`** n'est rattaché à rien.~~ Tranché : rattaché à `SagaFolderEntity` (1 dossier → N composants). Unicité `(SGF_ID, SCP_COMPONENT_ID)` ajoutée.
4. ~~**PPA**~~ Tranché : lieu de naissance en texte libre ; date de naissance en 3 parties facultatives (voir §5).
5. ~~**Nommage**~~ Tranché : `IS_REF_ZONE_ZNE`, `IS_MAP_MESSAGE_ASSIGNED_UNIT_MMAUN`, `IS_MAP_MESSAGE_ASSIGNED_USER_MMAUS`.

## Comment vérifier

- [x] `entity/` recopié dans `ischia-domain/.../persistence/entity` le 2026-11-27 (ancienne version sauvegardée dans `backup/ischia-domain-entity-avant-copie-2026-11-27/`). ⚠️ Les entités importent `lu.pgd.dri.ischia.domain.persistence.PersistenceUtils`, qui n'est pas dans ce workspace (il existe dans le projet du bureau).
- [ ] Copier `main/resources/db/*` dans le module `ischia-flyway`, supprimer les anciens `V*.sql` (ils sont sauvegardés).
- [ ] Oracle : `flyway clean` puis `flyway migrate`. Les 46 versions doivent passer et `R__01_GRANTS` doit s'appliquer.
- [ ] Démarrer l'application (`ddl-auto: validate`).
  - ⚠️ Point à surveiller : depuis Hibernate 6.2, un `Instant` est mappé par défaut en `TIMESTAMP_UTC` (`timestamp with time zone` sur Oracle), alors que nos colonnes sont en `TIMESTAMP`.
  - Si `validate` remonte *wrong column type … found [timestamp], but expecting [timestamp(6) with time zone]*, ajouter `spring.jpa.properties.hibernate.type.preferred_instant_jdbc_type: TIMESTAMP` dans `config-domain.yml`. C'est cohérent avec `jdbc.time_zone: UTC` déjà configuré.
- [ ] `mvn -pl ischia-service-core verify` (`ReferentialIT` rejoue Flyway sur H2).

## Reste à faire

- [ ] ⚠️ **Prévenir le front** : `GET /{type}/code/{code}` exige maintenant `?channelId=` pour les 5 référentiels par canal (`crime-area-types`, `message-confidentiality-types`, `message-handling-code-types`, `message-priority-types`, `message-reliability-types`).
- [ ] Service des messages (à écrire) : vérifier que priorité / fiabilité / confidentialité / handling codes / crime areas appartiennent au canal du message **avant** l'enregistrement, pour répondre un 400 clair. Sinon la base rejette à l'enregistrement (`DataIntegrityViolationException`, nom de contrainte `C_FK_*_RCH_ID`).
- [ ] Ne jamais appeler `findByCodeIgnoreCase` (hérité) sur un repository de référentiel par canal : il échoue dès qu'un code existe dans deux canaux.
- [ ] Données de référence (INSERT des valeurs de référentiels) : aucun script pour l'instant.
- [ ] Le placeholder `${tablespace_lob}` est configuré mais pas utilisé : à définir si les CLOB (`MSG_BODY`, `MC_CONTENT`, bodies d'audit) doivent aller dans un tablespace dédié.
- [ ] Supprimer `backup/flyway-avant-refonte-2026-11-27/` et `backup/ischia-domain-entity-avant-copie-2026-11-27/` une fois validé.
