package lu.pgd.dri.ischia.domain.persistence.repository.reference;

import lu.pgd.dri.ischia.domain.persistence.entity.reference.AbstractReferenceEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

/**
 * Reference types that belong to a channel (column RCH_ID, attribute {@code channel}).
 * <br>
 * Every entity of a repository extending this interface MUST have a {@code channel} attribute,
 * otherwise the queries below fail at startup.
 * <br>
 * ⚠️ The code is unique <b>per channel</b> (constraint C_U_xxx_RCH_ID_CODE): two channels may share a code.
 * Do NOT use the inherited {@link #findByCodeIgnoreCase(String)} on these repositories: it fails with
 * {@code IncorrectResultSizeDataAccessException} as soon as a code exists in two channels.
 * Use {@link #findByChannelIdAndCodeIgnoreCase(Long, String)}.
 */
@NoRepositoryBean
public interface ChannelReferenceBaseRepository<E extends AbstractReferenceEntity> extends ReferenceBaseRepository<E> {

    /**
     * Lookup by business key (channel + code), case-insensitive on the code. Ignores the validity:
     * an old message must still be able to display an expired value.
     */
    @Query("""
            SELECT e
            FROM #{#entityName} e
            WHERE e.channel.id = :channelId
            AND UPPER(e.code) = UPPER(:code)
            """)
    Optional<E> findByChannelIdAndCodeIgnoreCase(@Param("channelId") Long channelId, @Param("code") String code);

    @Query("""
            SELECT e
            FROM #{#entityName} e
            WHERE e.channel.id = :channelId
            AND (e.validityFrom IS NULL OR e.validityFrom <= :#{datez.today()})
            AND (e.validityTo IS NULL OR e.validityTo >= :#{datez.today()})
            """)
    List<E> findValidateReferencesByChannelId(@Param("channelId") Long channelId);
}
