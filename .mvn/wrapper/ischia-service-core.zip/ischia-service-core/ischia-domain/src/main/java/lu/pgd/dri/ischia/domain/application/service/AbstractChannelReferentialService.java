package lu.pgd.dri.ischia.domain.application.service;

import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.AbstractReferenceEntity;
import lu.pgd.dri.ischia.domain.persistence.repository.reference.ChannelReferenceBaseRepository;
import lu.pgd.dri.ischia.domainapi.response.ChannelReferentialResponse;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;
import java.util.function.Function;

/**
 * Same contract as {@link AbstractReferentialService}, for reference types that belong to a channel:
 * the response carries the {@code channelId}, and the list can be filtered by channel.
 * <br>
 * Subclasses pass the matching MapStruct method, e.g. {@code referentialMapper::toChannelReferentialResponse}
 * (the overload is chosen from the entity type).
 */
@Transactional(readOnly = true)
public abstract class AbstractChannelReferentialService<E extends AbstractReferenceEntity> {

    private final ChannelReferenceBaseRepository<E> repository;
    private final Function<E, ChannelReferentialResponse> mapper;

    // Concrete class name in the logs (see AbstractReferentialService)
    private final Logger log = LoggerFactory.getLogger(getClass());

    protected AbstractChannelReferentialService(ChannelReferenceBaseRepository<E> repository,
                                                Function<E, ChannelReferentialResponse> mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    /**
     * @param channelId optional; when null, the valid references of every channel are returned
     */
    public List<ChannelReferentialResponse> getAll(@Nullable Long channelId) {
        log.info("Referential - getAll (channelId={})", channelId);
        List<E> references = Objects.isNull(channelId)
                ? repository.findValidateReferences()
                : repository.findValidateReferencesByChannelId(channelId);
        return references.stream().map(mapper).toList();
    }

    public ChannelReferentialResponse getById(@NonNull Long id) {
        log.info("Referential - getById {}", id);
        return repository.findById(id)
                .map(mapper)
                .orElseThrow(() -> new ResourceNotFoundException("referential.notfound.byId", id));
    }

    /**
     * The code is unique per channel only (two channels may share a code): the channel is mandatory.
     */
    public ChannelReferentialResponse getByCode(@NonNull Long channelId, @NonNull String code) {
        log.info("Referential - getByCode {} (channelId={})", code, channelId);
        return repository.findByChannelIdAndCodeIgnoreCase(channelId, code)
                .map(mapper)
                .orElseThrow(() -> new ResourceNotFoundException("referential.notfound.byChannelAndCode", code, channelId));
    }
}
