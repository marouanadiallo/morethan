package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.persistence.PersistenceUtils;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.CountryEntity;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.OrganizationEntity;
import org.hibernate.annotations.Comment;

import java.util.Objects;

@Getter
@Entity
@Table(name = "IS_MAIL_ADDRESS_MAD")
@AttributeOverride(name = "updatedAt", column = @Column(name = "MAD_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "MAD_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "MAD_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "MAD_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class MailAddressEntity extends Auditable {

    @Id
    @Column(name = "MAD_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_address_gen"
    )
    @SequenceGenerator(
            name = "seq_message_address_gen",
            sequenceName = "IS_MAD_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @Column(name = "MAD_EMAIL")
    @Comment("")
    private String email;

    @Setter
    @Column(name = "MAD_IS_ACTIVE")
    @Comment("")
    private Boolean isActive;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RCTY_ID", foreignKey = @ForeignKey(name = "C_FK_MAD_RCTY_ID"))
    @Comment("")
    private CountryEntity country;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RO_ID", foreignKey = @ForeignKey(name = "C_FK_MAD_RO_ID"))
    @Comment("")
    private OrganizationEntity organization;

    protected MailAddressEntity() {
        this.id = null;
    }

    public static MailAddressEntity of(String email, Boolean active) {
        MailAddressEntity entity = new MailAddressEntity();
        entity.setEmail(email);
        entity.setIsActive(active);
        return entity;
    }

    /**
     * Business key = email. Proxy-safe (getters, real class) and null-safe
     * (an address without email is only equal to itself).
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || PersistenceUtils.effectiveClass(this) != PersistenceUtils.effectiveClass(o)) {
            return false;
        }

        MailAddressEntity that = (MailAddressEntity) o;
        return getEmail() != null && getEmail().equals(that.getEmail());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getEmail());
    }
}
