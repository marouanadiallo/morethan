package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.ChannelEntity;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.MessageHandlingCodeEntity;
import org.hibernate.annotations.Comment;

/**
 * Link between a message and one of its handling codes.
 * <br>
 * The handling code MUST belong to the channel of the message. The table stores the channel of the message (RCH_ID)
 * and the database checks it with 2 composite foreign keys: (MSG_ID, RCH_ID) -> message and
 * (RMHC_ID, RCH_ID) -> handling code. A handling code of another channel is rejected at flush.
 * <br>
 * No setters: the only way to build a link is {@link #of}, which copies the channel of the message.
 */
@Getter
@Entity
@Table(name = "IS_MAP_MESSAGE_HANDLING_CODE_MMHC")
@AttributeOverride(name = "updatedAt", column = @Column(name = "MMHC_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "MMHC_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "MMHC_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "MMHC_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class MessageHandlingCodeMapEntity extends Auditable {

    @Id
    @Column(name = "MMHC_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_handling_code_map_gen"
    )
    @SequenceGenerator(
            name = "seq_message_handling_code_map_gen",
            sequenceName = "IS_MMHC_S",
            allocationSize = 20
    )
    private final Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_MMHC_MSG_ID_RCH_ID"))
    @Comment("")
    private MessageEntity message;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RMHC_ID", foreignKey = @ForeignKey(name = "C_FK_MMHC_RMHC_ID_RCH_ID"))
    @Comment("")
    private MessageHandlingCodeEntity messageHandlingCode;

    /**
     * Copy of the channel of the message. No direct foreign key to the channel table:
     * the composite foreign keys above already guarantee it (see class javadoc).
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RCH_ID", foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
    @Comment("Channel of the message")
    private ChannelEntity channel;

    protected MessageHandlingCodeMapEntity() {
        this.id = null;
    }

    public static MessageHandlingCodeMapEntity of(MessageEntity message, MessageHandlingCodeEntity messageHandlingCode) {
        MessageHandlingCodeMapEntity entity = new MessageHandlingCodeMapEntity();
        entity.message = message;
        entity.messageHandlingCode = messageHandlingCode;
        entity.channel = message.getChannel();
        return entity;
    }
}
