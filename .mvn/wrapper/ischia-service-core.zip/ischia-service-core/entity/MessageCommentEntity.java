package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_MESSAGE_COMMENTS_MC")
@AttributeOverride(name = "updatedAt", column = @Column(name = "MC_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "MC_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "MC_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "MC_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class MessageCommentEntity extends Auditable {

    @Id
    @Column(name = "MC_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_comment_gen"
    )
    @SequenceGenerator(
            name = "seq_message_comment_gen",
            sequenceName = "IS_MC_S",
            allocationSize = 20
    )
    private final Long id;

    @Lob
    @Basic(fetch = FetchType.LAZY)
    @Setter
    @Column(name = "MC_CONTENT", columnDefinition = "CLOB")
    @Comment("")
    private String content;

    @Setter
    @Column(name = "MC_DELETED")
    @Comment("")
    private boolean deleted;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_MC_MSG_ID"))
    @Comment("")
    private MessageEntity message;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "US_ID", foreignKey = @ForeignKey(name = "C_FK_MC_US_ID"))
    @Comment("")
    private AppUserEntity appUser;

    protected MessageCommentEntity() {
        this.id = null;
    }

    public static MessageCommentEntity of(MessageEntity message, AppUserEntity appUser) {
        MessageCommentEntity entity = new MessageCommentEntity();
        entity.setMessage(message);
        entity.setAppUser(appUser);
        return entity;
    }
}
