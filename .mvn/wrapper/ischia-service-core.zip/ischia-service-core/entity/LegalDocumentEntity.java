package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.DocumentCategoryEntity;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.NationalityEntity;
import org.hibernate.annotations.Comment;

import java.time.Instant;

@Getter
@Entity
@Table(name = "IS_LEGAL_DOCUMENT_LD")
@AttributeOverride(name = "updatedAt", column = @Column(name = "LD_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "LD_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "LD_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "LD_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class LegalDocumentEntity extends Auditable {

    @Id
    @Column(name = "LD_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_legal_document_gen"
    )
    @SequenceGenerator(name = "seq_legal_document_gen",
            sequenceName = "IS_LD_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    /**
     * Alphanumeric (e.g. passport "AB1234567") and not unique: the same document can be cited in several messages.
     */
    @Column(name = "LD_DOCUMENT_NUMBER", length = 50)
    @Comment("Number of the document")
    private String documentNumber;

    @Setter
    @Column(name = "LD_FIRST_NAME")
    @Comment("")
    private String firstName;

    @Setter
    @Column(name = "LD_LAST_NAME")
    @Comment("")
    private String lastName;

    @Setter
    @Column(name = "LD_DELIVERY_DATE")
    @Comment("")
    private Instant deliveryDate;

    @Setter
    @Column(name = "LD_EXPIRATION_DATE")
    @Comment("")
    private Instant expirationDate;

    @Setter
    @Column(name = "LD_REMARKS")
    @Comment("")
    private String remarks;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_LD_MSG_ID"))
    @Comment("")
    private MessageEntity message;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RNT_ID", foreignKey = @ForeignKey(name = "C_FK_LD_RNT_ID"))
    @Comment("")
    private NationalityEntity nationality;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RDC_ID", foreignKey = @ForeignKey(name = "C_FK_LD_RDC_ID"))
    @Comment("")
    private DocumentCategoryEntity documentCategory;

    protected LegalDocumentEntity() {
        this.id = null;
    }

    public static LegalDocumentEntity of(String documentNumber, MessageEntity message, NationalityEntity nationality, DocumentCategoryEntity documentCategory) {
        LegalDocumentEntity entity = new LegalDocumentEntity();
        entity.setDocumentNumber(documentNumber);
        entity.setMessage(message);
        entity.setNationality(nationality);
        entity.setDocumentCategory(documentCategory);
        return entity;
    }
}
