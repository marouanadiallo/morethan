package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

import java.time.Instant;

@Getter
@Entity
@Table(name = "IS_AUDIT_OUTGOING_AOG")
@Comment("Audit of outgoing calls (HTTP, Feign)")
public class AuditOutgoingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_audit_outgoing_generator")
    @Column(name = "AOG_ID", updatable = false, nullable = false)
    @SequenceGenerator(name = "seq_audit_outgoing_generator",
            sequenceName = "IS_AOG_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @Column(name = "AOG_CORRELATION_ID", nullable = false, length = 64)
    private String correlationId;

    @Setter
    @Column(name = "AOG_ACTION", nullable = false, length = 10)
    private String action;

    @Setter
    @Column(name = "AOG_STATUS", nullable = false, length = 3)
    private String status;

    @Setter
    @Column(name = "AOG_URL", length = 2000)
    private String url;

    @Lob
    @Setter
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "AOG_REQUEST_BODY")
    private String requestBody;

    @Lob
    @Setter
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "AOG_RESPONSE_BODY")
    private String responseBody;

    @Setter
    @Column(name = "AOG_START_DATE", nullable = false)
    private Instant startDate;

    @Setter
    @Column(name = "AOG_END_DATE")
    private Instant endDate;

    protected AuditOutgoingEntity() {
        this.id = null;
    }

    public static AuditOutgoingEntity of(String correlationId, String action, String status, Instant startDate) {
        AuditOutgoingEntity entity = new AuditOutgoingEntity();
        entity.setCorrelationId(correlationId);
        entity.setAction(action);
        entity.setStatus(status);
        entity.setStartDate(startDate);
        return entity;
    }

}
