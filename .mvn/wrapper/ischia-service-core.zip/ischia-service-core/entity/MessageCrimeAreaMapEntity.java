package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.ChannelEntity;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.CrimeAreaEntity;
import org.hibernate.annotations.Comment;

/**
 * Link between a message and one of its crime areas.
 * <br>
 * The crime area MUST belong to the channel of the message. The table stores the channel of the message (RCH_ID)
 * and the database checks it with 2 composite foreign keys: (MSG_ID, RCH_ID) -> message and
 * (RCA_ID, RCH_ID) -> crime area. A crime area of another channel is rejected at flush.
 * <br>
 * No setters: the only way to build a link is {@link #of}, which copies the channel of the message.
 */
@Getter
@Entity
@Table(name = "IS_MAP_MESSAGE_CRIME_AREA_MMCA")
@AttributeOverride(name = "updatedAt", column = @Column(name = "MMCA_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "MMCA_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "MMCA_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "MMCA_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class MessageCrimeAreaMapEntity extends Auditable {

    @Id
    @Column(name = "MMCA_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_crime_area_gen"
    )
    @SequenceGenerator(
            name = "seq_message_crime_area_gen",
            sequenceName = "IS_MMCA_S",
            allocationSize = 20
    )
    private final Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_MMCA_MSG_ID_RCH_ID"))
    @Comment("")
    private MessageEntity message;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RCA_ID", foreignKey = @ForeignKey(name = "C_FK_MMCA_RCA_ID_RCH_ID"))
    @Comment("")
    private CrimeAreaEntity crimeArea;

    /**
     * Copy of the channel of the message. No direct foreign key to the channel table:
     * the composite foreign keys above already guarantee it (see class javadoc).
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RCH_ID", foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
    @Comment("Channel of the message")
    private ChannelEntity channel;

    protected MessageCrimeAreaMapEntity() {
        this.id = null;
    }

    public static MessageCrimeAreaMapEntity of(MessageEntity message, CrimeAreaEntity crimeArea) {
        MessageCrimeAreaMapEntity entity = new MessageCrimeAreaMapEntity();
        entity.message = message;
        entity.crimeArea = crimeArea;
        entity.channel = message.getChannel();
        return entity;
    }
}
