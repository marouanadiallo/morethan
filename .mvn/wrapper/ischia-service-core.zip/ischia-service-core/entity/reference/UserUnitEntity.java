package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_USER_UNIT_TYPE_RUUT", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_RUUT_CODE", columnNames = {"RUUT_CODE"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RUUT_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RUUT_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RUUT_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RUUT_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RUUT_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RUUT_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RUUT_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RUUT_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RUUT_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RUUT_VALIDITY_FROM", length = 6))
@Comment("Defines the user unit type.")
public class UserUnitEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RUUT_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the user unit.")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_user_unit_gen")
    @SequenceGenerator(name = "seq_user_unit_gen",
            sequenceName = "IS_RUUT_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RUO_ID", foreignKey = @ForeignKey(name = "C_FK_RUUT_RUO_ID"))
    private UnitOrganizationEntity organization;

    protected UserUnitEntity() {
        this.id = null;
    }

    public static UserUnitEntity of(String code) {
        UserUnitEntity entity = new UserUnitEntity();
        entity.setCode(code);
        return entity;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
