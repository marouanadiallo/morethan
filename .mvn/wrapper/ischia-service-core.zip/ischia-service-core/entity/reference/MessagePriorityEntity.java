package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_MESSAGE_PRIORITY_RMP", uniqueConstraints = {
        // Code unique per channel: two channels may share a code (e.g. HIGH)
        @UniqueConstraint(name = "C_U_RMP_RCH_ID_CODE", columnNames = {"RCH_ID", "RMP_CODE"}),
        // Target of the composite foreign keys (RMP_ID, RCH_ID): a message only uses values of its own channel
        @UniqueConstraint(name = "C_U_RMP_ID_RCH_ID", columnNames = {"RMP_ID", "RCH_ID"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RMP_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RMP_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RMP_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RMP_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RMP_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RMP_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RMP_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RMP_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RMP_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RMP_VALIDITY_FROM", length = 6))
@Comment("Defines the message priority type.")
public class MessagePriorityEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RMP_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the message priority type.")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_priority_gen"
    )
    @SequenceGenerator(name = "seq_message_priority_gen",
            sequenceName = "IS_RMP_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RCH_ID", foreignKey = @ForeignKey(name = "C_FK_RMP_RCH_ID"))
    private ChannelEntity channel;

    protected MessagePriorityEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
