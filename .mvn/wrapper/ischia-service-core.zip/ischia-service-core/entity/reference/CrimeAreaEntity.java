package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_CRIME_AREA_RCA", uniqueConstraints = {
        // Code unique per channel: two channels may share a code (e.g. HIGH)
        @UniqueConstraint(name = "C_U_RCA_RCH_ID_CODE", columnNames = {"RCH_ID", "RCA_CODE"}),
        // Target of the composite foreign keys (RCA_ID, RCH_ID): a message only uses values of its own channel
        @UniqueConstraint(name = "C_U_RCA_ID_RCH_ID", columnNames = {"RCA_ID", "RCH_ID"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RCA_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RCA_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RCA_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RCA_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RCA_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RCA_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RCA_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RCA_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RCA_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RCA_VALIDITY_FROM", length = 6))
@Comment("Defines the crime area type.")
public class CrimeAreaEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RCA_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the crime area.")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_crime_area_gen")
    @SequenceGenerator(name = "seq_crime_area_gen",
            sequenceName = "IS_RCA_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RCH_ID", foreignKey = @ForeignKey(name = "C_FK_RCA_RCH_ID"))
    private ChannelEntity channel;

    protected CrimeAreaEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
