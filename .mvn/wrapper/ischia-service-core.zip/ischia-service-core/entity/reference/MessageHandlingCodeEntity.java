package lu.pgd.dri.ischia.domain.persistence.entity.reference;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_REF_MESSAGE_HANDLING_CODE_RMHC", uniqueConstraints = {
        // Code unique per channel: two channels may share a code (e.g. HIGH)
        @UniqueConstraint(name = "C_U_RMHC_RCH_ID_CODE", columnNames = {"RCH_ID", "RMHC_CODE"}),
        // Target of the composite foreign keys (RMHC_ID, RCH_ID): a message only uses values of its own channel
        @UniqueConstraint(name = "C_U_RMHC_ID_RCH_ID", columnNames = {"RMHC_ID", "RCH_ID"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "RMHC_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "RMHC_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "RMHC_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "RMHC_UPDATED_BY", length = 50))
@AttributeOverride(name = "code", column = @Column(name = "RMHC_CODE", length = 100))
@AttributeOverride(name = "labelDe", column = @Column(name = "RMHC_LABEL_DE", length = 100))
@AttributeOverride(name = "labelFr", column = @Column(name = "RMHC_LABEL_FR", length = 100))
@AttributeOverride(name = "labelEn", column = @Column(name = "RMHC_LABEL_EN", length = 100))
@AttributeOverride(name = "validityTo", column = @Column(name = "RMHC_VALIDITY_TO", length = 6))
@AttributeOverride(name = "validityFrom", column = @Column(name = "RMHC_VALIDITY_FROM", length = 6))
@Comment("Defines the message processing code type.")
public class MessageHandlingCodeEntity extends AbstractReferenceEntity {

    @Id
    @Column(name = "RMHC_ID", nullable = false, updatable = false)
    @Comment("Unique identifier of the message processing code.")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_handling_code_gen"
    )
    @SequenceGenerator(name = "seq_message_handling_code_gen",
            sequenceName = "IS_RMHC_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RCH_ID", foreignKey = @ForeignKey(name = "C_FK_RMHC_RCH_ID"))
    private ChannelEntity channel;

    protected MessageHandlingCodeEntity() {
        this.id = null;
    }

    @Override
    public boolean equals(Object other) {
        return super.equals(other);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
