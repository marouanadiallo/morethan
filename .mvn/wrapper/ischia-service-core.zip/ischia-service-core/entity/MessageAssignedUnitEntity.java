package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.UserUnitEntity;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_MAP_MESSAGE_ASSIGNED_UNIT_MMAUN")
@AttributeOverride(name = "updatedAt", column = @Column(name = "MMAUN_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "MMAUN_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "MMAUN_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "MMAUN_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class MessageAssignedUnitEntity extends Auditable {

    @Id
    @Column(name = "MMAUN_ID", nullable = false, updatable = false)
    @Comment("")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_message_assigned_unit_gen"
    )
    @SequenceGenerator(
            name = "seq_message_assigned_unit_gen",
            sequenceName = "IS_MMAUN_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "RUUT_ID", foreignKey = @ForeignKey(name = "C_FK_MMAUN_RUUT_ID"))
    @Comment("")
    private UserUnitEntity userUnit;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "MSG_ID", foreignKey = @ForeignKey(name = "C_FK_MMAUN_MSG_ID"))
    @Comment("")
    private MessageEntity message;

    protected MessageAssignedUnitEntity() {
        this.id = null;
    }

    public static MessageAssignedUnitEntity of(UserUnitEntity userUnit, MessageEntity message) {
        MessageAssignedUnitEntity entity = new MessageAssignedUnitEntity();
        entity.setUserUnit(userUnit);
        entity.setMessage(message);
        return entity;
    }

}
