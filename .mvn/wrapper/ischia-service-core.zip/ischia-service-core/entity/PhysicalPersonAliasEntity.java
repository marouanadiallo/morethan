package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.application.enums.PersonDetailsType;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.CountryEntity;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_PHYSICAL_PERSON_ALIAS_PPA")
@AttributeOverride(name = "updatedAt", column = @Column(name = "PPA_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "PPA_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "PPA_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "PPA_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class PhysicalPersonAliasEntity extends Auditable {

    @Id
    @Column(name = "PPA_ID", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_physical_person_details_gen"
    )
    @SequenceGenerator(name = "seq_physical_person_details_gen",
            sequenceName = "IS_PPA_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @JoinColumn(name = "PP_ID", foreignKey = @ForeignKey(name = "C_FK_PPA_PP_ID"))
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private PhysicalPersonEntity physicalPerson;

    @Setter
    @Enumerated(EnumType.STRING)
    @Column(name = "PPA_TYPE")
    private PersonDetailsType type;

    @Setter
    @Column(name = "PPA_FIRST_NAME")
    @Comment("")
    private String firstName;

    @Setter
    @Column(name = "PPA_LAST_NAME")
    @Comment("")
    private String lastName;

    /*
     * Date of birth stored in 3 parts so that a partial date can be kept (e.g. "03/1980", day unknown).
     * Each part is optional; ranges are checked by the database (C_PPA_BIRTH_*_RANGE).
     */
    @Setter
    @Column(name = "PPA_BIRTH_DAY")
    @Comment("Day of birth (1-31), null when unknown")
    private Integer birthDay;

    @Setter
    @Column(name = "PPA_BIRTH_MONTH")
    @Comment("Month of birth (1-12), null when unknown")
    private Integer birthMonth;

    @Setter
    @Column(name = "PPA_BIRTH_YEAR")
    @Comment("Year of birth, null when unknown")
    private Integer birthYear;

    @Setter
    @Column(name = "PPA_BIRTH_PLACE", length = 255)
    @Comment("Birth place (city), free text")
    private String birthPlace;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "RCTY_BIRTH_COUNTRY_ID", foreignKey = @ForeignKey(name = "C_FK_PPA_RCTY_BIRTH_COUNTRY_ID"))
    @Comment("")
    private CountryEntity birthCountry;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "RCTY_NAT_ID", foreignKey = @ForeignKey(name = "C_FK_PPA_RCTY_NAT_ID"))
    @Comment("")
    private CountryEntity nationality;

    @Setter
    @Column(name = "PPA_IS_KNOWN_IN_CECIMA")
    @Comment("")
    private boolean isKnownInCeCIMA;

    @Setter
    @Column(name = "PPA_NOTICE")
    @Comment("")
    private String notice;

    public PhysicalPersonAliasEntity() {
        this.id = null;
    }

    public static PhysicalPersonAliasEntity of(PhysicalPersonEntity physicalPerson) {
        PhysicalPersonAliasEntity pe = new PhysicalPersonAliasEntity();
        pe.setPhysicalPerson(physicalPerson);
        return pe;
    }
}
