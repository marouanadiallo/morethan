package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Comment;

@Getter
@Entity
@Table(name = "IS_SAGA_COMPONENT_SCP", uniqueConstraints = {
        // The same SAGA component appears only once in a folder
        @UniqueConstraint(name = "C_U_SCP_SGF_ID_COMPONENT_ID", columnNames = {"SGF_ID", "SCP_COMPONENT_ID"})
})
@AttributeOverride(name = "updatedAt", column = @Column(name = "SCP_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "SCP_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "SCP_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "SCP_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class SagaComponentEntity extends Auditable {

    @Id
    @Column(name = "SCP_ID", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_saga_component_gen"
    )
    @SequenceGenerator(name = "seq_saga_component_gen",
            sequenceName = "IS_SCP_S",
            allocationSize = 20
    )
    private final Long id;

    /**
     * Folder owning the component (a folder can have several components).
     * Not final (Hibernate bytecode enhancement) but without setter: a component never changes folder.
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "SGF_ID", foreignKey = @ForeignKey(name = "C_FK_SCP_SGF_ID"))
    @Comment("SAGA folder owning the component")
    private SagaFolderEntity sagaFolder;

    @Column(name = "SCP_COMPONENT_ID")
    @Comment("")
    private Long componentId;

    @Setter
    @Column(name = "SCP_COMPONENT_SELECTED")
    private boolean selected;

    @SuppressWarnings("unused")
    protected SagaComponentEntity() {
        this.id = null;
    }

    public SagaComponentEntity(SagaFolderEntity sagaFolder, Long componentId, boolean selected) {
        this.id = null;
        this.sagaFolder = sagaFolder;
        this.componentId = componentId;
        this.selected = selected;
    }
}
