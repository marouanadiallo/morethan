package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.persistence.PersistenceUtils;
import lu.pgd.dri.ischia.domain.persistence.entity.reference.UserUnitEntity;
import org.hibernate.annotations.Comment;

import java.util.Objects;

@Getter
@Entity
@Table(name = "IS_USER_US", uniqueConstraints = {
        @UniqueConstraint(name = "C_U_US_LOGIN", columnNames = {"US_LOGIN"})
})
@AttributeOverride(name = "createdAt", column = @Column(name = "US_CREATED_AT"))
@AttributeOverride(name = "updatedAt", column = @Column(name = "US_UPDATED_AT"))
@AttributeOverride(name = "createdBy", column = @Column(name = "US_CREATED_BY", length = 50))
@AttributeOverride(name = "updatedBy", column = @Column(name = "US_UPDATED_BY", length = 50))
@Comment("Represents a system user who can access the application.")
public class AppUserEntity extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_app_user_gen")
    @Column(name = "US_ID", updatable = false, nullable = false)
    @Comment("Unique identifier of the ischia user")
    @SequenceGenerator(name = "seq_app_user_gen",
            sequenceName = "IS_US_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @Comment("Is the first name of the user")
    @Column(name = "US_FIRST_NAME", length = 100)
    private String firstName;

    @Setter
    @Comment("Is the last name of the user")
    @Column(name = "US_LAST_NAME", length = 100)
    private String lastName;

    @Setter
    @Column(name = "US_GROUP_NAME", length = 50)
    @Comment("Is the name of the group the user belongs to")
    private String groupName;

    @Setter
    @Comment("Is the email of the user")
    @Column(name = "US_EMAIL", length = 100)
    private String email;

    @Setter
    @Comment("Is the login of the user")
    @Column(name = "US_LOGIN", nullable = false)
    private String login;

    @Setter
    @Comment("Is the opj of the user")
    @Column(name = "US_OPJ", length = 100)
    private String opj;

    @Setter
    @Comment("Is the function of the user")
    @Column(name = "US_FUNCTION", length = 100)
    private String function;

    @Setter
    @Comment("Is the corps of the user")
    @Column(name = "US_CORPS", length = 100)
    private String corps;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "RUUT_ID", foreignKey = @ForeignKey(name = "C_FK_US_RUUT_ID"))
    private UserUnitEntity unit;

    protected AppUserEntity() {
        this.id = null;
    }

    public static AppUserEntity of(String login) {
        AppUserEntity entity = new AppUserEntity();
        entity.setLogin(login);
        return entity;
    }

    /**
     * Business key = login (unique and NOT NULL: C_U_US_LOGIN). The email is not part of it:
     * it is optional and can change, which would change the hashCode of a user already in a Set.
     * Proxy-safe (getters, real class) and null-safe (a user without login is only equal to itself).
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || PersistenceUtils.effectiveClass(this) != PersistenceUtils.effectiveClass(o)) {
            return false;
        }

        AppUserEntity that = (AppUserEntity) o;
        return getLogin() != null && getLogin().equals(that.getLogin());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getLogin());
    }
}
