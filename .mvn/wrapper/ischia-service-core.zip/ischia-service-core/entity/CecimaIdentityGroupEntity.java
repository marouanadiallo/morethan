package lu.pgd.dri.ischia.domain.persistence.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lu.pgd.dri.ischia.domain.application.enums.CecimaIdentityGroupMatches;
import lu.pgd.dri.ischia.domain.persistence.PersistenceUtils;
import org.hibernate.annotations.Comment;

import java.util.Objects;

@Getter
@Entity
@Table(name = "IS_CECIMA_GROUP_CEG")
@AttributeOverride(name = "updatedAt", column = @Column(name = "CEG_UPDATED_AT"))
@AttributeOverride(name = "updatedBy", column = @Column(name = "CEG_UPDATED_BY", length = 50))
@AttributeOverride(name = "createdAt", column = @Column(name = "CEG_CREATED_AT", nullable = false, updatable = false))
@AttributeOverride(name = "createdBy", column = @Column(name = "CEG_CREATED_BY", length = 50, nullable = false, updatable = false))
@Comment("")
public class CecimaIdentityGroupEntity extends Auditable {

    @Id
    @Column(name = "CEG_ID", nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "seq_cecima_identity_group_gen"
    )
    @SequenceGenerator(name = "seq_cecima_identity_group_gen",
            sequenceName = "IS_CEG_S",
            allocationSize = 20
    )
    private final Long id;

    @Setter
    @Column(name = "CEG_CECIMA_GROUP_ID")
    private Long cecimaGroupId;

    @Setter
    @Column(name = "CEG_GROUP_MATCHES")
    @Enumerated(EnumType.STRING)
    private CecimaIdentityGroupMatches matches;

    protected CecimaIdentityGroupEntity() {
        this.id = null;
    }

    public static CecimaIdentityGroupEntity of(Long cecimaGroupId, CecimaIdentityGroupMatches matches) {
        CecimaIdentityGroupEntity entity = new CecimaIdentityGroupEntity();
        entity.setCecimaGroupId(cecimaGroupId);
        entity.setMatches(matches);
        return entity;
    }

    /**
     * Business key = identifier of the group in CECIMA. Proxy-safe (getters, real class) and null-safe
     * (a group without CECIMA id is only equal to itself).
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || PersistenceUtils.effectiveClass(this) != PersistenceUtils.effectiveClass(o)) {
            return false;
        }

        CecimaIdentityGroupEntity that = (CecimaIdentityGroupEntity) o;
        return getCecimaGroupId() != null && getCecimaGroupId().equals(that.getCecimaGroupId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getCecimaGroupId());
    }
}
