-- Date : 10-19-2026
-- DDL of CONSULTATION_LOG table

-- Create table
CREATE TABLE IS_CONSULTATION_LOG_CL (
    CL_ID                   NUMBER(19, 0),
    CL_TRACE_ID             VARCHAR2(64 CHAR),
    RCSTE_ID                NUMBER(19, 0),
    CL_MOTIVE               VARCHAR2(300 CHAR),
    CL_ONLY_ACTIVE          NUMBER(1, 0),
    CL_URL                  VARCHAR2(2000 CHAR),
    CL_REQ_BODY             CLOB,
    CL_QUERY_PARAMETERS     VARCHAR2(2000 CHAR),
    CL_TIME                 TIMESTAMP(6),
    CL_USER_ID              VARCHAR2(255 CHAR),
    CONSTRAINT C_PK_CL_ID PRIMARY KEY (CL_ID),
    CONSTRAINT C_FK_CL_RCSTE_ID FOREIGN KEY (RCSTE_ID) REFERENCES IS_REF_CONSULTATION_SCOPE_TYPE_RCSTE (RCSTE_ID)
) ${tablespace_data}; -- flyway placeholder

-- Create sequence
CREATE SEQUENCE IS_CL_S START WITH 1 INCREMENT BY 20 CACHE 20;

-- Comments
COMMENT ON TABLE IS_CONSULTATION_LOG_CL IS 'Stores consultation traces for read operations on ischia-service resources';
COMMENT ON COLUMN IS_CONSULTATION_LOG_CL.CL_ID IS 'Technical identifier of the consultation log entry';
COMMENT ON COLUMN IS_CONSULTATION_LOG_CL.CL_TRACE_ID IS 'Trace identifier propagated across the request flow';
COMMENT ON COLUMN IS_CONSULTATION_LOG_CL.RCSTE_ID IS 'Optional consultation scope type associated with the consultation';
COMMENT ON COLUMN IS_CONSULTATION_LOG_CL.CL_MOTIVE IS 'Optional motive provided for the consultation';
COMMENT ON COLUMN IS_CONSULTATION_LOG_CL.CL_ONLY_ACTIVE IS 'Optional flag indicating that only active data was requested';
COMMENT ON COLUMN IS_CONSULTATION_LOG_CL.CL_URL IS 'Full URL of the consulted resource';
COMMENT ON COLUMN IS_CONSULTATION_LOG_CL.CL_QUERY_PARAMETERS IS 'Raw query string used for the consultation';
COMMENT ON COLUMN IS_CONSULTATION_LOG_CL.CL_TIME IS 'Timestamp when the consultation was logged';
COMMENT ON COLUMN IS_CONSULTATION_LOG_CL.CL_USER_ID IS 'Identifier of the authenticated user who performed the consultation';
COMMENT ON COLUMN IS_CONSULTATION_LOG_CL.CL_REQ_BODY IS 'Request body captured for JSON payloads after masking configured sensitive fields';