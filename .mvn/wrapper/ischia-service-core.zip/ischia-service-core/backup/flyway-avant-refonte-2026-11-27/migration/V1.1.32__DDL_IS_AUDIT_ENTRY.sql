-- Date : 10-19-2026
-- DDL of AUDIT_ENTRY table

-- Create table
CREATE TABLE IS_AUDIT_ENTRY_AE (
    AE_ID          NUMBER(19, 0),
    AE_TRACE_ID    VARCHAR2(64 CHAR),
    AE_USER_ID     VARCHAR2(255 CHAR),
    AE_STATUS      VARCHAR2(3 CHAR),
    AE_ACTION      VARCHAR2(10 CHAR),
    AE_URL         VARCHAR2(2000 CHAR),
    AE_REQ_BODY    CLOB,
    AE_HEADERS     VARCHAR2(4000 CHAR),
    AE_START_DATE  TIMESTAMP(6),
    AE_END_DATE    TIMESTAMP(6),
    AE_ORIGIN_APP  VARCHAR2(255 CHAR),
    CONSTRAINT C_PK_AE_ID PRIMARY KEY (AE_ID)
) ${tablespace_data}; -- flyway placeholder

-- Create sequence
CREATE SEQUENCE IS_AE_S START WITH 1 INCREMENT BY 20 CACHE 20;

-- Comments
COMMENT ON TABLE IS_AUDIT_ENTRY_AE IS 'Stores inbound REST API audit events for ischia-service requests';
COMMENT ON COLUMN IS_AUDIT_ENTRY_AE.AE_ID IS 'Technical identifier of the audit entry';
COMMENT ON COLUMN IS_AUDIT_ENTRY_AE.AE_TRACE_ID IS 'Trace identifier propagated across the request flow using the x-b3-trace-id header';
COMMENT ON COLUMN IS_AUDIT_ENTRY_AE.AE_USER_ID IS 'Authenticated user identifier propagated from the preferred_username JWT property';
COMMENT ON COLUMN IS_AUDIT_ENTRY_AE.AE_STATUS IS 'HTTP response status code returned by ischia-service';
COMMENT ON COLUMN IS_AUDIT_ENTRY_AE.AE_ACTION IS 'HTTP method used for the audited request';
COMMENT ON COLUMN IS_AUDIT_ENTRY_AE.AE_URL IS 'Full request URL including query string when present';
COMMENT ON COLUMN IS_AUDIT_ENTRY_AE.AE_REQ_BODY IS 'Request body captured for JSON payloads after masking configured sensitive fields';
COMMENT ON COLUMN IS_AUDIT_ENTRY_AE.AE_HEADERS IS 'Formatted request headers excluding the Authorization header';
COMMENT ON COLUMN IS_AUDIT_ENTRY_AE.AE_START_DATE IS 'Timestamp when request processing started in ischia-service';
COMMENT ON COLUMN IS_AUDIT_ENTRY_AE.AE_END_DATE IS 'Timestamp when request processing ended in ischia-service';
COMMENT ON COLUMN IS_AUDIT_ENTRY_AE.AE_ORIGIN_APP IS 'Caller application propagated by dri-starter-log using the x-sender header';