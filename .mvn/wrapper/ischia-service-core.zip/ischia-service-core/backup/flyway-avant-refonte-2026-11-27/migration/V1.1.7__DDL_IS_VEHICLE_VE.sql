-- Date : 10-8-2026
-- DDL of VEHICLE table

-- Create table
CREATE TABLE IS_VEHICLE_VE (
    VE_ID                      NUMBER(19),
    VE_LICENCE_PLATE           VARCHAR2(50 BYTE),
    VE_HULL                    VARCHAR2(50 BYTE),
    VE_COUNTRY                 VARCHAR2(50 BYTE),
    VE_FIRST_REGISTRATION_DATE TIMESTAMP,
    VE_CATEGORY                VARCHAR2(50 BYTE),
    VE_COLOR                   VARCHAR2(50 BYTE),
    VE_BRAND                   VARCHAR2(50 BYTE),
    VE_MODEL                   VARCHAR2(50 BYTE),
    VE_REMARKS                 VARCHAR2(2000 BYTE),
    VE_CREATED_AT              TIMESTAMP CONSTRAINT C_VE_CREATED_AT_REQUIRED NOT NULL,
    VE_CREATED_BY              VARCHAR2(50 CHAR) CONSTRAINT C_VE_CREATED_BY_REQUIRED NOT NULL,
    VE_UPDATED_AT              TIMESTAMP,
    VE_UPDATED_BY              VARCHAR2(50 CHAR),
    MSG_ID                     NUMBER CONSTRAINT C_FK_VE_MSG_ID_REQUIRED NOT NULL,
    CONSTRAINT C_PK_VE_ID PRIMARY KEY (VE_ID),
    CONSTRAINT C_FK_VE_MSG_ID FOREIGN KEY (MSG_ID) REFERENCES IS_MESSAGE_MSG (MSG_ID)
) ${tablespace_data}; -- flyway placeholder

-- Create sequence
CREATE SEQUENCE IS_VE_S START WITH 1 INCREMENT BY 20 CACHE 20;

-- Index on foreign keys
CREATE INDEX I_VE_MSG_ID ON IS_VEHICLE_VE (MSG_ID) ${tablespace_index}; -- flyway placeholder