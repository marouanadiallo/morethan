-- Date : 10-19-2026
-- DDL of REF_CONSULTATION_SCOPE_TYPE_RCSTE table

-- Create table
CREATE TABLE IS_REF_CONSULTATION_SCOPE_TYPE_RCSTE
(
    RCSTE_ID            NUMBER(18),
    RCSTE_CODE          VARCHAR2(100 CHAR),
    RCSTE_LABEL_DE      VARCHAR2(150 char),
    RCSTE_LABEL_EN      VARCHAR2(150 char),
    RCSTE_LABEL_FR      VARCHAR2(150 char),
    RCSTE_VALIDITY_FROM DATE,
    RCSTE_VALIDITY_TO   DATE,
    RCSTE_CREATED_AT    TIMESTAMP(6),
    RCSTE_UPDATED_AT    TIMESTAMP(6),
    RCSTE_CREATED_BY    VARCHAR2(50 char),
    RCSTE_UPDATED_BY    VARCHAR2(50 char),
    CONSTRAINT C_PK_RCSTE_ID PRIMARY KEY (RCSTE_ID)
) ${tablespace_data}; -- flyway placeholder

-- Create sequence
CREATE SEQUENCE IS_RCSTE_S START WITH 1 INCREMENT BY 20 CACHE 20;

-- Comments
comment on table IS_REF_CONSULTATION_SCOPE_TYPE_RCSTE is 'Reference table containing the possible values of consultation scope types';
comment on column IS_REF_CONSULTATION_SCOPE_TYPE_RCSTE.RCSTE_ID is 'Technical identifier of the entry';
comment on column IS_REF_CONSULTATION_SCOPE_TYPE_RCSTE.RCSTE_CODE is 'Unique code identifying the consultation scope type';
comment on column IS_REF_CONSULTATION_SCOPE_TYPE_RCSTE.RCSTE_LABEL_DE is 'Label of the entry in german';
comment on column IS_REF_CONSULTATION_SCOPE_TYPE_RCSTE.RCSTE_LABEL_FR is 'Label of the entry in french';
comment on column IS_REF_CONSULTATION_SCOPE_TYPE_RCSTE.RCSTE_VALIDITY_FROM is 'Timestamp from which the entry is valid';
comment on column IS_REF_CONSULTATION_SCOPE_TYPE_RCSTE.RCSTE_VALIDITY_TO is 'Timestamp until which the entry is valid';
comment on column IS_REF_CONSULTATION_SCOPE_TYPE_RCSTE.RCSTE_CREATED_AT is 'Timestamp of the creation of the entry';
comment on column IS_REF_CONSULTATION_SCOPE_TYPE_RCSTE.RCSTE_CREATED_BY is 'User which has created of the entry';
comment on column IS_REF_CONSULTATION_SCOPE_TYPE_RCSTE.RCSTE_UPDATED_AT is 'Timestamp of the last change on the entry';
comment on column IS_REF_CONSULTATION_SCOPE_TYPE_RCSTE.RCSTE_UPDATED_BY is 'User which has applied the last change on the entry';