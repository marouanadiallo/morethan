package lu.pgd.dri.ischia.web.controller;

import lu.pgd.dri.ischia.domain.persistence.repository.ConsultationLogEntryRepository;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.transaction.annotation.Transactional;

import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * End-to-end tests of every reference-type endpoint: HTTP → controller → service → JPA → H2 (schema from Flyway).
 * <ul>
 *   <li>Data: sql/referential-data.sql (ids >= 9001, codes IT_*), rolled back after each test.</li>
 *   <li>Assertions only look at the IT_* rows, so reference data seeded by Flyway does not break them.</li>
 *   <li>MockMvc (MOCK environment, not RANDOM_PORT): the request runs in the test thread,
 *       inside the test transaction, so the rollback also covers what the request writes.</li>
 * </ul>
 * These tests also check that the JPA mapping matches the Flyway schema (table / column names, RCH_ID...).
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
@Sql("/sql/referential-data.sql")
class ReferentialIT {

    private static final String BASE = "/api/v1/referential/";
    private static final long VALID_ID = 9001L;
    private static final long CHANNEL_A = 9001L;
    private static final long CHANNEL_B = 9004L;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ConsultationLogEntryRepository consultationLogRepository;

    /** Endpoints that expose a {@code code} (all except country). */
    static Stream<String> codeEndpoints() {
        return Stream.concat(genericEndpoints(), channelEndpoints());
    }

    static Stream<String> genericEndpoints() {
        return Stream.of(
                "channel-types",
                "document-category-types",
                "message-delay-types",
                "message-status-types",
                "message-types",
                "nationality-types",
                "organization-types",
                "unit-organization-types",
                "user-unit-types");
    }

    static Stream<String> channelEndpoints() {
        return Stream.of(
                "crime-area-types",
                "message-confidentiality-types",
                "message-handling-code-types",
                "message-priority-types",
                "message-reliability-types");
    }

    /**
     * Lookup by code: channel reference types need the channel (a code is unique per channel only).
     * Generic types: no parameter.
     */
    private static String byCode(String endpoint) {
        boolean channelScoped = channelEndpoints().anyMatch(endpoint::equals);
        return endpoint + "/code/{code}" + (channelScoped ? "?channelId=" + CHANNEL_A : "");
    }

    private ResultActions call(String path, Object... uriVars) throws Exception {
        return mockMvc.perform(get(BASE + path, uriVars)
                .contentType(MediaType.APPLICATION_JSON)
                .with(jwt().jwt(jwt -> jwt.subject("it-user").claim("preferred_username", "it-user"))));
    }

    @Nested
    class AllReferenceTypes {

        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#codeEndpoints")
        void listShouldOnlyContainReferencesValidToday(String endpoint) throws Exception {
            call(endpoint)
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$[*].code", hasItem("IT_VALID")))
                    .andExpect(jsonPath("$[*].code", not(hasItem("IT_EXPIRED"))))
                    .andExpect(jsonPath("$[*].code", not(hasItem("IT_FUTURE"))));
        }

        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#codeEndpoints")
        void getByIdShouldReturnTheFullReference(String endpoint) throws Exception {
            call(endpoint + "/{id}", VALID_ID)
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(VALID_ID))
                    .andExpect(jsonPath("$.code").value("IT_VALID"))
                    .andExpect(jsonPath("$.labelFr").value("IT_VALID fr"))
                    .andExpect(jsonPath("$.labelEn").value("IT_VALID en"))
                    .andExpect(jsonPath("$.labelDe").value("IT_VALID de"))
                    .andExpect(jsonPath("$.validityFrom").value("2020-01-01"));
        }

        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#codeEndpoints")
        void getByCodeShouldIgnoreCase(String endpoint) throws Exception {
            call(byCode(endpoint), "it_valid")
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(VALID_ID))
                    .andExpect(jsonPath("$.code").value("IT_VALID"));
        }

        /**
         * By design, id / code lookups ignore validity: a message created last year must still
         * display the (now expired) value it references.
         */
        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#codeEndpoints")
        void getByCodeShouldAlsoReturnExpiredReferences(String endpoint) throws Exception {
            call(byCode(endpoint), "IT_EXPIRED")
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.validityTo").value("2020-12-31"));
        }

        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#codeEndpoints")
        void unknownIdShouldReturn404ProblemDetail(String endpoint) throws Exception {
            call(endpoint + "/{id}", 999_999_999L)
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.status").value(404))
                    .andExpect(jsonPath("$.detail", containsString("999999999")));
        }

        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#codeEndpoints")
        void unknownCodeShouldReturn404ProblemDetail(String endpoint) throws Exception {
            call(byCode(endpoint), "IT_UNKNOWN")
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.detail", containsString("IT_UNKNOWN")));
        }

        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#codeEndpoints")
        void nonNumericIdShouldReturn400(String endpoint) throws Exception {
            call(endpoint + "/{id}", "abc").andExpect(status().isBadRequest());
        }
    }

    @Nested
    class ChannelReferenceTypes {

        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#channelEndpoints")
        void responseShouldContainChannelId(String endpoint) throws Exception {
            call(endpoint + "/{id}", VALID_ID)
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.channelId").value(CHANNEL_A));
        }

        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#channelEndpoints")
        void filterOnChannelAShouldOnlyReturnItsValidReferences(String endpoint) throws Exception {
            call(endpoint + "?channelId={channelId}", CHANNEL_A)
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$", hasSize(1)))
                    .andExpect(jsonPath("$[0].code").value("IT_VALID"))
                    .andExpect(jsonPath("$[0].channelId").value(CHANNEL_A));
        }

        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#channelEndpoints")
        void filterOnChannelBShouldOnlyReturnItsReferences(String endpoint) throws Exception {
            call(endpoint + "?channelId={channelId}", CHANNEL_B)
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$", hasSize(1)))
                    .andExpect(jsonPath("$[0].code").value("IT_VALID_B"));
        }

        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#channelEndpoints")
        void withoutFilterShouldReturnEveryChannel(String endpoint) throws Exception {
            call(endpoint)
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$[*].code", hasItems("IT_VALID", "IT_VALID_B")));
        }

        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#channelEndpoints")
        void getByCodeWithoutChannelShouldReturn400(String endpoint) throws Exception {
            // A code is unique per channel only: the channel is mandatory
            call(endpoint + "/code/{code}", "IT_VALID").andExpect(status().isBadRequest());
        }

        /**
         * IT_SHARED exists on both channels (ids 9005 on A, 9006 on B, expired so that the lists are not affected):
         * the lookup by code returns the value of the requested channel.
         */
        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#channelEndpoints")
        void sameCodeOnTwoChannelsShouldReturnTheValueOfTheRequestedChannel(String endpoint) throws Exception {
            call(endpoint + "/code/{code}?channelId={channelId}", "it_shared", CHANNEL_A)
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(9005))
                    .andExpect(jsonPath("$.channelId").value(CHANNEL_A));
            call(endpoint + "/code/{code}?channelId={channelId}", "IT_SHARED", CHANNEL_B)
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(9006))
                    .andExpect(jsonPath("$.channelId").value(CHANNEL_B));
        }

        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#channelEndpoints")
        void codeOfAnotherChannelShouldReturn404(String endpoint) throws Exception {
            // IT_VALID_B only exists on channel B
            call(endpoint + "/code/{code}?channelId={channelId}", "IT_VALID_B", CHANNEL_A)
                    .andExpect(status().isNotFound());
        }

        @ParameterizedTest(name = "{0}")
        @MethodSource("lu.pgd.dri.ischia.web.controller.ReferentialIT#channelEndpoints")
        void unknownChannelShouldReturnEmptyList(String endpoint) throws Exception {
            call(endpoint + "?channelId={channelId}", 999_999_999L)
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$", hasSize(0)));
        }
    }

    @Nested
    class Country {

        @Test
        void listShouldOnlyContainCountriesValidToday() throws Exception {
            call("country-types")
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$[*].alphaCode2", hasItem("QX")))
                    .andExpect(jsonPath("$[*].alphaCode2", not(hasItem("QY"))))
                    .andExpect(jsonPath("$[*].alphaCode2", not(hasItem("QZ"))));
        }

        @ParameterizedTest(name = "code {0}")
        @ValueSource(strings = {"QX", "qx", "QXX", "qxx"})
        void getByCodeShouldAcceptAlpha2AndAlpha3IgnoringCase(String code) throws Exception {
            call("country-types/code/{code}", code)
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(9001))
                    .andExpect(jsonPath("$.alphaCode2").value("QX"))
                    .andExpect(jsonPath("$.alphaCode3").value("QXX"));
        }

        @Test
        void getByIdShouldReturnTheCountry() throws Exception {
            call("country-types/{id}", 9001)
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.labelFr").value("IT pays"));
        }

        @Test
        void unknownCodeShouldReturn404() throws Exception {
            call("country-types/code/{code}", "Q0").andExpect(status().isNotFound());
        }
    }

    @Nested
    class UserUnit {

        @Test
        void responseShouldContainOrganizationId() throws Exception {
            call("user-unit-types/{id}", VALID_ID)
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.organizationId").value(9001));
        }
    }

    @Nested
    class ConsultationAudit {

        @Test
        void eachSuccessfulGetShouldWriteOneConsultationLog() throws Exception {
            long before = consultationLogRepository.count();

            call("message-types/{id}", VALID_ID).andExpect(status().isOk());
            call("country-types").andExpect(status().isOk());
            call("message-priority-types?channelId={channelId}", CHANNEL_A).andExpect(status().isOk());

            assertThat(consultationLogRepository.count()).isEqualTo(before + 3);
        }

        @Test
        void failedGetShouldNotWriteAnyConsultationLog() throws Exception {
            long before = consultationLogRepository.count();

            call("message-types/{id}", 999_999_999L).andExpect(status().isNotFound());

            assertThat(consultationLogRepository.count()).isEqualTo(before);
        }
    }
}
