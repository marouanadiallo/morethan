package lu.pgd.dri.ischia.web.controller;

import lu.pgd.dri.ischia.domain.application.exception.ResourceNotFoundException;
import lu.pgd.dri.ischia.domain.application.service.referential.MessageReliabilityService;
import lu.pgd.dri.ischia.domainapi.response.ChannelReferentialResponse;
import lu.pgd.dri.ischia.web.controller.advice.MessagesProvider;
import lu.pgd.dri.ischia.web.controller.referential.MessageReliabilityController;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.never;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Web layer of a channel-scoped reference type (AbstractChannelReferentialController),
 * tested through MessageReliabilityController. The service is mocked.
 */
@WebMvcTest(controllers = MessageReliabilityController.class)
@ActiveProfiles("test")
@Import(MessagesProvider.class)
class MessageReliabilityControllerTests {

    private static final String URL = "/api/v1/referential/message-reliability-types";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private MessagesProvider messagesProvider;

    @MockitoBean
    private MessageReliabilityService service;

    @Test
    void getAll_withoutChannel_shouldReturn200WithList() throws Exception {
        given(service.getAll(null)).willReturn(List.of(response(1L, "ABC", 3L)));

        mockMvc.perform(authenticated(get(URL)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].code").value("ABC"))
                .andExpect(jsonPath("$[0].channelId").value(3));
    }

    @Test
    void getAll_withChannel_shouldPassChannelToService() throws Exception {
        given(service.getAll(3L)).willReturn(List.of(response(1L, "ABC", 3L), response(2L, "DEF", 3L)));

        mockMvc.perform(authenticated(get(URL).param("channelId", "3")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)));
        then(service).should().getAll(3L);
    }

    @Test
    void getAll_withInvalidChannel_shouldReturn400() throws Exception {
        mockMvc.perform(authenticated(get(URL).param("channelId", "abc")))
                .andExpect(status().isBadRequest());
        then(service).should(never()).getAll(any());
    }

    @Test
    void getByCode_shouldPassChannelAndCodeToService() throws Exception {
        given(service.getByCode(3L, "Ref")).willReturn(response(1L, "Ref", 3L));

        mockMvc.perform(authenticated(get(URL + "/code/{code}", "Ref").param("channelId", "3")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("Ref"))
                .andExpect(jsonPath("$.channelId").value(3));
    }

    @Test
    void getByCode_withoutChannel_shouldReturn400() throws Exception {
        // A code is unique per channel only: the channel is mandatory
        mockMvc.perform(authenticated(get(URL + "/code/{code}", "Ref")))
                .andExpect(status().isBadRequest());
        then(service).should(never()).getByCode(any(), any());
    }

    @Test
    void getByCode_withInvalidChannel_shouldReturn400() throws Exception {
        mockMvc.perform(authenticated(get(URL + "/code/{code}", "Ref").param("channelId", "abc")))
                .andExpect(status().isBadRequest());
        then(service).should(never()).getByCode(any(), any());
    }

    @Test
    void getById_shouldReturn200() throws Exception {
        given(service.getById(1L)).willReturn(response(1L, "Ref", 3L));

        mockMvc.perform(authenticated(get(URL + "/{id}", 1)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1));
    }

    @Test
    void getById_withNonNumericId_shouldReturn400() throws Exception {
        mockMvc.perform(authenticated(get(URL + "/{id}", "abc")))
                .andExpect(status().isBadRequest());
    }

    @Test
    void getByCode_shouldReturn404WhenNotFound() throws Exception {
        given(service.getByCode(3L, "RefM"))
                .willThrow(new ResourceNotFoundException("referential.notfound.byChannelAndCode", "RefM", 3L));

        mockMvc.perform(authenticated(get(URL + "/code/{code}", "RefM").param("channelId", "3")))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.detail").value(messagesProvider.get("referential.notfound.byChannelAndCode", "RefM", 3L)));
    }

    @Test
    void getById_shouldReturn404WhenNotFound() throws Exception {
        given(service.getById(1L)).willThrow(new ResourceNotFoundException("referential.notfound.byId", 1L));

        mockMvc.perform(authenticated(get(URL + "/{id}", "1")))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.detail").value(messagesProvider.get("referential.notfound.byId", 1L)));
    }

    private static ChannelReferentialResponse response(Long id, String code, Long channelId) {
        return new ChannelReferentialResponse(id, channelId, code, "Label Fr", "Label En", "Label De", null, null);
    }

    private static RequestBuilder authenticated(MockHttpServletRequestBuilder request) {
        return request
                .contentType(MediaType.APPLICATION_JSON)
                .with(jwt().jwt(jwt -> jwt.subject("xac7865").claim("preferred_username", "xac7865")));
    }
}
