package lu.pgd.dri.ischia.web.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lu.pgd.dri.ischia.audit.business.ConsultationLog;
import lu.pgd.dri.ischia.domain.application.service.AbstractChannelReferentialService;
import lu.pgd.dri.ischia.domainapi.response.ChannelReferentialResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * Reference types that belong to a channel: same endpoints as {@link AbstractReferentialController},
 * the response carries the {@code channelId} and the list can be filtered with {@code ?channelId=}.
 * <br>
 * Every GET is logged as a consultation (class-level rule, see BusinessLogResolver).
 */
@ConsultationLog
public abstract class AbstractChannelReferentialController {

    protected abstract AbstractChannelReferentialService<?> service();

    @GetMapping
    @Tag(name = "Referential - List")
    @Operation(
            description = "Provides the list of valid data for the reference type, optionally filtered by channel",
            responses = {@ApiResponse(responseCode = "200", description = "Successful operation")}
    )
    public ResponseEntity<List<ChannelReferentialResponse>> getAll(
            @Parameter(description = "Channel identifier (optional)")
            @RequestParam(required = false) Long channelId) {
        return ResponseEntity.ok(this.service().getAll(channelId));
    }

    @GetMapping("/{id}")
    @Tag(name = "Referential - by ID")
    @Operation(
            description = "Reference type determined by its identifier",
            responses = {@ApiResponse(responseCode = "200", description = "Successful operation")}
    )
    public ResponseEntity<ChannelReferentialResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(this.service().getById(id));
    }

    @GetMapping("/code/{code}")
    @Tag(name = "Referential - by code")
    @Operation(
            description = "Reference type determined by its channel and its code (a code is unique per channel only)",
            responses = {@ApiResponse(responseCode = "200", description = "Successful operation")}
    )
    public ResponseEntity<ChannelReferentialResponse> getByCode(
            @PathVariable String code,
            @Parameter(description = "Channel identifier (mandatory: two channels may share a code)")
            @RequestParam Long channelId) {
        return ResponseEntity.ok(this.service().getByCode(channelId, code));
    }
}
